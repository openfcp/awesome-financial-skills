# -*- coding: utf-8 -*-
"""v13.0 报告中间模型（IR）。

ResearchReport 先归一成一个与格式无关的文档树，Word / PPT / PDF / Markdown
渲染器只消费这一棵树，避免同一份结论在四种排版里各说各话。

纯标准库。渲染器不得在此写业务判断。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

IR_VERSION = "13.0"


def fmt_pct(value: Any, digits: int = 2) -> str:
    """把小数比例或百分数渲染成带符号的百分串；无法判读时给破折号。"""
    if value is None or value == "":
        return "—"
    try:
        f = float(str(value).replace("%", "").replace(",", "").strip())
    except (TypeError, ValueError):
        return "—"
    if f != f:  # NaN
        return "—"
    return f"{f:+.{digits}f}%"


def fmt_ratio(value: Any, digits: int = 0) -> str:
    """0~1 的比例渲染成百分比；越界时按原值提示，不做二次缩放。"""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return "—"
    if f != f:
        return "—"
    if 0.0 <= f <= 1.0:
        return f"{f * 100:.{digits}f}%"
    return f"{f:.{digits}f}"


def fmt_num(value: Any, digits: int = 2) -> str:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return "—"
    if f != f:
        return "—"
    return f"{f:.{digits}f}"


@dataclass
class Heading:
    text: str
    level: int = 2


@dataclass
class Paragraph:
    text: str
    style: str = "body"  # body | lead | note


@dataclass
class Bullets:
    items: List[str]
    ordered: bool = False


@dataclass
class Table:
    header: List[str]
    rows: List[List[str]]
    align: List[str] = field(default_factory=list)  # left | right | center
    caption: str = ""
    narrow_drop: List[int] = field(default_factory=list)  # 窄版面（PPT）丢弃的列下标

    def narrow(self) -> Tuple[List[str], List[List[str]], List[str]]:
        """返回按 narrow_drop 裁剪后的列/行/对齐，供窄版面渲染器使用。"""
        drop = set(i for i in self.narrow_drop if 0 <= i < len(self.header))
        keep = [i for i in range(len(self.header)) if i not in drop]
        header = [self.header[i] for i in keep]
        rows = [[(r[i] if i < len(r) else "") for i in keep] for r in self.rows]
        align = [self.align[i] if i < len(self.align) else "left" for i in keep]
        return header, rows, align


@dataclass
class MetricGrid:
    """键值对卡片；Word/PPT 用两列表格，PDF 用行排。"""

    items: List[Tuple[str, str]]


@dataclass
class CodeBlock:
    text: str
    language: str = ""


@dataclass
class Callout:
    text: str
    kind: str = "note"  # note | warning


@dataclass
class Section:
    title: str
    blocks: List[Any] = field(default_factory=list)


@dataclass
class ReportDocument:
    """一份与格式无关的研究报告。"""

    title: str
    subtitle: str = ""
    meta: List[Tuple[str, str]] = field(default_factory=list)
    sections: List[Section] = field(default_factory=list)
    disclaimer: str = ""
    ir_version: str = IR_VERSION

    def section_titles(self) -> List[str]:
        return [s.title for s in self.sections]

    def iter_blocks(self):
        for section in self.sections:
            yield section.title, section.blocks

    def plain_text(self) -> str:
        """降级导出（.txt）与 MCP 文本返回共用的纯文本形状。"""
        lines: List[str] = [self.title]
        if self.subtitle:
            lines.append(self.subtitle)
        for key, value in self.meta:
            lines.append(f"{key}：{value}")
        for section in self.sections:
            lines.append("")
            lines.append(section.title)
            lines.extend(_block_lines(section.blocks))
        if self.disclaimer:
            lines.append("")
            lines.append("免责声明")
            lines.append(self.disclaimer)
        return "\n".join(lines)


_REPORT_KEYS = ("symbol", "name", "run_id", "schema_version", "executive_summary",
                "conclusions", "risks", "counterpoints", "methodology", "evidence",
                "forecasts", "scenarios", "asset_analysis", "data_quality", "warnings")


def coerce_document(doc: Any) -> ReportDocument:
    """把 ReportDocument / ResearchReport / 其 dict 归一成 IR 文档树。

    Word、PPT、PDF 三个渲染器共用这一条归一路径，避免同一份结论在不同格式里
    各说各话。非报告对象抛 ValueError，由调用方转换成各自的 ExportError。
    """
    if isinstance(doc, ReportDocument):
        return doc
    if doc is None:
        raise ValueError("缺少可渲染的报告对象")
    if isinstance(doc, dict):
        # 任意 dict 都能被 build_document 宽容地读成"全空"报告，于是调用方传错
        # 对象时会得到一份排版精美、结论为空的文档。这里要求至少命中一个报告字段。
        if not any(key in doc for key in _REPORT_KEYS):
            raise ValueError("字典里没有可识别的报告字段，无法渲染")
        return build_document(doc)
    if hasattr(doc, "to_dict"):
        return build_document(doc)
    raise ValueError("不支持的报告类型：%s" % type(doc).__name__)


def _block_lines(blocks: Sequence[Any]) -> List[str]:
    out: List[str] = []
    for block in blocks:
        if isinstance(block, Paragraph):
            out.append(block.text)
        elif isinstance(block, Bullets):
            out.extend(f"- {item}" for item in block.items)
        elif isinstance(block, Heading):
            out.append(block.text)
        elif isinstance(block, Table):
            out.append(" | ".join(block.header))
            out.extend(" | ".join(row) for row in block.rows)
        elif isinstance(block, MetricGrid):
            out.extend(f"{key}：{value}" for key, value in block.items)
        elif isinstance(block, CodeBlock):
            out.append(block.text)
        elif isinstance(block, Callout):
            out.append(block.text)
    return out


# ---------------------------------------------------------------- 组装

def _as_dict(obj: Any) -> Dict[str, Any]:
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "to_dict"):
        return dict(obj.to_dict())
    return dict(obj or {})


def _direction_line(direction: str, confidence: float, score: float) -> str:
    return f"综合方向 {direction}｜置信度 {fmt_ratio(confidence)}｜评分 {fmt_num(score, 1)}/100"


def build_document(report: Any) -> ReportDocument:
    """把 v12 的 ResearchReport（或其 to_dict() 结果）编译成 IR 文档树。

    只读字段；缺字段按"未知"处理，不补造数字。
    """
    data: Dict[str, Any] = report.to_dict() if hasattr(report, "to_dict") else dict(report or {})

    symbol = str(data.get("symbol") or "")
    name = str(data.get("name") or symbol)
    asset_type = str(data.get("asset_type") or "")
    direction = str(data.get("direction") or "neutral")
    confidence = data.get("confidence") or 0.0
    score = data.get("score") or 0.0

    doc = ReportDocument(
        title=f"{name} 研究简报",
        subtitle=_direction_line(direction, float(confidence), float(score)),
        meta=[
            ("标的", f"{symbol}（{asset_type}）" if asset_type else symbol),
            ("生成时间", str(data.get("generated_at") or "")),
            ("数据截止", str(data.get("data_cutoff") or data.get("as_of") or "")),
        ],
        disclaimer=str(data.get("disclaimer") or ""),
    )

    doc.sections.append(_summary_section(data))
    doc.sections.append(_forecast_section(data.get("forecasts") or []))
    doc.sections.append(_factor_section(data.get("asset_analysis") or {}))
    doc.sections.append(_scenario_section(data.get("scenarios") or []))
    doc.sections.append(_risk_section(data))
    doc.sections.append(_evidence_section(data.get("evidence") or []))
    doc.sections.append(_method_section(data))
    return doc


def _summary_section(data: Dict[str, Any]) -> Section:
    blocks: List[Any] = [
        Paragraph(str(data.get("executive_summary") or "数据不足，暂不形成方向性结论。"), style="lead")
    ]
    conclusions = list(data.get("conclusions") or [])
    if conclusions:
        blocks.append(Heading("核心结论", level=3))
        blocks.append(Bullets(conclusions))
    return Section("一、结论摘要", blocks)


def _forecast_section(forecasts: List[Any]) -> Section:
    if not forecasts:
        return Section("二、多周期概率预测", [Paragraph("数据不足，未生成概率预测。")])

    rows: List[List[str]] = []
    provenance: List[str] = []
    for f in forecasts:
        item: Dict[str, Any] = _as_dict(f)
        quant = item.get("quantiles") or {}
        q05 = quant.get("p05", quant.get("q05"))
        q95 = quant.get("p95", quant.get("q95"))
        interval = (
            f"{fmt_pct(q05)} ~ {fmt_pct(q95)}"
            if q05 is not None and q95 is not None
            else "—"
        )
        flag = "（弃权）" if item.get("abstain") else ""
        rows.append([
            f"{item.get('horizon', '')}{flag}",
            str(item.get("direction", "neutral")),
            fmt_ratio(item.get("probability_up")),
            fmt_ratio(item.get("probability_flat")),
            fmt_ratio(item.get("probability_down")),
            fmt_pct(item.get("median_return_pct")),
            interval,
            fmt_ratio(item.get("confidence")),
            str(item.get("quality", "")),
        ])
        provenance.append(
            f"{item.get('horizon', '')}：样本 {int(item.get('sample_size') or 0)}、"
            f"有效样本 {fmt_num(item.get('effective_sample_size'), 1)}、"
            f"Brier 技能分 {fmt_num(item.get('skill_score'), 3)}、方法 {item.get('method', '')}"
        )

    blocks: List[Any] = [
        Table(
            header=["周期", "方向", "上涨概率", "震荡概率", "下跌概率", "中位收益", "90%区间", "置信度", "质量"],
            rows=rows,
            align=["left", "center", "right", "right", "right", "right", "center", "right", "center"],
            narrow_drop=[3, 4, 7],  # 幻灯片只留 上涨/下跌/中位收益/区间
        )
    ]
    blocks.append(Bullets(provenance))
    blocks.append(Callout("概率来自历史条件样本的非参数估计；样本不足或校准不佳时会标记弃权，不强行给方向。"))
    return Section("二、多周期概率预测", blocks)


def _factor_section(aa: Dict[str, Any]) -> Section:
    blocks: List[Any] = []
    factors = list(aa.get("factors") or [])
    if factors:
        rows = []
        for f in factors:
            item: Dict[str, Any] = _as_dict(f)
            rows.append([
                str(item.get("name", "")),
                str(item.get("category", "")),
                fmt_num(item.get("score"), 1),
                fmt_num(item.get("weight"), 2),
                fmt_ratio(item.get("confidence")),
                ", ".join(item.get("evidence_ids") or []) or "—",
                str(item.get("rationale", "")),
            ])
        blocks.append(Table(
            header=["因子", "类别", "方向分", "权重", "置信度", "证据", "说明"],
            rows=rows,
            align=["left", "left", "right", "right", "right", "left", "left"],
            narrow_drop=[1, 3, 4, 6],
        ))
    else:
        blocks.append(Paragraph("未形成因子打分（数据不足或被弃权）。"))

    metrics = aa.get("metrics") or {}
    if metrics:
        blocks.append(Heading("关键指标", level=3))
        blocks.append(MetricGrid([(str(k), _metric_text(v)) for k, v in list(metrics.items())[:24]]))

    conflicts = list(aa.get("conflicts") or [])
    if conflicts:
        blocks.append(Heading("冲突信号", level=3))
        blocks.append(Bullets(conflicts))
    return Section("三、因子与证据", blocks)


def _metric_text(value: Any) -> str:
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, int):
        return f"{value:,}"
    if isinstance(value, float):
        text = f"{value:.4f}".rstrip("0").rstrip(".")
        return text or "0"
    if isinstance(value, (dict, list)):
        import json as _json

        return _json.dumps(value, ensure_ascii=False, default=str)[:160]
    text = str(value)
    return text[:160] + "…" if len(text) > 160 else text


def _scenario_section(scenarios: List[Any]) -> Section:
    if not scenarios:
        return Section("四、情景分析", [Paragraph("未生成情景分析。")])
    rows = []
    for s in scenarios:
        item: Dict[str, Any] = _as_dict(s)
        rng = item.get("price_range") or [0, 0]
        low, high = (list(rng) + [0, 0])[:2]
        rows.append([
            str(item.get("name", "")),
            fmt_ratio(item.get("probability")),
            fmt_pct(item.get("return_pct")),
            f"{fmt_num(low)} ~ {fmt_num(high)}" if high else "—",
            "；".join(item.get("assumptions") or []) or "—",
        ])
    return Section("四、情景分析", [
        Table(header=["情景", "概率", "收益假设", "价格区间", "主要假设"], rows=rows,
              align=["left", "right", "right", "center", "left"])
    ])


def _risk_section(data: Dict[str, Any]) -> Section:
    blocks: List[Any] = []
    risks = list(data.get("risks") or [])
    if risks:
        blocks.append(Heading("主要风险", level=3))
        blocks.append(Bullets(risks))
    counterpoints = list(data.get("counterpoints") or [])
    if counterpoints:
        blocks.append(Heading("反方证据 / 冲突", level=3))
        blocks.append(Bullets(counterpoints))

    dq: Dict[str, Any] = _as_dict(data.get("data_quality") or {})
    blocks.append(Heading("数据质量", level=3))
    blocks.append(MetricGrid([
        ("数据状态", str(dq.get("status", "unknown"))),
        ("完整度", fmt_ratio(dq.get("completeness"))),
        ("质量分", fmt_ratio(dq.get("score"))),
        ("时效", str(dq.get("freshness", ""))),
        ("来源", ", ".join(dq.get("sources") or []) or "—"),
        ("缺失项", ", ".join(dq.get("missing") or []) or "无"),
    ]))
    warnings = list(dq.get("warnings") or []) + list(data.get("warnings") or [])
    for warning in warnings:
        blocks.append(Callout(str(warning), kind="warning"))
    if not (risks or counterpoints or warnings):
        blocks.append(Paragraph("本轮未记录显著风险项，不等于没有风险；请以自身研究与风控为准。"))
    return Section("五、风险、反方证据与数据质量", blocks)


def _evidence_section(evidence: List[Any]) -> Section:
    if not evidence:
        return Section("六、证据链", [Paragraph("无可用证据。")])
    rows = []
    for e in evidence:
        item: Dict[str, Any] = _as_dict(e)
        value = str(item.get("value", "")).replace("|", "｜")
        rows.append([
            str(item.get("evidence_id", "")),
            str(item.get("kind", "")),
            str(item.get("source", "")),
            str(item.get("observed_at", "")),
            str(item.get("quality", "")),
            value[:160] + "…" if len(value) > 160 else value,
        ])
    blocks: List[Any] = [Table(
        header=["ID", "类型", "来源", "观测时间", "质量", "证据"],
        rows=rows,
        align=["left", "left", "left", "left", "left", "left"],
        narrow_drop=[1, 3, 4],
    )]
    blocks.append(Callout(f"共 {len(rows)} 条证据；结论中的每一项都可回溯到上表的 ID。"))
    return Section("六、证据链", blocks)


def _method_section(data: Dict[str, Any]) -> Section:
    methodology = list(data.get("methodology") or [])
    blocks: List[Any] = [Bullets(methodology)] if methodology else [
        Paragraph("多周期概率由历史相似条件下的非参数样本估计；分析与预测分开陈述，预测均带样本量与质量标记。")
    ]
    blocks.append(Callout(
        f"报告 schema {data.get('schema_version', '')}｜运行 {data.get('run_id', '')}｜IR {IR_VERSION}",
        kind="note",
    ))
    return Section("七、方法与限制", blocks)
