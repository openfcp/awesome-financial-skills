# -*- coding: utf-8 -*-
"""口语指令解析（纯文本，零子进程）。

从 v9.4 的 voice_interface 拆出来：市场评审点名的是"SAPI 兜底会起 PowerShell 子
进程"，而把中文口语解析成结构化命令这部分只有正则和字典，是 CLI/Agent 路由口语指
令的核心内容。拆开后上架包可以只带本模块，把 voice_interface 留在源码树里。
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional

__all__ = ["parse_voice_command", "summarize_for_speech"]

# 常见口语标的 → 标准代码
_CODE_ALIASES = {
    "茅台": "600519", "贵州茅台": "600519",
    "腾讯": "hk:00700", "宁德时代": "300750",
    "中国平安": "601318", "招商银行": "600036",
    "比亚迪": "002594", "五粮液": "000858",
    "上证指数": "idx:SSE", "上证": "idx:SSE", "大盘": "idx:SSE",
    "沪深300": "idx:HS300", "恒生指数": "idx:HSI", "恒指": "idx:HSI",
    "纳斯达克": "idx:IXIC", "纳指": "idx:IXIC",
    "标普": "idx:SPX", "标普500": "idx:SPX",
    "日经": "idx:N225", "黄金": "gold:comex", "原油": "crude:wti",
    "苹果": "us:AAPL", "英伟达": "us:NVDA", "特斯拉": "us:TSLA",
}

_MARKET_WORDS = {"a股": "cn", "港股": "hk", "美股": "us"}


# ─── 播报文本压缩 ───────────────────────────────────────────────────────────


def summarize_for_speech(reply: str, max_chars: int = 300) -> str:
    """把文本结果压缩为适合播报的口语文本。

    去 Markdown 记号/URL/表情，中文间空白压缩，超长截断到句尾并附提示。
    """
    if not reply:
        return ""
    txt = re.sub(r"```[\s\S]*?```", " 代码块省略 ", reply)
    txt = re.sub(r"https?://\S+", "", txt)
    txt = re.sub(r"[*#>`|_\-=~]+", " ", txt)
    txt = re.sub(r"\s+", " ", txt)
    txt = re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])", "", txt)
    txt = txt.strip()
    if len(txt) <= max_chars:
        return txt
    cut = txt[:max_chars]
    for sep in ("。", "；", "，", " "):
        idx = cut.rfind(sep)
        if idx >= max_chars // 2:
            cut = cut[: idx + 1]
            break
    return cut.rstrip("，； ") + "（更多内容见终端输出）"


# ─── 自然语言命令解析 ───────────────────────────────────────────────────────


def parse_voice_command(text: str) -> Dict[str, Any]:
    """把口语指令解析为结构化命令。

    返回 {"intent": ..., "code": ..., "params": {...}, "echo": 确认语}。
    intent 取值: predict/quant_check/sector_ranking/index_regime/scenario/
    topdown/masters/kb_save/kb_search/kb_quant/help/exit/unknown。
    """
    s = (text or "").strip()
    low = s.lower()
    out: Dict[str, Any] = {"intent": "unknown", "code": None,
                           "params": {}, "echo": ""}
    if not s:
        return out
    if re.search(r"退出|再见|结束|停止|bye", s):
        out.update(intent="exit", echo="好的，已退出。")
        return out
    if re.search(r"帮助|怎么用|帮助我|使用说明|help", low):
        out.update(intent="help", echo="支持：预测某只股票、量化体检、板块排名、指数体制、情景分析、自上而下全景、大佬圆桌、保存分析到知识库、查询知识库。")
        return out

    # 1) 提取代码/别名
    code: Optional[str] = None
    for alias, std in sorted(_CODE_ALIASES.items(), key=lambda kv: -len(kv[0])):
        if alias in s:
            code = std
            break
    if code is None:
        m = re.search(r"(?:代码|股票)?[:：]?\s*((?:hk|us|idx|gold|silver|crude|sh|sz)?:?\s*\d{4,6}(?:\.(?:HK|SS|SZ))?(?:\.US)?)", s, re.I)
        if m:
            code = re.sub(r"\s+", "", m.group(1))
        else:
            # 美股代码：需上下文明确（us:/美股/US），不用 \b（中文也是单词字符）
            m = re.search(r"([A-Za-z]{1,5})", s)
            if m and re.search(r"us:|美股|US", s):
                code = "us:" + m.group(1).upper()

    # 2) 意图判别（按特异性从高到低）
    # v9.7 知识库交互：保存分析/检索笔记/回读量化（关键词优先判别）
    # v9.8 支持口语指定 12 适配器目标（如“保存到 ragflow 知识库”）
    if re.search(r"知识库|笔记", s):
        target = ""
        for word, t in (("ragflow", "ragflow"), ("fastgpt", "fastgpt"),
                        ("maxkb", "maxkb"), ("语雀", "yuque"), ("飞书", "feishu"),
                        ("notion", "notion"), ("思源", "siyuan"),
                        ("logseq", "logseq"), ("obsidian", "obsidian"),
                        ("ima", "ima"), ("dify", "dify")):
            if word in low:
                target = t
                break
        query = re.sub(r"知识库|笔记|查一下|查询|搜索|搜一下|找一下|查找|读取|回顾"
                       r"|帮我|请|把|将|到|里|中|的"
                       r"|ragflow|fastgpt|maxkb|语雀|飞书|notion|思源"
                       r"|logseq|obsidian|ima|dify|本地", "", s).strip()
        if re.search(r"体检|量化|形态|预测分析", s):
            out.update(intent="kb_quant",
                       params={"query": query or (code or ""),
                               "target": target or None},
                       echo=f"从知识库回读数据做量化分析：{query or code or '全部'}。")
        elif re.search(r"保存|存档|入库|同步|记下来", s):
            if code:
                out.update(intent="kb_save", code=code,
                           params={"target": target or None},
                           echo=f"开始分析并保存到知识库：{code}。")
            else:
                out.update(intent="kb_save",
                           echo="请告诉我要保存哪只股票到知识库，比如：把茅台保存到知识库。")
        else:
            out.update(intent="kb_search",
                       params={"query": query or (code or ""),
                               "target": target or None},
                       echo=f"开始检索知识库：{query or code or '全部'}。")
        return out
    if re.search(r"板块.{0,4}(排名|强度|比较)|板块排名", s):
        market = "cn"
        for word, mk in _MARKET_WORDS.items():
            if word in low:
                market = mk
                break
        out.update(intent="sector_ranking", params={"market": market},
                   echo=f"开始{market.upper()}板块相对强度排名。")
        return out
    if re.search(r"(指数|大盘|市场).{0,4}(体制|状态)|体制分类", s):
        out.update(intent="index_regime", code=code or "sh000001",
                   echo=f"开始分析指数市场体制：{code or 'sh000001'}。")
        return out
    if re.search(r"情景|压力测试|宏观假设", s):
        out.update(intent="scenario",
                   echo="开始宏观情景概率加权分析。")
        return out
    if re.search(r"自上而下|全景|总览|市场全貌", s):
        market = "cn"
        for word, mk in _MARKET_WORDS.items():
            if word in low:
                market = mk
                break
        out.update(intent="topdown", params={"market": market},
                   echo=f"开始生成{market.upper()}自上而下全景报告。")
        return out
    if re.search(r"体检|量化指标|回撤|夏普", s):
        if code:
            out.update(intent="quant_check", code=code,
                       echo=f"开始量化体检：{code}。")
        else:
            out.update(intent="quant_check",
                       echo="请告诉我体检哪只股票或指数。")
        return out
    if re.search(r"大佬|大师|圆桌|高手们|名人", s):
        if code:
            out.update(intent="masters", code=code,
                       echo=f"开始大佬圆桌：{code}。")
        else:
            out.update(intent="masters",
                       echo="请告诉我圆桌讨论哪只股票，比如：大佬们怎么看茅台。")
        return out
    if re.search(r"预测|分析|看看|怎么样|走势|行情|研报|涨跌", s):
        if code:
            out.update(intent="predict", code=code,
                       echo=f"开始分析：{code}。")
        else:
            out.update(intent="predict",
                       echo="请告诉我要分析哪只股票，比如：预测茅台。")
        return out
    # 仅有代码时也默认预测
    if code:
        out.update(intent="predict", code=code, echo=f"开始分析：{code}。")
        return out
    out["echo"] = "没听懂指令，说“帮助”可查看支持的功能。"
    return out
