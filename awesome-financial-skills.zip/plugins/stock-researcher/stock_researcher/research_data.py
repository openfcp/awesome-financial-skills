﻿# -*- coding: utf-8 -*-
"""v12.0 数据获取、归一化与任意数据集摄入。

覆盖：
- 实时/历史行情归一化（股票、ETF/基金、期货）
- 基金官方净值 + 盘中估值（估值绝不冒充官方净值）
- 期货报价/历史/期限结构输入
- CSV/TSV/JSON/JSONL/XLSX/TXT/MD 与受限 URL 摄入
- 超时、重试、大小限制、数据质量标记
"""
from __future__ import annotations

import csv
import hashlib
import ipaddress
import json
import logging
import math
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from stock_researcher.research_contracts import (
    CN_TZ, FundSnapshot, FuturesContract, FuturesCurve, MarketQuote,
    PriceSeries, finite, now_iso, parse_datetime, safe_float, stable_hash, to_iso,
)

MAX_DOWNLOAD_BYTES = 12 * 1024 * 1024
DEFAULT_TIMEOUT = 10.0
# 单个 URL 的重试总预算（含退避）。不设上限时 3 次 × 10s 会卡住 31s，
# 上层多源降级串起来就是分钟级假死；预算到了就把控制权还给路由器。
URL_TIME_BUDGET = 16.0
HTTP_MAX_ATTEMPTS = 3
USER_AGENT = "Mozilla/5.0 (compatible; stock-researcher-v12; research use)"


class DataAccessError(RuntimeError):
    """可预期的数据访问错误。"""


LOG = logging.getLogger("stock_researcher.research_data")


def _enable_direct_connection_if_set() -> bool:
    """腾讯/东财接口需国内直连，但改写全局 opener 是进程级副作用。

    所以只在联网这一刻按显式开关生效：没设 STOCK_RESEARCHER_DIRECT_CONNECT 时
    完全不动 urllib 的全局 opener。
    """
    try:
        from stock_researcher.data_proxy_guard import enable_direct_connection_from_env
        return enable_direct_connection_from_env()
    except Exception as exc:  # 防护模块坏了不能拖垮取数
        LOG.debug("直连开关检查失败: %s", exc)
        return False


def _http_get(url: str, headers: Optional[Dict[str, str]] = None,
              timeout: float = DEFAULT_TIMEOUT, max_bytes: int = MAX_DOWNLOAD_BYTES,
              budget: float = URL_TIME_BUDGET) -> bytes:
    h = {"User-Agent": USER_AGENT, "Accept": "application/json,text/plain,*/*"}
    h.update(headers or {})
    _enable_direct_connection_if_set()
    last_err: Optional[Exception] = None
    deadline = time.monotonic() + max(timeout, budget)
    for attempt in range(HTTP_MAX_ATTEMPTS):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            last_err = last_err or DataAccessError("超出单 URL 时间预算")
            break
        try:
            req = urllib.request.Request(url, headers=h)
            with urllib.request.urlopen(req, timeout=min(timeout, remaining)) as resp:
                length = resp.headers.get("Content-Length")
                if length and int(length) > max_bytes:
                    raise DataAccessError(f"响应过大: {length} bytes")
                body = resp.read(max_bytes + 1)
                if len(body) > max_bytes:
                    raise DataAccessError("响应超过下载上限")
                return body
        except Exception as exc:  # 网络错误只在幂等 GET 上重试
            last_err = exc
            if attempt < HTTP_MAX_ATTEMPTS - 1:
                left = deadline - time.monotonic()
                if left <= 0:
                    break
                time.sleep(min((2 ** attempt) * 0.4, left))
    raise DataAccessError(str(last_err)[:240])


def _decode_bytes(body: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk"):
        try:
            return body.decode(enc)
        except UnicodeDecodeError:
            continue
    return body.decode("utf-8", errors="replace")


def _parse_json_text(text: str) -> Any:
    text = text.strip()
    if text.startswith("\ufeff"):
        text = text.lstrip("\ufeff")
    # JSONP: callback({...});
    m = re.match(r"^[\w$.]+\s*\((.*)\)\s*;?\s*$", text, flags=re.S)
    if m:
        text = m.group(1)
    return json.loads(text)


@dataclass
class Dataset:
    """一次用户数据摄入的不可变描述。"""
    name: str
    records: List[Dict[str, Any]]
    columns: List[str] = field(default_factory=list)
    source_path: str = ""
    source_hash: str = ""
    row_count: int = 0
    rejected_rows: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    as_of: str = ""
    mapping: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.row_count = len(self.records)
        if not self.columns and self.records:
            seen: List[str] = []
            for row in self.records:
                for key in row:
                    if key not in seen:
                        seen.append(key)
            self.columns = seen
        if not self.as_of:
            self.as_of = now_iso()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "columns": self.columns,
            "source_path": self.source_path,
            "source_hash": self.source_hash,
            "row_count": self.row_count,
            "rejected_rows": self.rejected_rows[:50],
            "warnings": self.warnings,
            "as_of": self.as_of,
            "mapping": self.mapping,
            "preview": self.records[:5],
        }


COLUMN_ALIASES: Dict[str, Tuple[str, ...]] = {
    "date": ("date", "datetime", "time", "trade_date", "trading_date", "日期", "交易日期", "时间"),
    "datetime": ("datetime", "timestamp", "time", "日期时间", "时间戳"),
    "open": ("open", "open_price", "开盘", "开盘价"),
    "high": ("high", "high_price", "最高", "最高价"),
    "low": ("low", "low_price", "最低", "最低价"),
    "close": ("close", "close_price", "price", "last", "nav", "unit_nav", "收盘", "收盘价", "价格", "单位净值", "净值"),
    "volume": ("volume", "vol", "成交量", "交易量"),
    "amount": ("amount", "turnover_value", "成交额", "成交金额"),
    "open_interest": ("open_interest", "oi", "hold", "持仓量", "持仓"),
    "spot": ("spot", "spot_price", "basis_spot", "现货价", "现货价格"),
}


def _canonical_column(name: str) -> Optional[str]:
    key = str(name).strip().lower().replace(" ", "").replace("_", "")
    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if key == alias.lower().replace(" ", "").replace("_", ""):
                return canonical
    return None


def infer_column_mapping(columns: Sequence[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for col in columns:
        canonical = _canonical_column(str(col))
        if canonical and canonical not in out:
            out[canonical] = str(col)
    return out

class DatasetLoader:
    """把本地文件或用户记录转换为统一 Dataset/PriceSeries。"""

    SUPPORTED = (".csv", ".tsv", ".json", ".jsonl", ".xlsx", ".xlsm", ".txt", ".md", ".pdf")

    @classmethod
    def load(cls, path: str, encoding: str = "") -> Dataset:
        p = Path(path).expanduser()
        if not p.exists():
            raise DataAccessError(f"文件不存在: {p}")
        if p.stat().st_size > MAX_DOWNLOAD_BYTES:
            raise DataAccessError("文件超过 12MB 摄入上限")
        raw = p.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        suffix = p.suffix.lower()
        if suffix in (".csv", ".tsv"):
            records, warnings = cls._read_delimited(raw, encoding=encoding,
                                                    delimiter="\t" if suffix == ".tsv" else None)
        elif suffix == ".json":
            records, warnings = cls._read_json(raw, encoding=encoding)
        elif suffix == ".jsonl":
            records, warnings = cls._read_jsonl(raw, encoding=encoding)
        elif suffix in (".xlsx", ".xlsm"):
            records, warnings = cls._read_xlsx(p)
        elif suffix == ".pdf":
            records, warnings = cls._read_pdf(p)
        elif suffix in (".txt", ".md"):
            text = raw.decode(encoding or "utf-8", errors="replace")
            records = [{"content": text, "title": p.stem}]
            warnings = []
        else:
            raise DataAccessError(f"不支持的文件类型: {suffix}；支持 {', '.join(cls.SUPPORTED)}")
        columns = list(records[0].keys()) if records else []
        return Dataset(name=p.name, records=records, columns=columns,
                       source_path=str(p.resolve()), source_hash=digest,
                       warnings=warnings, as_of=datetime.fromtimestamp(
                           p.stat().st_mtime, CN_TZ).isoformat(timespec="seconds"),
                       mapping=infer_column_mapping(columns))

    @classmethod
    def from_records(cls, records: Iterable[Dict[str, Any]], name: str = "user_input") -> Dataset:
        rows = [dict(r) for r in records if isinstance(r, dict)]
        if not rows:
            raise DataAccessError("没有可用的记录")
        payload = json.dumps(rows, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
        return Dataset(name=name, records=rows, columns=list(rows[0].keys()),
                       source_hash=hashlib.sha256(payload).hexdigest(),
                       mapping=infer_column_mapping(list(rows[0].keys())))

    @staticmethod
    def _read_delimited(raw: bytes, encoding: str = "", delimiter: Optional[str] = None) -> Tuple[List[Dict[str, Any]], List[str]]:
        text = raw.decode(encoding or "utf-8-sig", errors="replace")
        if not encoding:
            for candidate in ("utf-8-sig", "gb18030", "gbk"):
                try:
                    text = raw.decode(candidate)
                    break
                except UnicodeDecodeError:
                    continue
        sample = text[:4096]
        if delimiter is None:
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
                delimiter = dialect.delimiter
            except csv.Error:
                delimiter = ","
        reader = csv.DictReader(text.splitlines(), delimiter=delimiter)
        records = []
        bad = []
        for row_no, row in enumerate(reader, start=2):
            clean = {str(k).strip(): (v.strip() if isinstance(v, str) else v) for k, v in row.items() if k is not None}
            if not clean or all(v in (None, "") for v in clean.values()):
                bad.append({"row": row_no, "reason": "空行"})
                continue
            records.append(clean)
        warnings = [f"跳过 {len(bad)} 个空行"] if bad else []
        return records, warnings

    @staticmethod
    def _read_json(raw: bytes, encoding: str = "") -> Tuple[List[Dict[str, Any]], List[str]]:
        text = raw.decode(encoding or "utf-8-sig", errors="replace")
        data = _parse_json_text(text)
        return DatasetLoader._coerce_json_records(data)

    @staticmethod
    def _read_jsonl(raw: bytes, encoding: str = "") -> Tuple[List[Dict[str, Any]], List[str]]:
        text = raw.decode(encoding or "utf-8-sig", errors="replace")
        records, warnings = [], []
        for line_no, line in enumerate(text.splitlines(), start=1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                warnings.append(f"第 {line_no} 行 JSON 无效: {exc.msg}")
                continue
            if isinstance(item, dict):
                records.append(item)
            else:
                warnings.append(f"第 {line_no} 行不是对象，已跳过")
        return records, warnings

    @staticmethod
    def _coerce_json_records(data: Any) -> Tuple[List[Dict[str, Any]], List[str]]:
        warnings: List[str] = []
        if isinstance(data, dict):
            for key in ("data", "records", "rows", "items", "result", "list"):
                if isinstance(data.get(key), list):
                    data = data[key]
                    warnings.append(f"已展开顶层字段 {key}")
                    break
            else:
                data = [data]
        if not isinstance(data, list):
            raise DataAccessError("JSON 顶层必须是数组，或包含 data/records/rows 数组")
        records = []
        for idx, item in enumerate(data):
            if isinstance(item, dict):
                records.append(item)
            else:
                warnings.append(f"第 {idx + 1} 项不是对象，已跳过")
        return records, warnings

    @staticmethod
    def _read_xlsx(path: Path) -> Tuple[List[Dict[str, Any]], List[str]]:
        try:
            import openpyxl  # type: ignore
        except ImportError as exc:
            raise DataAccessError("读取 XLSX 需要可选依赖 openpyxl；当前环境未安装，请另存为 CSV") from exc
        wb = openpyxl.load_workbook(filename=str(path), read_only=True, data_only=True)
        try:
            ws = wb.active
            rows = ws.iter_rows(values_only=True)
            try:
                headers = [str(x).strip() if x is not None else f"col{i+1}" for i, x in enumerate(next(rows))]
            except StopIteration:
                return [], ["工作表为空"]
            records: List[Dict[str, Any]] = []
            warnings: List[str] = []
            for row_no, values in enumerate(rows, start=2):
                if values is None or all(v is None or v == "" for v in values):
                    continue
                rec = {headers[i] if i < len(headers) else f"col{i+1}": v for i, v in enumerate(values)}
                records.append(rec)
            warnings.append("公式按 data_only=True 读取缓存值；不会执行宏或公式")
            return records, warnings
        finally:
            wb.close()

    @staticmethod
    def _read_pdf(path: Path) -> Tuple[List[Dict[str, Any]], List[str]]:
        try:
            from pypdf import PdfReader  # type: ignore
        except ImportError:
            try:
                from PyPDF2 import PdfReader  # type: ignore
            except ImportError as exc:
                raise DataAccessError("读取 PDF 需要可选依赖 pypdf/PyPDF2；当前环境未安装") from exc
        reader = PdfReader(str(path))
        records = []
        warnings = []
        for idx, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                records.append({"page": idx, "content": text, "title": f"{path.stem} 第{idx}页"})
            else:
                warnings.append(f"第 {idx} 页无可提取文本（扫描件需 OCR，本工具不承诺 OCR）")
        return records, warnings

    @classmethod
    def load_url(cls, url: str, timeout: float = DEFAULT_TIMEOUT) -> Dataset:
        """受限 URL 摄入：仅公网 http/https，阻断私网/重定向到私网。"""
        _validate_public_url(url)
        handlers = [urllib.request.ProxyHandler({}), _PublicOnlyRedirectHandler()]
        opener = urllib.request.build_opener(*handlers)
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT,
                                                   "Accept": "application/json,text/csv,text/plain,*/*"})
        try:
            with opener.open(req, timeout=timeout) as resp:
                _validate_public_url(resp.geturl())
                length = resp.headers.get("Content-Length")
                if length and int(length) > MAX_DOWNLOAD_BYTES:
                    raise DataAccessError("URL 内容超过 12MB 上限")
                body = resp.read(MAX_DOWNLOAD_BYTES + 1)
                if len(body) > MAX_DOWNLOAD_BYTES:
                    raise DataAccessError("URL 内容超过 12MB 上限")
                content_type = (resp.headers.get("Content-Type") or "").lower()
                final_url = resp.geturl()
        except DataAccessError:
            raise
        except Exception as exc:
            raise DataAccessError(f"URL 获取失败: {str(exc)[:200]}") from exc
        path = urllib.parse.urlparse(final_url).path.lower()
        if "json" in content_type or path.endswith(".json"):
            records, warnings = cls._read_json(body)
        elif "csv" in content_type or path.endswith((".csv", ".tsv")):
            records, warnings = cls._read_delimited(body)
        elif "html" in content_type or path.endswith((".html", ".htm")):
            text = _HTMLTextExtractor().extract(_decode_bytes(body))
            records, warnings = [{"content": text, "title": final_url}], ["网页仅提取可见文本，脚本样式已忽略"]
        else:
            text = _decode_bytes(body)
            records, warnings = [{"content": text, "title": final_url}], []
        return Dataset(name=urllib.parse.urlparse(final_url).path.rsplit("/", 1)[-1] or "url_input",
                       records=records, columns=list(records[0].keys()) if records else [],
                       source_path=final_url, source_hash=hashlib.sha256(body).hexdigest(),
                       warnings=warnings, as_of=now_iso(),
                       mapping=infer_column_mapping(list(records[0].keys()) if records else []))

    @staticmethod
    def to_price_series(dataset: Dataset, symbol: str, asset_type: str = "stock",
                        market: str = "cn", mapping: Optional[Dict[str, str]] = None) -> PriceSeries:
        mapping = dict(mapping or dataset.mapping)
        close_col = mapping.get("close")
        if not close_col:
            raise DataAccessError("无法识别收盘价/净值列；请显式提供 mapping={'close': '列名'}")
        date_col = mapping.get("date")
        rows = []
        rejected = []
        for idx, rec in enumerate(dataset.records, start=1):
            close = safe_float(rec.get(close_col), None)
            if close is None or close <= 0:
                rejected.append({"row": idx, "reason": f"{close_col} 非正数或不可解析"})
                continue
            rows.append((idx, rec, close))
        if not rows:
            raise DataAccessError("没有通过质量校验的价格行")
        parsed_dates = [parse_datetime(rec.get(date_col)) if date_col else None for _, rec, _ in rows]
        if date_col and all(parsed_dates):
            order = sorted(range(len(rows)), key=lambda i: parsed_dates[i])
            rows = [rows[i] for i in order]
            parsed_dates = [parsed_dates[i] for i in order]
        dates = [to_iso(d) if d else str(rows[i][1].get(date_col, "")) for i, d in enumerate(parsed_dates)]
        closes = [r[2] for r in rows]

        def col(name: str, fallback: float = 0.0) -> List[float]:
            c = mapping.get(name)
            if not c:
                return [fallback] * len(rows)
            out = []
            for _, rec, _ in rows:
                val = safe_float(rec.get(c), None)
                out.append(val if val is not None else fallback)
            return out

        warnings = list(dataset.warnings)
        if not mapping.get("high") or not mapping.get("low"):
            warnings.append("未提供最高/最低价，ATR 使用收盘价近似")
        if not mapping.get("open"):
            warnings.append("未提供开盘价，开盘价以收盘价替代")
        if not mapping.get("volume"):
            warnings.append("未提供成交量，量价因子降权")
        highs = col("high") if mapping.get("high") else list(closes)
        lows = col("low") if mapping.get("low") else list(closes)
        opens = col("open") if mapping.get("open") else list(closes)
        volumes = col("volume")
        amounts = col("amount")
        quality = "actual"
        if warnings:
            quality = "derived"
        series = PriceSeries(
            symbol=symbol, asset_type=asset_type, market=market, dates=dates,
            opens=opens, highs=highs, lows=lows, closes=closes,
            volumes=volumes, amounts=amounts, source=f"file:{dataset.name}",
            quality=quality, as_of=dates[-1] if dates else dataset.as_of,
            warnings=warnings,
        )
        dataset.rejected_rows = rejected[:50]
        return series


class _PublicOnlyRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _validate_public_url(url: str) -> None:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise DataAccessError("仅允许 http/https URL")
    if not parsed.hostname:
        raise DataAccessError("URL 缺少主机名")
    if parsed.username or parsed.password:
        raise DataAccessError("URL 不允许包含用户名/密码")
    try:
        infos = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80))
    except socket.gaierror as exc:
        raise DataAccessError(f"域名解析失败: {parsed.hostname}") from exc
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
                or ip.is_multicast or ip.is_unspecified):
            raise DataAccessError("禁止访问私网/环回/保留地址")


class _HTMLTextExtractor:
    def extract(self, html: str) -> str:
        from html.parser import HTMLParser

        class Parser(HTMLParser):
            def __init__(self):
                super().__init__()
                self.parts: List[str] = []
                self.skip = 0

            def handle_starttag(self, tag, attrs):
                if tag in ("script", "style", "noscript"):
                    self.skip += 1

            def handle_endtag(self, tag):
                if tag in ("script", "style", "noscript") and self.skip:
                    self.skip -= 1

            def handle_data(self, data):
                if not self.skip and data.strip():
                    self.parts.append(data.strip())

        parser = Parser()
        parser.feed(html)
        return "\n".join(parser.parts)

_QUOTE_ALIASES = {
    "price": ("price", "current", "last", "last_price", "current_price", "close", "f2", "f43"),
    "prev_close": ("prev_close", "pre_close", "previous_close", "yesterday_close", "f60"),
    "open": ("open", "open_price", "f46"),
    "high": ("high", "high_price", "f44"),
    "low": ("low", "low_price", "f45"),
    "volume": ("volume", "vol", "f47", "f5"),
    "amount": ("amount", "turnover_value", "f48", "f6"),
    "change_pct": ("change_pct", "pct_chg", "percent", "chg_pct", "f3", "f170"),
    "name": ("name", "stock_name", "f58", "f14"),
    "code": ("code", "symbol", "f57", "f12"),
    "timestamp": ("timestamp", "time", "datetime", "f86", "snapshot_at"),
}


def _unwrap_payload(data: Any) -> Any:
    if isinstance(data, list):
        return data
    if not isinstance(data, dict):
        return data
    for key in ("data", "result", "quote"):
        nested = data.get(key)
        if isinstance(nested, (dict, list)):
            if isinstance(nested, dict) and isinstance(nested.get("diff"), list):
                return nested["diff"]
            return nested
    return data


def _pick(data: Dict[str, Any], aliases: Iterable[str]) -> Any:
    for key in aliases:
        if key in data and data[key] not in (None, "", "-", "--"):
            return data[key]
    lower = {str(k).lower(): v for k, v in data.items()}
    for key in aliases:
        if key.lower() in lower and lower[key.lower()] not in (None, "", "-", "--"):
            return lower[key.lower()]
    return None


def normalize_quote_data(data: Any, symbol: str, asset_type: str = "stock",
                         market: str = "cn", source: str = "") -> MarketQuote:
    """把不同数据源的原始行情归一化为 MarketQuote。"""
    if hasattr(data, "to_dict"):
        try:
            data = data.to_dict("records")
        except Exception:
            pass
    payload = _unwrap_payload(data)
    mismatch = ""
    if isinstance(payload, list):
        chosen = None
        bare = re.sub(r"^(cn|hk|us|idx):", "", symbol, flags=re.I).upper()
        for item in payload:
            if not isinstance(item, dict):
                continue
            code = str(_pick(item, _QUOTE_ALIASES["code"]) or "").upper()
            if code and (code == bare or code.endswith(bare) or bare.endswith(code)):
                chosen = item
                break
        if chosen is None:
            # 单行表就是按这只票查出来的，可以直接采信；
            # 多行表匹配不上时不能拿第一行冒充——那会把别的证券的价格挂到本代码上。
            if len(payload) == 1 and isinstance(payload[0], dict):
                chosen = payload[0]
            elif payload:
                mismatch = f"返回 {len(payload)} 行但未匹配到代码 {symbol}，已放弃首行兜底"
        payload = chosen or {}
    if not isinstance(payload, dict):
        return MarketQuote(symbol=symbol, asset_type=asset_type, market=market,
                           source=source, warnings=["原始行情不是对象"])
    price = safe_float(_pick(payload, _QUOTE_ALIASES["price"]), None)
    prev_close = safe_float(_pick(payload, _QUOTE_ALIASES["prev_close"]), None)
    open_price = safe_float(_pick(payload, _QUOTE_ALIASES["open"]), None)
    high = safe_float(_pick(payload, _QUOTE_ALIASES["high"]), None)
    low = safe_float(_pick(payload, _QUOTE_ALIASES["low"]), None)
    change_pct = safe_float(_pick(payload, _QUOTE_ALIASES["change_pct"]), None)
    # 东财 f43/f44/f45/f46/f60 常用整数放大 100 倍；只在明显不可能时统一修正。
    derived = False
    if price is not None and price > 10_000 and "f43" in payload:
        for value in (price, prev_close, open_price, high, low):
            if value is not None:
                value = value / 100.0
        price, prev_close = price / 100.0, (prev_close / 100.0 if prev_close is not None else None)
        open_price = open_price / 100.0 if open_price is not None else None
        high = high / 100.0 if high is not None else None
        low = low / 100.0 if low is not None else None
        derived = True
    if change_pct is not None and "f170" in payload and abs(change_pct) > 50:
        change_pct = change_pct / 100.0
        derived = True
    quality = "derived" if derived else ("actual" if price else "unavailable")
    warnings = ["东财字段按 100 倍缩放修正"] if derived else []
    if mismatch:
        warnings.append(mismatch)
    if price and high and low and not (high >= price >= low):
        warnings.append("OHLC 关系异常：最新价不在最高/最低之间")
        quality = "suspect"
    return MarketQuote(
        symbol=symbol,
        name=str(_pick(payload, _QUOTE_ALIASES["name"]) or ""),
        asset_type=asset_type, market=market, price=price,
        prev_close=prev_close, open=open_price, high=high, low=low,
        volume=safe_float(_pick(payload, _QUOTE_ALIASES["volume"]), None),
        amount=safe_float(_pick(payload, _QUOTE_ALIASES["amount"]), None),
        change_pct=change_pct,
        timestamp=to_iso(_pick(payload, _QUOTE_ALIASES["timestamp"])) if _pick(payload, _QUOTE_ALIASES["timestamp"]) else now_iso(),
        source=source or str(payload.get("source", "")), freshness="realtime" if price else "unavailable",
        quality=quality, warnings=warnings, raw=payload,
    )


def infer_market(symbol: str) -> Tuple[str, str, str]:
    """返回 (market, clean_symbol, asset_type)。"""
    s = str(symbol).strip()
    low = s.lower()
    if low.startswith("idx:"):
        return "global" if not re.match(r"idx:\d{6}", low) else "cn", s.split(":", 1)[1], "index"
    if low.startswith("hk:"):
        return "hk", s.split(":", 1)[1], "stock"
    if low.startswith("us:"):
        return "us", s.split(":", 1)[1], "stock"
    if low.startswith(("fund:", "etf:")):
        return "cn", s.split(":", 1)[1], "fund"
    m = re.match(r"^([A-Za-z]{1,3})(\d{3,4})?$", s)
    if m and not s.isdigit():
        return "cn", s.upper(), "futures"
    if "." in s and s.split(".")[0].isalpha():
        return "cn", s.upper(), "futures"
    if re.match(r"^\d{5}$", s):
        return "hk", s.zfill(5), "stock"
    if re.match(r"^[A-Za-z][A-Za-z.\-]{0,9}$", s):
        return "us", s.upper(), "stock"
    digits = re.sub(r"\D", "", s)
    if len(digits) == 6:
        prefix = digits[:2]
        if prefix in ("11", "15", "16", "51", "52", "58", "59"):
            return "cn", digits, "fund"
        return "cn", digits, "stock"
    return "cn", s, "stock"

class EastmoneyClient:
    """东方财富公开接口的薄客户端（行情 + K 线 + 期货 K 线）。"""

    QUOTE_URL = "https://push2.eastmoney.com/api/qt/stock/get"
    KLINE_URL = "https://push2his.eastmoney.com/api/qt/stock/kline/get"
    FUTURES_MARKET = {"shfe": 113, "dce": 114, "czce": 115, "cffex": 220}

    @staticmethod
    def _secid(symbol: str, asset_type: str = "stock") -> Optional[str]:
        code = symbol.split(":", 1)[-1].upper()
        if asset_type == "futures":
            m = re.match(r"^([A-Z]{1,2})", code)
            if not m:
                return None
            product = m.group(1)
            exchange = _futures_exchange(product)
            market = EastmoneyClient.FUTURES_MARKET.get(exchange or "")
            return f"{market}.{code}" if market else None
        if code.isdigit() and len(code) == 6:
            if asset_type == "index" and code.startswith("000"):
                return f"1.{code}"
            if code.startswith(("6", "9")):
                return f"1.{code}"
            return f"0.{code}"
        return None

    @classmethod
    def quote(cls, symbol: str, asset_type: str = "stock", market: str = "cn") -> Optional[MarketQuote]:
        secid = cls._secid(symbol, asset_type)
        if not secid:
            return None
        fields = ("f43,f44,f45,f46,f47,f48,f57,f58,f60,f86,"
                  "f116,f162,f167,f168,f169,f170")
        url = f"{cls.QUOTE_URL}?secid={secid}&fields={fields}&invt=2&fltt=2&ut=fa5fd1943c7b386f172d6893dbbd1d0c"
        try:
            raw = json.loads(_decode_bytes(_http_get(url, timeout=8)))
        except Exception:
            return None
        if not isinstance(raw, dict) or not isinstance(raw.get("data"), dict):
            return None
        quote = normalize_quote_data(raw, symbol, asset_type, market, "eastmoney_api")
        quote.timestamp = to_iso(raw["data"].get("f86")) if raw["data"].get("f86") else now_iso()
        return quote if quote.valid else None

    @classmethod
    def kline(cls, symbol: str, asset_type: str = "stock", market: str = "cn",
              days: int = 250) -> Optional[PriceSeries]:
        secid = cls._secid(symbol, asset_type)
        if not secid:
            return None
        url = (f"{cls.KLINE_URL}?secid={secid}&klt=101&fqt=1&lmt={max(2, int(days))}"
               f"&end=20500101&fields1=f1,f2,f3,f4,f5,f6"
               f"&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61")
        try:
            raw = json.loads(_decode_bytes(_http_get(url, timeout=10)))
        except Exception:
            return None
        klines = ((raw or {}).get("data") or {}).get("klines") if isinstance(raw, dict) else None
        if not isinstance(klines, list) or not klines:
            return None
        dates, opens, closes, highs, lows, volumes, amounts = [], [], [], [], [], [], []
        for row in klines:
            parts = str(row).split(",")
            if len(parts) < 6:
                continue
            vals = [safe_float(x, None) for x in parts[1:6]]
            if any(v is None or v <= 0 for v in vals):
                continue
            dates.append(parts[0])
            opens.append(vals[0])
            closes.append(vals[1])
            highs.append(vals[2])
            lows.append(vals[3])
            volumes.append(safe_float(parts[5], 0.0) or 0.0)
            amounts.append(safe_float(parts[6], 0.0) if len(parts) > 6 else 0.0)
        if not closes:
            return None
        return PriceSeries(symbol=symbol, asset_type=asset_type, market=market,
                           dates=dates, opens=opens, highs=highs, lows=lows,
                           closes=closes, volumes=volumes, amounts=amounts,
                           source="eastmoney_kline", quality="actual", as_of=dates[-1])


def _futures_exchange(product_or_contract: str) -> str:
    """按品种前缀推断交易所，仅用于路由，最终仍以合约元数据为准。"""
    code = re.sub(r"[^A-Z]", "", product_or_contract.upper())
    groups = {
        "shfe": ("AU", "AG", "CU", "AL", "ZN", "PB", "NI", "SN", "RU", "BU", "FU", "RB", "HC", "WR", "SS", "SP", "BR", "AO"),
        "dce": ("A", "B", "M", "Y", "P", "C", "CS", "L", "V", "PP", "J", "JM", "I", "EG", "EB", "PG", "RR", "LH", "JD", "FB", "BB"),
        "czce": ("SR", "CF", "TA", "MA", "RM", "OI", "RS", "SF", "SM", "FG", "AP", "CJ", "UR", "SA", "PF", "PK", "PR", "CY", "WH", "JR", "LR", "PM", "RI"),
        "cffex": ("IF", "IH", "IC", "IM", "T", "TF", "TS", "TL"),
    }
    for exchange, prefixes in groups.items():
        for prefix in sorted(prefixes, key=len, reverse=True):
            if code == prefix or code.startswith(prefix + "") and not code[len(prefix):len(prefix) + 1].isalpha():
                return exchange
    return ""

class FundDataClient:
    """场外基金/ETF 数据：官方净值、盘中估值与历史净值。"""

    ESTIMATE_URL = "https://fundgz.1234567.com.cn/js/{code}.js"
    HISTORY_URL = "https://api.fund.eastmoney.com/f10/lsjz"

    @staticmethod
    def fund_type(code: str) -> str:
        c = re.sub(r"\D", "", code)
        return "etf" if c.startswith(("51", "52", "56", "58", "159")) else "otc"

    @classmethod
    def estimate(cls, code: str) -> Optional[FundSnapshot]:
        clean = re.sub(r"\D", "", code)
        if not clean:
            return None
        url = cls.ESTIMATE_URL.format(code=clean)
        try:
            text = _decode_bytes(_http_get(url, headers={
                "Referer": f"https://fund.eastmoney.com/{clean}.html",
            }, timeout=8))
            data = _parse_json_text(text)
        except Exception:
            return None
        if not isinstance(data, dict):
            return None
        return FundSnapshot(
            code=clean, name=str(data.get("name") or ""),
            official_nav=safe_float(data.get("dwjz"), None),
            nav_date=str(data.get("jzrq") or ""),
            estimated_nav=safe_float(data.get("gsz"), None),
            estimate_pct=safe_float(data.get("gszzl"), None),
            estimate_time=str(data.get("gztime") or ""),
            fund_type=cls.fund_type(clean), source="eastmoney_fund_estimate",
            quality="estimated",
            warnings=["盘中估值非官方净值，不能用于确认成交或收益"],
        )

    @classmethod
    def history(cls, code: str, days: int = 250) -> Optional[PriceSeries]:
        clean = re.sub(r"\D", "", code)
        if not clean:
            return None
        params = urllib.parse.urlencode({
            "fundCode": clean, "pageIndex": 1, "pageSize": max(2, int(days)),
            "startDate": "", "endDate": "",
        })
        try:
            payload = json.loads(_decode_bytes(_http_get(
                f"{cls.HISTORY_URL}?{params}",
                headers={"Referer": f"https://fundf10.eastmoney.com/jjjz_{clean}.html"},
                timeout=10,
            )))
        except Exception:
            return None
        rows = ((payload or {}).get("Data") or {}).get("LSJZList") if isinstance(payload, dict) else None
        if not isinstance(rows, list) or not rows:
            return None
        # 接口按时间倒序；统一转为从旧到新。
        rows = list(reversed(rows))
        dates, navs = [], []
        for row in rows:
            nav = safe_float(row.get("DWJZ"), None)
            if nav is None or nav <= 0:
                continue
            dates.append(str(row.get("FSRQ") or ""))
            navs.append(nav)
        if len(navs) < 2:
            return None
        return PriceSeries(symbol=clean, asset_type="fund", market="cn",
                           dates=dates, closes=navs, source="eastmoney_fund_nav",
                           quality="actual", as_of=dates[-1],
                           warnings=["场外基金净值为每日披露值，不存在真正实时净值"] if cls.fund_type(clean) == "otc" else [])

    @classmethod
    def snapshot(cls, code: str, market_price: Optional[float] = None,
                 iopv: Optional[float] = None) -> FundSnapshot:
        snap = cls.estimate(code)
        if snap is None:
            snap = FundSnapshot(code=re.sub(r"\D", "", code),
                                fund_type=cls.fund_type(code),
                                source="eastmoney", quality="unavailable",
                                warnings=["基金估值获取失败"])
        if market_price is not None:
            snap.market_price = safe_float(market_price, None)
        if iopv is not None:
            snap.iopv = safe_float(iopv, None)
        if snap.market_price and snap.iopv:
            snap.premium_pct = (snap.market_price - snap.iopv) / snap.iopv * 100.0
        return snap

# 中金所股指/国债期货的交割日是"第 N 个周五"，与商品期货的 15 日规则不同。
# 早先一律按每月 15 日推算，IF/IC 的剩余天数会错好几天，展期风险判断随之失真。
_CFFEX_INDEX = ("IF", "IC", "IH", "IM")
_CFFEX_BOND = ("T", "TF", "TS", "TL")


def _nth_weekday(year: int, month: int, weekday: int, n: int) -> date:
    """当月第 n 个 weekday（Mon=0..Sun=6）。"""
    first = date(year, month, 1)
    offset = (weekday - first.weekday()) % 7
    return first.replace(day=1 + offset + 7 * (n - 1))


def _contract_expiry(year: int, month: int, contract: str) -> Optional[date]:
    """按交易所规则给出到期日；无法识别的月份返回 None，绝不给假日期。"""
    if not (1900 <= year <= 2999 and 1 <= month <= 12):
        return None
    try:
        product = re.match(r"^([A-Z]{1,2})", contract)
        code = product.group(1) if product else ""
        if code in _CFFEX_INDEX:
            return _nth_weekday(year, month, 4, 3)
        if code in _CFFEX_BOND:
            return _nth_weekday(year, month, 4, 2)
        return date(year, month, 15)
    except ValueError:
        return None


class FuturesDataClient:
    """期货合约报价、历史与期限结构。真实价格缺失时返回 None，不伪造快照。"""

    SINA_URL = "https://hq.sinajs.cn/list=nf_{code}"

    @staticmethod
    def product(contract: str) -> str:
        m = re.match(r"^([A-Za-z]{1,2})", str(contract).strip())
        return m.group(1).upper() if m else str(contract).strip().upper()

    @staticmethod
    def days_to_expiry(contract: str) -> Optional[int]:
        m = re.search(r"(\d{2})(\d{2})$", str(contract))
        if not m:
            return None
        yy, mm = int(m.group(1)), int(m.group(2))
        year = 2000 + yy
        month = mm if 1 <= mm <= 12 else 1
        expiry = _contract_expiry(year, month, str(contract).strip().upper())
        if expiry is None:
            return None
        return max(0, (expiry - datetime.now(CN_TZ).date()).days)

    @classmethod
    def _sina_quote(cls, contract: str) -> Optional[FuturesContract]:
        code = str(contract).strip().upper()
        try:
            text = _decode_bytes(_http_get(
                cls.SINA_URL.format(code=code),
                headers={"Referer": "https://finance.sina.com.cn/"}, timeout=6,
            ))
        except Exception:
            return None
        m = re.search(r'="(.*?)"', text, flags=re.S)
        if not m:
            return None
        fields = m.group(1).split(",")
        if len(fields) < 15:
            return None
        nums = [safe_float(x, None) for x in fields]
        # 新浪期货字段在不同品种上略有差异，采用 OHLC 一致性做候选校验。
        candidates = []
        if len(nums) >= 15:
            candidates.append({
                "open": nums[2], "high": nums[3], "low": nums[4],
                "prev_close": nums[5], "price": nums[8],
                "settlement": nums[9], "prev_settlement": nums[10],
                "open_interest": nums[13], "volume": nums[14],
            })
        if len(nums) >= 18:
            candidates.append({
                "open": nums[2], "high": nums[3], "low": nums[4],
                "price": nums[5], "prev_close": nums[6],
                "settlement": nums[9], "open_interest": nums[13],
                "volume": nums[14],
            })
        for c in candidates:
            price, high, low = c.get("price"), c.get("high"), c.get("low")
            if not (price and price > 0 and high and high > 0 and low and low > 0):
                continue
            if high + 1e-9 < max(price, low) or low - 1e-9 > min(price, high):
                continue
            exchange = _futures_exchange(cls.product(code))
            return FuturesContract(
                contract=code, product=cls.product(code), exchange=exchange,
                price=price, prev_close=c.get("prev_close"),
                settlement=c.get("settlement"),
                open_interest=c.get("open_interest"), volume=c.get("volume"),
                days_to_expiry=cls.days_to_expiry(code),
                is_main=bool(re.search(r"0$", code) and not re.search(r"\d{4}$", code)),
                timestamp=to_iso(fields[1] if len(fields) > 1 else now_iso()),
                source="sina_futures", quality="actual",
                warnings=["新浪期货字段存在品种差异，已通过 OHLC 一致性校验"],
            )
        return None

    @classmethod
    def quote(cls, contract: str) -> Optional[FuturesContract]:
        return cls._sina_quote(contract) or EastmoneyClient.quote(
            contract, asset_type="futures", market="cn")

    @classmethod
    def history(cls, contract: str, days: int = 250) -> Optional[PriceSeries]:
        series = EastmoneyClient.kline(contract, asset_type="futures", days=days)
        if series:
            series.source = "eastmoney_futures_kline"
            return series
        # 仅在 akshare 已安装时尝试，不在运行时联网安装。
        try:
            import akshare as ak  # type: ignore
            df = ak.futures_zh_daily_sina(symbol=str(contract).upper())
            if df is None or len(df) == 0:
                return None
            dates, opens, highs, lows, closes, volumes = [], [], [], [], [], []
            for _, row in df.iterrows():
                close = safe_float(row.get("close"), None)
                if close is None or close <= 0:
                    continue
                dates.append(str(row.get("date") or ""))
                opens.append(safe_float(row.get("open"), close) or close)
                highs.append(safe_float(row.get("high"), close) or close)
                lows.append(safe_float(row.get("low"), close) or close)
                closes.append(close)
                volumes.append(safe_float(row.get("volume"), 0.0) or 0.0)
            if closes:
                return PriceSeries(symbol=contract, asset_type="futures", dates=dates,
                                   opens=opens, highs=highs, lows=lows, closes=closes,
                                   volumes=volumes, source="akshare_sina_futures",
                                   quality="actual", as_of=dates[-1])
        except Exception:
            return None
        return None

    @classmethod
    def mark_main_contract(cls, items: Sequence[FuturesContract]) -> Optional[str]:
        """按持仓量（缺失时退到成交量）在期限结构里认定主力合约。

        返回判定依据；没有任何量能数据时返回 None，由调用方标注不确定性，
        而不是靠合约名后缀猜主力——后缀规则只对连续合约成立。
        """
        real = [c for c in items if c]
        if len(real) < 2:
            return None
        for key in ("open_interest", "volume"):
            with_key = [c for c in real if getattr(c, key) is not None]
            if len(with_key) >= 2:
                top = max(with_key, key=lambda c: float(getattr(c, key) or 0.0))
                for c in real:
                    c.is_main = c is top
                return key
        return None

    @classmethod
    def curve(cls, contracts: Sequence[str], spot_price: Optional[float] = None) -> FuturesCurve:
        items = []
        for contract in contracts[:12]:
            q = cls.quote(contract)
            if q:
                items.append(q)
        product = cls.product(contracts[0]) if contracts else ""
        warnings: List[str] = []
        if items:
            basis = cls.mark_main_contract(items)
            if basis is None and len(items) > 1:
                warnings.append("多个合约均无持仓量/成交量，主力标识沿用命名规则，未经量能确认")
        return FuturesCurve(product=product, contracts=items, spot_price=spot_price,
                            source=",".join(sorted({x.source for x in items})) if items else "",
                            quality="actual" if items else "unavailable",
                            warnings=warnings or ([] if items else ["未能获取合约报价，期限结构不可用"]))

@dataclass
class CollectedData:
    symbol: str
    asset_type: str
    market: str
    quote: Optional[MarketQuote] = None
    history: Optional[PriceSeries] = None
    fund_snapshot: Optional[FundSnapshot] = None
    futures_curve: Optional[FuturesCurve] = None
    news: List[Dict[str, Any]] = field(default_factory=list)
    money_flow: Dict[str, Any] = field(default_factory=dict)
    fundamentals: Dict[str, Any] = field(default_factory=dict)
    macro: Dict[str, Any] = field(default_factory=dict)
    sources: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    extras: Dict[str, Any] = field(default_factory=dict)
    collected_at: str = field(default_factory=now_iso)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol, "asset_type": self.asset_type,
            "market": self.market,
            "quote": self.quote.to_dict() if self.quote else None,
            "history": self.history.to_dict() if self.history else None,
            "fund_snapshot": self.fund_snapshot.to_dict() if self.fund_snapshot else None,
            "futures_curve": self.futures_curve.to_dict() if self.futures_curve else None,
            "news": self.news[:50], "money_flow": self.money_flow,
            "fundamentals": self.fundamentals, "macro": self.macro,
            "sources": self.sources, "warnings": self.warnings,
            "errors": self.errors, "extras": self.extras,
            "collected_at": self.collected_at,
        }

class LiveDataProvider:
    """统一实时/历史数据提供器，支持注入替身与离线覆盖。

    网络失败不会抛出到报告层：返回已取得的数据 + warnings/errors，
    由上层进行质量降级和弃权判断。
    """

    def __init__(self, router: Any = None, cache_ttl: float = 15.0,
                 use_network: bool = True) -> None:
        self.router = router
        self.cache_ttl = max(0.0, cache_ttl)
        self.use_network = use_network
        self._cache: Dict[str, Tuple[float, Any]] = {}

    def _cache_get(self, key: str) -> Any:
        item = self._cache.get(key)
        if not item:
            return None
        ts, value = item
        return value if time.time() - ts <= self.cache_ttl else None

    def _cache_put(self, key: str, value: Any) -> None:
        if self.cache_ttl > 0:
            self._cache[key] = (time.time(), value)

    def _router(self):
        if self.router is not None:
            return self.router
        if not self.use_network:
            return None
        try:
            from stock_researcher.data_multi_source import get_router
            self.router = get_router()
            return self.router
        except Exception:
            return None

    def get_quote(self, symbol: str, asset_type: str = "stock",
                  market: str = "cn") -> Optional[MarketQuote]:
        key = f"quote:{asset_type}:{market}:{symbol}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        clean = symbol.split(":", 1)[-1] if ":" in symbol else symbol
        if asset_type == "fund":
            mq = self._fund_quote(clean, market)
            if mq:
                self._cache_put(key, mq)
                return mq
        if asset_type == "futures":
            fc = FuturesDataClient.quote(clean)
            if fc:
                q = MarketQuote(symbol=symbol, name=clean, asset_type="futures",
                                market="cn", price=fc.price, prev_close=fc.prev_close,
                                volume=fc.volume, timestamp=fc.timestamp,
                                source=fc.source, freshness="realtime",
                                quality=fc.quality, warnings=list(fc.warnings),
                                raw=fc.to_dict())
                self._cache_put(key, q)
                return q
            return None
        q = None
        router = self._router()
        if router is not None:
            try:
                result = router.query_stock_quote(clean, market=market)
                if getattr(result, "success", False):
                    q = normalize_quote_data(result.data, symbol, asset_type, market, result.source)
                    q.timestamp = getattr(result, "timestamp", "") or q.timestamp
                    q.freshness = getattr(result, "freshness", q.freshness)
                    q.raw.setdefault("_validated", getattr(result, "validated", False))
                    q.raw.setdefault("_confidence", getattr(result, "confidence", None))
            except Exception:
                q = None
        if q is None or not q.valid:
            q = EastmoneyClient.quote(clean, asset_type=asset_type, market=market)
        if q is None or not q.valid:
            q = self._marketdata_quote(clean, asset_type, market)
        if q is None or not q.valid:
            q = self._yfinance_quote(clean, asset_type, market)
        if q and q.valid:
            self._cache_put(key, q)
        return q

    def _marketdata_quote(self, code: str, asset_type: str, market: str) -> Optional[MarketQuote]:
        if market != "cn":
            return None
        try:
            from stock_researcher.data_market import MarketData
            data = MarketData().fetch_realtime([code])
            item = data.get(code) or next(iter(data.values()), None)
            if item:
                return normalize_quote_data(item, code, asset_type, market, "tencent")
        except Exception:
            return None
        return None

    def _yfinance_quote(self, code: str, asset_type: str, market: str) -> Optional[MarketQuote]:
        try:
            import yfinance as yf  # type: ignore
            symbol = code
            if market == "hk" and not symbol.endswith(".HK"):
                symbol = symbol.zfill(4) + ".HK"
            elif market == "us":
                symbol = symbol.upper()
            info = yf.Ticker(symbol).fast_info
            price = safe_float(getattr(info, "last_price", None), None)
            if price:
                return MarketQuote(symbol=code, asset_type=asset_type, market=market,
                                   price=price, prev_close=safe_float(getattr(info, "previous_close", None), None),
                                   open=safe_float(getattr(info, "open", None), None),
                                   high=safe_float(getattr(info, "day_high", None), None),
                                   low=safe_float(getattr(info, "day_low", None), None),
                                   timestamp=now_iso(), source="yfinance",
                                   freshness="delayed", quality="actual")
        except Exception:
            return None
        return None

    def _fund_quote(self, code: str, market: str) -> Optional[MarketQuote]:
        market_price = None
        iopv = None
        router = self._router()
        if router is not None and FundDataClient.fund_type(code) == "etf":
            try:
                result = router.query_stock_quote(code, market="cn")
                if getattr(result, "success", False):
                    q = normalize_quote_data(result.data, code, "fund", "cn", result.source)
                    market_price = q.price if q.valid else None
                    iopv = safe_float((q.raw or {}).get("iopv"), None)
            except Exception:
                pass
        snap = FundDataClient.snapshot(code, market_price=market_price, iopv=iopv)
        price = snap.market_price or snap.estimated_nav or snap.official_nav
        if not price:
            return None
        return MarketQuote(
            symbol=code, name=snap.name, asset_type="fund", market="cn", price=price,
            prev_close=snap.official_nav, timestamp=snap.estimate_time or snap.nav_date or now_iso(),
            source=snap.source, freshness="estimated" if snap.estimated_nav else "closing",
            quality=snap.quality, warnings=list(snap.warnings),
            raw={**snap.to_dict(), "market_price": snap.market_price, "iopv": snap.iopv},
        )

    def get_history(self, symbol: str, asset_type: str = "stock",
                    market: str = "cn", days: int = 250) -> Optional[PriceSeries]:
        key = f"history:{asset_type}:{market}:{symbol}:{days}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        clean = symbol.split(":", 1)[-1] if ":" in symbol else symbol
        series = None
        if asset_type == "fund":
            series = FundDataClient.history(clean, days=days)
        elif asset_type == "futures":
            series = FuturesDataClient.history(clean, days=days)
        else:
            if market == "cn":
                series = EastmoneyClient.kline(clean, asset_type=asset_type, market=market, days=days)
                if series is None:
                    series = self._marketdata_history(clean, asset_type, market, days)
            if series is None:
                router = self._router()
                if router is not None:
                    try:
                        from stock_researcher.data_multi_source import DataCategory
                        result = router.query(market, DataCategory.KLINE, code=clean, days=days)
                        if getattr(result, "success", False):
                            series = _series_from_payload(result.data, symbol, asset_type, market,
                                                          result.source, days)
                    except Exception:
                        pass
            if series is None:
                series = self._yfinance_history(clean, asset_type, market, days)
        if series and series.usable:
            self._cache_put(key, series)
            return series
        return series

    def _marketdata_history(self, code: str, asset_type: str, market: str,
                            days: int) -> Optional[PriceSeries]:
        if market != "cn":
            return None
        try:
            from stock_researcher.data_market import MarketData
            data = MarketData().fetch_history(code, days=days)
            if data and len(data.get("closes", [])) >= 2:
                return PriceSeries(symbol=code, asset_type=asset_type, market=market,
                                   dates=data.get("dates", []), opens=data.get("opens", []),
                                   highs=data.get("highs", []), lows=data.get("lows", []),
                                   closes=data.get("closes", []), volumes=data.get("volumes", []),
                                   source="tencent_kline", quality="actual",
                                   as_of=(data.get("dates") or [now_iso()])[-1])
        except Exception:
            return None
        return None

    def _yfinance_history(self, code: str, asset_type: str, market: str,
                          days: int) -> Optional[PriceSeries]:
        try:
            import yfinance as yf  # type: ignore
            symbol = code
            if market == "hk" and not symbol.endswith(".HK"):
                symbol = symbol.zfill(4) + ".HK"
            elif market == "cn":
                symbol = symbol + (".SS" if symbol.startswith("6") else ".SZ")
            frame = yf.download(symbol, period=f"{max(1, int(days))}d", interval="1d",
                                progress=False, auto_adjust=False)
            if frame is None or len(frame) == 0:
                return None
            close_obj = frame["Close"]
            if hasattr(close_obj, "columns"):
                close_obj = close_obj.iloc[:, 0]
            dates = [str(idx)[:10] for idx in frame.index]
            closes = [safe_float(x, None) for x in close_obj.tolist()]
            pairs = [(d, c) for d, c in zip(dates, closes) if c and c > 0]
            if not pairs:
                return None
            return PriceSeries(symbol=code, asset_type=asset_type, market=market,
                               dates=[p[0] for p in pairs], closes=[p[1] for p in pairs],
                               source="yfinance", quality="actual", as_of=pairs[-1][0])
        except Exception:
            return None

    def get_news(self, symbol: str, asset_type: str = "stock",
                 clean: str = "", limit: int = 30) -> List[Dict[str, Any]]:
        clean = clean or (symbol.split(":", 1)[-1] if ":" in symbol else symbol)
        if not self.use_network:
            return []
        try:
            from stock_researcher.data_news import NewsData
            raw = NewsData().fetch_stock_news(clean, limit=limit)
            return raw if isinstance(raw, list) else []
        except Exception:
            return []

    def get_announcements(self, symbol: str, clean: str = "",
                          limit: int = 20) -> List[Dict[str, Any]]:
        clean = clean or (symbol.split(":", 1)[-1] if ":" in symbol else symbol)
        if not self.use_network:
            return []
        try:
            return AnnouncementClient.fetch(clean, limit=limit)
        except Exception:
            return []

    def get_money_flow(self, code: str, market: str = "cn") -> Dict[str, Any]:
        router = self._router()
        payload = None
        source = ""
        if router is not None:
            try:
                result = router.query_money_flow(code)
                if getattr(result, "success", False):
                    payload, source = result.data, result.source
            except Exception:
                pass
        if payload is None:
            try:
                from stock_researcher.data_money_flow import MoneyFlowData
                data = MoneyFlowData().get_money_flow([code])
                payload = data.get(code)
                source = "tencent/eastmoney_money_flow"
            except Exception:
                payload = None
        flow = _normalize_money_flow(payload, code)
        if flow:
            flow.setdefault("source", source)
        return flow

    def get_fundamentals(self, code: str, market: str = "cn") -> Dict[str, Any]:
        if market != "cn":
            return {}
        out: Dict[str, Any] = {}
        try:
            from stock_researcher.data_fundamental import FundamentalData
            fd = FundamentalData()
            summary = fd.get_financial_summary(code)
            if isinstance(summary, dict):
                out.update(summary)
            valuation = fd.get_valuation(code)
            if isinstance(valuation, dict):
                out.update({f"valuation_{k}": v for k, v in valuation.items()
                            if k not in out})
        except Exception:
            return out
        return out


    def collect(self, symbol: str, asset_type: Optional[str] = None,
                market: Optional[str] = None, history_days: int = 250,
                include_news: bool = True, include_flow: bool = True,
                include_fundamentals: bool = True,
                include_futures_curve: bool = False,
                futures_contracts: Optional[Sequence[str]] = None,
                spot_price: Optional[float] = None,
                overrides: Optional[Dict[str, Any]] = None) -> CollectedData:
        inferred_market, clean, inferred_type = infer_market(symbol)
        asset_type = (asset_type or inferred_type).lower()
        market = market or inferred_market
        if asset_type in ("etf", "lof"):
            asset_type = "fund"
        out = CollectedData(symbol=symbol, asset_type=asset_type, market=market)
        overrides = dict(overrides or {})
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _safe(name, fn, *args, **kwargs):
            try:
                return name, fn(*args, **kwargs), None
            except Exception as exc:
                return name, None, f"{name}: {str(exc)[:180]}"

        tasks = {}
        with ThreadPoolExecutor(max_workers=6) as pool:
            quote_override = overrides.get("quote")
            if quote_override is not None:
                out.quote = quote_override if isinstance(quote_override, MarketQuote) else MarketQuote(symbol=symbol, **quote_override)
            elif self.use_network:
                tasks[pool.submit(_safe, "quote", self.get_quote, symbol, asset_type, market)] = "quote"

            history_override = overrides.get("history")
            if history_override is not None:
                if isinstance(history_override, PriceSeries):
                    out.history = history_override
                else:
                    out.history = PriceSeries(symbol=symbol, asset_type=asset_type, market=market, **history_override)
            elif self.use_network:
                tasks[pool.submit(_safe, "history", self.get_history, symbol, asset_type, market, history_days)] = "history"

            if asset_type == "fund" and overrides.get("fund_snapshot") is not None:
                value = overrides["fund_snapshot"]
                out.fund_snapshot = value if isinstance(value, FundSnapshot) else FundSnapshot(code=clean, **value)

            if asset_type == "futures" and (include_futures_curve or futures_contracts):
                curve_override = overrides.get("futures_curve")
                if curve_override is not None:
                    out.futures_curve = curve_override if isinstance(curve_override, FuturesCurve) else FuturesCurve(product=FuturesDataClient.product(clean), **curve_override)
                elif self.use_network:
                    contracts = list(futures_contracts or [clean])
                    tasks[pool.submit(_safe, "futures_curve", FuturesDataClient.curve, contracts, spot_price)] = "futures_curve"

            if include_news and self.use_network and "news" not in overrides:
                tasks[pool.submit(_safe, "news", self.get_news, symbol, asset_type, clean)] = "news"
                if asset_type in ("stock", "fund", "index") and market == "cn":
                    tasks[pool.submit(_safe, "announcements", self.get_announcements,
                                      symbol, clean)] = "announcements"
            if include_flow and asset_type in ("stock", "index") and self.use_network and "money_flow" not in overrides:
                tasks[pool.submit(_safe, "money_flow", self.get_money_flow, clean, market)] = "money_flow"
            if include_fundamentals and asset_type == "stock" and market == "cn" and self.use_network and "fundamentals" not in overrides:
                tasks[pool.submit(_safe, "fundamentals", self.get_fundamentals, clean, market)] = "fundamentals"

            for future in as_completed(tasks):
                key, value, error = future.result()
                if error:
                    out.errors.append(error)
                elif value is not None:
                    if key == "announcements":
                        out.extras["announcements"] = value
                    else:
                        setattr(out, key, value)

        for key in ("news", "money_flow", "fundamentals", "macro", "extras"):
            if key in overrides and overrides[key] is not None:
                setattr(out, key, overrides[key])
        if overrides.get("warnings"):
            out.warnings.extend(str(x) for x in overrides["warnings"])
        if overrides.get("errors"):
            out.errors.extend(str(x) for x in overrides["errors"])
        announcements = out.extras.pop("announcements", None)
        if announcements and "news" not in overrides:
            out.news = list(announcements) + list(out.news or [])
            out.sources.append("东方财富公告")

        if out.fund_snapshot is None and asset_type == "fund" and out.quote:
            out.fund_snapshot = _fund_snapshot_from_quote(out.quote, clean)
        if out.futures_curve is None and asset_type == "futures" and out.quote:
            raw = out.quote.raw or {}
            contract = FuturesContract(
                contract=clean, product=FuturesDataClient.product(clean),
                exchange=str(raw.get("exchange") or _futures_exchange(clean)),
                price=out.quote.price, prev_close=out.quote.prev_close,
                open_interest=safe_float(raw.get("open_interest"), None),
                volume=out.quote.volume, days_to_expiry=FuturesDataClient.days_to_expiry(clean),
                timestamp=out.quote.timestamp, source=out.quote.source,
                quality=out.quote.quality,
            )
            out.futures_curve = FuturesCurve(product=contract.product, contracts=[contract],
                                             spot_price=spot_price, source=out.quote.source,
                                             quality=out.quote.quality)
        if out.history is None and out.quote and out.quote.price:
            out.history = PriceSeries(symbol=symbol, asset_type=asset_type, market=market,
                                      closes=[out.quote.price], source=out.quote.source,
                                      quality="insufficient",
                                      as_of=out.quote.timestamp or now_iso(),
                                      warnings=["仅有最新报价，无法计算可靠的时序指标"])
        if out.history and out.history.quality == "insufficient":
            out.warnings.append("历史序列不足，时序分析与概率预测应弃权或降级")
        sources: List[str] = []
        for obj in (out.quote, out.history, out.fund_snapshot, out.futures_curve):
            if obj and getattr(obj, "source", ""):
                sources.extend(str(obj.source).split(","))
        out.sources = sorted({s for s in sources if s})
        if announcements:
            out.sources = sorted(set(out.sources + ["东方财富公告"]))
        for obj in (out.quote, out.history, out.fund_snapshot, out.futures_curve):
            out.warnings.extend(getattr(obj, "warnings", []) if obj else [])
        out.extras.setdefault("data_cutoff", out.history.as_of if out.history else out.collected_at)
        out.extras.setdefault("clean_symbol", clean)
        return out


def _series_from_payload(data: Any, symbol: str, asset_type: str, market: str,
                         source: str, days: int = 250) -> Optional[PriceSeries]:
    """把 DataFrame/list[dict]/dict 形态的 K 线归一化为 PriceSeries。"""
    if data is None:
        return None
    if hasattr(data, "to_dict"):
        try:
            data = data.to_dict("records")
        except Exception:
            return None
    if isinstance(data, dict):
        raw = data.get("data") if isinstance(data.get("data"), dict) else data
        klines = raw.get("klines") if isinstance(raw, dict) else None
        if isinstance(klines, list):
            data = klines
        elif isinstance(raw, dict) and "closes" in raw:
            return PriceSeries(symbol=symbol, asset_type=asset_type, market=market,
                               dates=raw.get("dates", []), opens=raw.get("opens", []),
                               highs=raw.get("highs", []), lows=raw.get("lows", []),
                               closes=raw.get("closes", []), volumes=raw.get("volumes", []),
                               source=source, quality="actual",
                               as_of=(raw.get("dates") or [now_iso()])[-1])
        elif isinstance(raw, dict):
            data = [raw]
    if not isinstance(data, list):
        return None
    dates, opens, highs, lows, closes, volumes, amounts = [], [], [], [], [], [], []
    for row in data[-max(2, int(days)):]:
        if isinstance(row, str):
            parts = row.split(",")
            if len(parts) >= 6:
                row = {"date": parts[0], "open": parts[1], "close": parts[2],
                       "high": parts[3], "low": parts[4], "volume": parts[5],
                       "amount": parts[6] if len(parts) > 6 else 0}
        if not isinstance(row, dict):
            continue
        close = safe_float(_pick(row, ("close", "closes", "收盘", "收盘价", "nav", "price", "最新价")), None)
        if close is None or close <= 0:
            continue
        dt = _pick(row, ("date", "datetime", "time", "日期", "交易日期"))
        dates.append(str(dt or ""))
        opens.append(safe_float(_pick(row, ("open", "开盘", "开盘价")), close) or close)
        highs.append(safe_float(_pick(row, ("high", "最高", "最高价")), close) or close)
        lows.append(safe_float(_pick(row, ("low", "最低", "最低价")), close) or close)
        closes.append(close)
        volumes.append(safe_float(_pick(row, ("volume", "vol", "成交量")), 0.0) or 0.0)
        amounts.append(safe_float(_pick(row, ("amount", "成交额")), 0.0) or 0.0)
    if len(closes) < 2:
        return None
    return PriceSeries(symbol=symbol, asset_type=asset_type, market=market,
                       dates=dates, opens=opens, highs=highs, lows=lows,
                       closes=closes, volumes=volumes, amounts=amounts,
                       source=source, quality="actual", as_of=dates[-1])

def _normalize_money_flow(payload: Any, code: str) -> Dict[str, Any]:
    if payload is None:
        return {}
    if hasattr(payload, "to_dict"):
        try:
            records = payload.to_dict("records")
            payload = records[-1] if records else None
        except Exception:
            pass
    if isinstance(payload, dict) and code in payload and isinstance(payload[code], dict):
        payload = payload[code]
    payload = _unwrap_payload(payload)
    if isinstance(payload, list) and payload:
        next_payload = payload[-1]
        payload = next_payload
    if not isinstance(payload, dict):
        return {}
    nested = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    klines = payload.get("klines") or nested.get("klines")
    if isinstance(klines, list) and klines:
        parsed = []
        for row in klines[-10:]:
            parts = str(row).split(",") if not isinstance(row, dict) else []
            if parts and len(parts) >= 6:
                parsed.append({
                    "date": parts[0],
                    "main_net": safe_float(parts[1], None),
                    "small_net": safe_float(parts[2], None),
                    "medium_net": safe_float(parts[3], None),
                    "large_net": safe_float(parts[4], None),
                    "super_large_net": safe_float(parts[5], None),
                })
            elif isinstance(row, dict):
                parsed.append(row)
        if parsed:
            last = parsed[-1]
            main_values = [safe_float(x.get("main_net"), None) for x in parsed]
            main_values = [x for x in main_values if x is not None]
            trend = None
            if len(main_values) >= 3:
                trend = "inflow" if sum(main_values[-3:]) > 0 else "outflow" if sum(main_values[-3:]) < 0 else "flat"
            return {
                "code": code, "date": last.get("date", ""),
                "main_net": last.get("main_net"),
                "super_large_net": last.get("super_large_net"),
                "large_net": last.get("large_net"),
                "medium_net": last.get("medium_net"),
                "small_net": last.get("small_net"),
                "main_net_flow": last.get("main_net"),
                "recent_3d_main_net": main_values[-3:],
                "trend": trend, "quality": "actual",
                "unit": "万元", "source": "eastmoney_money_flow",
            }
    main_net = safe_float(_pick(payload, ("main_net_flow", "main_net", "net_inflow", "f62")), None)
    if main_net is None:
        return {}
    return {
        "code": code, "main_net_flow": main_net,
        "flow_ratio": safe_float(_pick(payload, ("flow_ratio", "f184")), None),
        "turnover": safe_float(payload.get("turnover"), None),
        "amount": safe_float(payload.get("amount"), None),
        "direction": "inflow" if main_net > 0 else "outflow" if main_net < 0 else "flat",
        "quality": payload.get("data_quality", "actual"),
        "unit": "万元",
        "source": str(payload.get("source") or "money_flow"),
    }

def _fund_snapshot_from_quote(quote: MarketQuote, code: str) -> FundSnapshot:
    raw = quote.raw or {}
    snap = FundSnapshot(
        code=code, name=quote.name,
        official_nav=safe_float(raw.get("official_nav"), None),
        nav_date=str(raw.get("nav_date") or ""),
        estimated_nav=safe_float(raw.get("estimated_nav"), None),
        estimate_pct=safe_float(raw.get("estimate_pct"), None),
        estimate_time=str(raw.get("estimate_time") or quote.timestamp or ""),
        market_price=safe_float(raw.get("market_price"), quote.price),
        iopv=safe_float(raw.get("iopv"), None),
        premium_pct=safe_float(raw.get("premium_pct"), None),
        fund_type=str(raw.get("fund_type") or FundDataClient.fund_type(code)),
        source=quote.source, quality=quote.quality,
        warnings=list(quote.warnings),
    )
    return snap

class AnnouncementClient:
    """上市公司公告（东方财富公告接口，标题级；不抓取受限全文）。"""

    URL = "https://np-anotice-stock.eastmoney.com/api/security/ann"

    @staticmethod
    def parse(payload: Any, code: str = "") -> List[Dict[str, Any]]:
        if not isinstance(payload, dict):
            return []
        rows = ((payload.get("data") or {}).get("list")
                if isinstance(payload.get("data"), dict) else None)
        if not isinstance(rows, list):
            return []
        out = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            title = str(row.get("title") or row.get("announcementTitle") or "").strip()
            if not title:
                continue
            art_code = str(row.get("art_code") or row.get("announcementId") or "")
            notice_date = row.get("notice_date") or row.get("display_time") or row.get("announcementTime")
            url = (f"https://data.eastmoney.com/notices/detail/{code}/{art_code}.html"
                   if code and art_code else "")
            out.append({
                "title": title,
                "content": title,  # 仅有标题时不伪造公告正文
                "public_date": to_iso(notice_date) if notice_date else "",
                "source": "东方财富公告",
                "url": url,
                "type": "announcement",
                "reliability": "high",
            })
        return out

    @classmethod
    def fetch(cls, code: str, limit: int = 20) -> List[Dict[str, Any]]:
        clean = re.sub(r"\D", "", str(code))
        if not clean:
            return []
        params = urllib.parse.urlencode({
            "sr": -1, "page_size": max(1, min(50, int(limit))), "page_index": 1,
            "ann_type": "A", "client_source": "web", "stock_list": clean,
        })
        try:
            payload = json.loads(_decode_bytes(_http_get(
                f"{cls.URL}?{params}",
                headers={"Referer": f"https://data.eastmoney.com/notices/stock/{clean}.html"},
                timeout=8,
            )))
        except Exception:
            return []
        return cls.parse(payload, clean)
