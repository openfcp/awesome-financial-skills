# -*- coding: utf-8 -*-
"""v14.0 研究闭环：批量研究与报告差异。

两个能力都只消费 ``ResearchHub`` 产出的研究简报（``ResearchReport`` 或其
``to_dict()`` 结果），不新增数据源、不自行联网：

- :class:`BatchResearcher`：多标的并行分析，单个标的失败不影响其余；
  输出按输入顺序排列的对比行、方向/质量分布与失败清单。
- :func:`diff_reports`：对比两份已保存的简报，列出评分、方向、置信度、
  数据质量、周期概率、因子与风险的变化，并判断是否属于实质性变化。

纯标准库；批量分析复用调用方注入的 Hub，测试可用桩替身离线运行。
"""
from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from stock_researcher.research_contracts import DISCLAIMER, now_iso, safe_float
from stock_researcher.research_hub import ResearchHub

QUALITY_RANK = {
    "insufficient": 0, "unavailable": 0, "unknown": 0,
    "estimated": 1, "derived": 2, "actual": 3,
}
GATE_CHOICES = ("estimated", "derived", "actual")
MAX_BATCH_SYMBOLS = 50
_FORECAST_ORDER = ("1d", "5d", "1M", "3M", "6M")
_DIRECTION_CN = {"bullish": "偏多", "bearish": "偏空", "neutral": "中性"}
_SYMBOL_SPLIT = re.compile(r"[,，;；\s]+")


def parse_symbols(value: Any) -> List[str]:
    """把 ``"600519, hk:00700\\nAAPL"`` 或列表归一成去重后的代码列表。

    顺序按首次出现保留；大小写不同的同一代码视为重复（``US:AAPL`` / ``us:aapl``）。
    """
    if value is None:
        return []
    if isinstance(value, str):
        parts = _SYMBOL_SPLIT.split(value)
    elif isinstance(value, Iterable):
        parts = []
        for item in value:
            parts.extend(_SYMBOL_SPLIT.split(str(item)))
    else:
        parts = _SYMBOL_SPLIT.split(str(value))
    out: List[str] = []
    seen = set()
    for part in parts:
        token = part.strip()
        if not token:
            continue
        key = token.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(token)
    return out


def quality_rank(value: Any) -> int:
    return QUALITY_RANK.get(str(value or "").strip().lower(), 0)


def meets_quality(value: Any, minimum: str = "") -> bool:
    """判断数据状态是否达到门槛；空门槛恒为 True。"""
    if not minimum:
        return True
    return quality_rank(value) >= quality_rank(minimum)


def _report_dict(report: Any) -> Dict[str, Any]:
    if report is None:
        raise ValueError("缺少报告对象")
    if isinstance(report, dict):
        return report
    if hasattr(report, "to_dict"):
        data = report.to_dict()
        if isinstance(data, dict):
            return data
    raise ValueError("不支持的报告类型：%s" % type(report).__name__)


def load_report(path: Any) -> Dict[str, Any]:
    """读取 ``research_hub_cli.py analyze --format json`` 落盘的简报。"""
    p = Path(str(path))
    if not p.is_file():
        raise ValueError("报告文件不存在：%s" % p)
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as exc:
        raise ValueError("读取报告失败：%s" % str(exc)[:160])
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError("报告不是合法 JSON：%s" % str(exc)[:160])
    if not isinstance(payload, dict) or "symbol" not in payload:
        raise ValueError("JSON 里没有 symbol 字段，不像是研究简报：%s" % p)
    return payload


def _forecast_rows(report: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for item in report.get("forecasts") or []:
        if not isinstance(item, dict):
            continue
        horizon = str(item.get("horizon") or "").strip()
        if not horizon:
            continue
        out[horizon] = {
            "probability_up": safe_float(item.get("probability_up"), None),
            "median_return_pct": safe_float(item.get("median_return_pct"), None),
            "confidence": safe_float(item.get("confidence"), None),
            "abstain": bool(item.get("abstain")),
            "quality": str(item.get("quality") or ""),
        }
    return out


def _factor_scores(report: Dict[str, Any]) -> Dict[str, Optional[float]]:
    out: Dict[str, Optional[float]] = {}
    factors = (report.get("asset_analysis") or {}).get("factors") or []
    for item in factors:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        if name:
            out[name] = safe_float(item.get("score"), None)
    return out


def _string_diff(old: Any, new: Any, limit: int = 10) -> Dict[str, List[str]]:
    old_list = [str(x) for x in (old or []) if str(x).strip()]
    new_list = [str(x) for x in (new or []) if str(x).strip()]
    added = [x for x in new_list if x not in old_list][:limit]
    removed = [x for x in old_list if x not in new_list][:limit]
    return {"added": added, "removed": removed}


def _row_from_report(symbol: str, report: Any) -> "BatchRow":
    data = _report_dict(report)
    asset = data.get("asset_analysis") or {}
    quality = data.get("data_quality") or {}
    forecast_1m = _forecast_rows(data).get("1M") or {}
    return BatchRow(
        symbol=str(data.get("symbol") or symbol),
        name=str(data.get("name") or ""),
        asset_type=str(data.get("asset_type") or ""),
        price=safe_float(asset.get("price"), None),
        score=safe_float(data.get("score"), None),
        direction=str(data.get("direction") or ""),
        confidence=safe_float(data.get("confidence"), None),
        quality_status=str(quality.get("status") or ""),
        quality_score=safe_float(quality.get("score"), None),
        freshness=str(quality.get("freshness") or ""),
        probability_up_1m=forecast_1m.get("probability_up"),
        median_return_1m=forecast_1m.get("median_return_pct"),
        abstain_1m=forecast_1m.get("abstain"),
        run_id=str(data.get("run_id") or ""),
    )


@dataclass
class BatchRow:
    """一个标的的批量研究结果；失败行只带 symbol/status/error。"""
    symbol: str
    status: str = "ok"
    name: str = ""
    asset_type: str = ""
    price: Optional[float] = None
    score: Optional[float] = None
    direction: str = ""
    confidence: Optional[float] = None
    quality_status: str = ""
    quality_score: Optional[float] = None
    freshness: str = ""
    probability_up_1m: Optional[float] = None
    median_return_1m: Optional[float] = None
    abstain_1m: Optional[bool] = None
    run_id: str = ""
    error: str = ""

    @property
    def ok(self) -> bool:
        return self.status == "ok"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _summarize(rows: Sequence[BatchRow], min_quality: str) -> Dict[str, Any]:
    ok = [r for r in rows if r.ok]
    failed = [r for r in rows if not r.ok]
    directions = {"bullish": 0, "neutral": 0, "bearish": 0}
    quality_counts: Dict[str, int] = {}
    for row in ok:
        if row.direction in directions:
            directions[row.direction] += 1
        key = row.quality_status or "unknown"
        quality_counts[key] = quality_counts.get(key, 0) + 1
    scores = [r.score for r in ok if r.score is not None]
    confs = [r.confidence for r in ok if r.confidence is not None]
    ranked = sorted([r for r in ok if r.score is not None],
                    key=lambda r: r.score, reverse=True)

    def brief(row: BatchRow) -> Dict[str, Any]:
        return {"symbol": row.symbol, "name": row.name, "score": row.score,
                "direction": row.direction}

    return {
        "total": len(rows),
        "ok": len(ok),
        "failed": len(failed),
        "direction_counts": directions,
        "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
        "avg_confidence": round(sum(confs) / len(confs), 4) if confs else None,
        "quality_counts": quality_counts,
        "top": brief(ranked[0]) if ranked else None,
        "bottom": brief(ranked[-1]) if ranked else None,
        "min_quality": min_quality or "any",
        "gate_failed": [r.symbol for r in ok
                        if not meets_quality(r.quality_status, min_quality)],
        "errors": [{"symbol": r.symbol, "error": r.error} for r in failed],
    }


@dataclass
class BatchResult:
    rows: List[BatchRow]
    generated_at: str = field(default_factory=now_iso)
    min_quality: str = ""
    summary: Dict[str, Any] = field(default_factory=dict)
    disclaimer: str = DISCLAIMER

    @property
    def ok_rows(self) -> List[BatchRow]:
        return [r for r in self.rows if r.ok]

    @property
    def failed_rows(self) -> List[BatchRow]:
        return [r for r in self.rows if not r.ok]

    @property
    def gate_passed(self) -> bool:
        return all(meets_quality(r.quality_status, self.min_quality)
                   for r in self.ok_rows)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "min_quality": self.min_quality or "any",
            "summary": dict(self.summary),
            "rows": [r.to_dict() for r in self.rows],
            "disclaimer": self.disclaimer,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False,
                          indent=indent, default=str)

    def to_markdown(self) -> str:
        s = self.summary or {}
        lines: List[str] = ["# 批量研究简报", ""]
        lines.append(f"- 生成时间：{self.generated_at}")
        lines.append(f"- 标的数：{len(self.rows)}（成功 {s.get('ok', 0)} / "
                     f"失败 {s.get('failed', 0)}）")
        if s.get("avg_score") is not None:
            conf = s.get("avg_confidence")
            conf_text = f"{conf:.0%}" if conf is not None else "—"
            lines.append(f"- 平均评分：{s['avg_score']:+.1f}/100｜平均置信度：{conf_text}")
        gate_text = "未设置" if not self.min_quality else self.min_quality
        gate_state = "通过" if self.gate_passed else "未通过"
        lines.append(f"- 数据质量门槛：{gate_text}（{gate_state}）")
        lines.append("")
        lines.append("## 对比表")
        lines.append("| # | 标的 | 名称 | 评分 | 方向 | 置信度 | 数据状态 | 1M上涨 | 1M中位 | 状态 |")
        lines.append("|---|---|---|---:|---|---:|---|---:|---:|---|")
        for idx, row in enumerate(self.rows, 1):
            if not row.ok:
                lines.append(f"| {idx} | {row.symbol} | — | — | — | — | — | — | — | 失败 |")
                continue
            score = f"{row.score:+.1f}" if row.score is not None else "—"
            conf = f"{row.confidence:.0%}" if row.confidence is not None else "—"
            if row.abstain_1m:
                up = "弃权"
            elif row.probability_up_1m is not None:
                up = f"{row.probability_up_1m:.0%}"
            else:
                up = "—"
            median = (f"{row.median_return_1m:+.2f}%"
                      if row.median_return_1m is not None else "—")
            direction = _DIRECTION_CN.get(row.direction, row.direction or "—")
            quality = row.quality_status or "—"
            if self.min_quality and not meets_quality(row.quality_status, self.min_quality):
                quality += "⚠"
            lines.append(
                f"| {idx} | {row.symbol} | {row.name or '—'} | {score} | {direction} | "
                f"{conf} | {quality} | {up} | {median} | 成功 |")
        lines.append("")
        lines.append("## 汇总")
        counts = s.get("direction_counts") or {}
        lines.append(f"- 方向分布：偏多 {counts.get('bullish', 0)} / "
                     f"中性 {counts.get('neutral', 0)} / 偏空 {counts.get('bearish', 0)}")
        quality_counts = s.get("quality_counts") or {}
        if quality_counts:
            lines.append("- 数据状态：" + "，".join(
                f"{k} {v}" for k, v in sorted(quality_counts.items())))
        if s.get("top"):
            top = s["top"]
            lines.append(f"- 评分最高：{top.get('symbol')}（{top.get('name') or '—'}）"
                         f" {top.get('score'):+.1f}")
        if s.get("bottom"):
            bottom = s["bottom"]
            lines.append(f"- 评分最低：{bottom.get('symbol')}（{bottom.get('name') or '—'}）"
                         f" {bottom.get('score'):+.1f}")
        gate_failed = s.get("gate_failed") or []
        if gate_failed:
            lines.append("- 未达质量门槛：" + "、".join(gate_failed))
        lines.append("")
        if self.failed_rows:
            lines.append("## 失败项")
            for row in self.failed_rows:
                lines.append(f"- {row.symbol}：{row.error or '未知错误'}")
            lines.append("")
        lines.append("---")
        lines.append("## 免责声明")
        lines.append(f"> {self.disclaimer}")
        return "\n".join(lines)


class BatchResearcher:
    """多标的批量研究；单标的异常收敛为一行失败记录。"""

    def __init__(self, hub: Optional[ResearchHub] = None,
                 max_workers: int = 3) -> None:
        self.hub = hub or ResearchHub()
        try:
            self.max_workers = max(1, min(8, int(max_workers)))
        except (TypeError, ValueError):
            self.max_workers = 3

    def run(self, symbols: Any, min_quality: str = "",
            **analyze_kwargs: Any) -> BatchResult:
        items = parse_symbols(symbols)
        if not items:
            raise ValueError("至少需要一个标的代码")
        if len(items) > MAX_BATCH_SYMBOLS:
            raise ValueError("单次最多 %d 个标的（收到 %d 个）"
                             % (MAX_BATCH_SYMBOLS, len(items)))
        gate = str(min_quality or "").strip().lower()
        if gate and gate not in GATE_CHOICES:
            raise ValueError("min_quality 只能是 %s" % "/".join(GATE_CHOICES))

        rows: List[Optional[BatchRow]] = [None] * len(items)
        if len(items) == 1 or self.max_workers == 1:
            for idx, symbol in enumerate(items):
                rows[idx] = self._one(symbol, analyze_kwargs)
        else:
            with ThreadPoolExecutor(max_workers=min(self.max_workers, len(items))) as pool:
                futures = {pool.submit(self._one, symbol, analyze_kwargs): idx
                           for idx, symbol in enumerate(items)}
                for future in as_completed(futures):
                    rows[futures[future]] = future.result()

        result = BatchResult(
            rows=[row for row in rows if row is not None],
            min_quality=gate,
        )
        result.summary = _summarize(result.rows, gate)
        return result

    def _one(self, symbol: str, kwargs: Dict[str, Any]) -> BatchRow:
        try:
            return _row_from_report(symbol, self.hub.analyze(symbol, **kwargs))
        except Exception as exc:  # 单标的失败不能拖垮整批
            message = str(exc)[:300] or type(exc).__name__
            return BatchRow(symbol=symbol, status="error", error=message)


def research_many(symbols: Any, hub: Optional[ResearchHub] = None,
                  min_quality: str = "", max_workers: int = 3,
                  **analyze_kwargs: Any) -> Dict[str, Any]:
    """便捷入口：返回可直接 JSON 序列化的批量研究结果。"""
    result = BatchResearcher(hub=hub, max_workers=max_workers).run(
        symbols, min_quality=min_quality, **analyze_kwargs)
    return result.to_dict()


@dataclass
class ReportDiff:
    """两份研究简报的差异；字段为空的类别表示没有变化。"""
    symbol: str
    old_symbol: str
    new_symbol: str
    fields: List[Dict[str, Any]] = field(default_factory=list)
    forecasts: List[Dict[str, Any]] = field(default_factory=list)
    factors: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    risks: Dict[str, List[str]] = field(default_factory=dict)
    counterpoints: Dict[str, List[str]] = field(default_factory=dict)
    warnings: Dict[str, List[str]] = field(default_factory=dict)
    evidence_delta: int = 0
    notes: List[str] = field(default_factory=list)
    material: bool = False
    verdict: str = ""
    disclaimer: str = DISCLAIMER

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False,
                          indent=indent, default=str)

    def to_markdown(self) -> str:
        lines: List[str] = ["# 研究简报差异", ""]
        lines.append(f"- 标的：`{self.symbol}`"
                     + (f"（旧 {self.old_symbol} → 新 {self.new_symbol}）"
                        if self.old_symbol != self.new_symbol else ""))
        lines.append(f"- 结论：{self.verdict}")
        lines.append(f"- 实质性变化：{'是' if self.material else '否'}")
        for note in self.notes:
            lines.append(f"- ⚠️ {note}")
        lines.append("")

        lines.append("## 核心字段")
        if self.fields:
            lines.append("| 字段 | 旧值 | 新值 | 变化 |")
            lines.append("|---|---|---|---:|")
            for item in self.fields:
                delta = item.get("delta")
                delta_text = (f"{delta:+.4g}" if isinstance(delta, (int, float))
                              else "—")
                lines.append(f"| {item.get('label')} | {item.get('old')} | "
                             f"{item.get('new')} | {delta_text} |")
        else:
            lines.append("核心字段没有变化。")
        lines.append("")

        lines.append("## 周期预测")
        if self.forecasts:
            lines.append("| 周期 | 旧上涨概率 | 新上涨概率 | 变化 | 旧中位 | 新中位 | 说明 |")
            lines.append("|---|---:|---:|---:|---:|---:|---|")
            for item in self.forecasts:
                change = item.get("change", "changed")
                old_up = _fmt_prob(item.get("old_up"), item.get("old_abstain"))
                new_up = _fmt_prob(item.get("new_up"), item.get("new_abstain"))
                delta = item.get("delta")
                delta_text = f"{delta:+.1%}" if isinstance(delta, (int, float)) else "—"
                old_median = _fmt_pct(item.get("old_median"))
                new_median = _fmt_pct(item.get("new_median"))
                lines.append(f"| {item.get('horizon')} | {old_up} | {new_up} | "
                             f"{delta_text} | {old_median} | {new_median} | {change} |")
        else:
            lines.append("周期预测没有变化。")
        lines.append("")

        lines.append("## 因子变化")
        added = (self.factors or {}).get("added") or []
        removed = (self.factors or {}).get("removed") or []
        changed = (self.factors or {}).get("changed") or []
        if added:
            lines.append("- 新增：" + "、".join(str(x) for x in added))
        if removed:
            lines.append("- 移除：" + "、".join(str(x) for x in removed))
        for item in changed:
            lines.append(f"- {item.get('name')}：{item.get('old')} → "
                         f"{item.get('new')}（{item.get('delta'):+.1f}）")
        if not (added or removed or changed):
            lines.append("因子构成没有变化。")
        lines.append("")

        lines.append("## 风险、反方证据与警告")
        rendered = False
        for key, label in (("risks", "风险"), ("counterpoints", "反方证据"),
                           ("warnings", "警告")):
            block = (getattr(self, key) or {})
            if block.get("added"):
                lines.append(f"- 新增{label}：" + "；".join(block["added"]))
                rendered = True
            if block.get("removed"):
                lines.append(f"- 解除{label}：" + "；".join(block["removed"]))
                rendered = True
        if self.evidence_delta:
            lines.append(f"- 证据链数量变化：{self.evidence_delta:+d}")
            rendered = True
        if not rendered:
            lines.append("没有新增或解除的风险项。")
        lines.append("")

        lines.append("---")
        lines.append("## 免责声明")
        lines.append(f"> {self.disclaimer}")
        return "\n".join(lines)


def _fmt_prob(value: Any, abstain: Any) -> str:
    if abstain:
        return "弃权"
    number = safe_float(value, None)
    return f"{number:.1%}" if number is not None else "—"


def _fmt_pct(value: Any) -> str:
    number = safe_float(value, None)
    return f"{number:+.2f}%" if number is not None else "—"


def _add_field(diff: ReportDiff, key: str, label: str, old_value: Any,
               new_value: Any, numeric: bool = False) -> None:
    if old_value == new_value:
        return
    item: Dict[str, Any] = {"key": key, "label": label,
                            "old": old_value, "new": new_value}
    if numeric:
        a = safe_float(old_value, None)
        b = safe_float(new_value, None)
        item["delta"] = round(b - a, 4) if a is not None and b is not None else None
    diff.fields.append(item)


def diff_reports(old: Any, new: Any) -> ReportDiff:
    """对比两份研究简报（对象或字典），返回结构化差异。"""
    old_data = _report_dict(old)
    new_data = _report_dict(new)
    old_symbol = str(old_data.get("symbol") or "")
    new_symbol = str(new_data.get("symbol") or "")
    if not old_symbol or not new_symbol:
        raise ValueError("两份报告都需要 symbol 字段")

    diff = ReportDiff(symbol=new_symbol, old_symbol=old_symbol,
                      new_symbol=new_symbol)
    if old_symbol != new_symbol:
        diff.notes.append("两份报告标的不同（%s → %s），差异仅供参考"
                          % (old_symbol, new_symbol))

    old_quality = old_data.get("data_quality") or {}
    new_quality = new_data.get("data_quality") or {}
    old_score = safe_float(old_data.get("score"), None)
    new_score = safe_float(new_data.get("score"), None)
    old_direction = str(old_data.get("direction") or "")
    new_direction = str(new_data.get("direction") or "")
    old_status = str(old_quality.get("status") or "")
    new_status = str(new_quality.get("status") or "")

    _add_field(diff, "score", "综合评分", old_score, new_score, numeric=True)
    _add_field(diff, "direction", "方向", old_direction, new_direction)
    _add_field(diff, "confidence", "置信度",
               safe_float(old_data.get("confidence"), None),
               safe_float(new_data.get("confidence"), None), numeric=True)
    _add_field(diff, "quality_status", "数据状态", old_status, new_status)
    _add_field(diff, "quality_score", "数据质量分",
               safe_float(old_quality.get("score"), None),
               safe_float(new_quality.get("score"), None), numeric=True)
    _add_field(diff, "data_cutoff", "数据截止",
               str(old_data.get("data_cutoff") or ""),
               str(new_data.get("data_cutoff") or ""))

    old_forecasts = _forecast_rows(old_data)
    new_forecasts = _forecast_rows(new_data)
    horizons = [h for h in _FORECAST_ORDER
                if h in old_forecasts or h in new_forecasts]
    horizons += [h for h in sorted(set(old_forecasts) | set(new_forecasts))
                 if h not in horizons]
    for horizon in horizons:
        old_f = old_forecasts.get(horizon)
        new_f = new_forecasts.get(horizon)
        if old_f is None or new_f is None:
            diff.forecasts.append({
                "horizon": horizon,
                "change": "新增预测" if old_f is None else "预测缺失",
                "old_up": old_f.get("probability_up") if old_f else None,
                "new_up": new_f.get("probability_up") if new_f else None,
                "old_abstain": old_f.get("abstain") if old_f else None,
                "new_abstain": new_f.get("abstain") if new_f else None,
                "old_median": old_f.get("median_return_pct") if old_f else None,
                "new_median": new_f.get("median_return_pct") if new_f else None,
                "delta": None,
            })
            continue
        old_up = old_f.get("probability_up")
        new_up = new_f.get("probability_up")
        delta = (round(new_up - old_up, 4)
                 if old_up is not None and new_up is not None else None)
        abstain_changed = old_f.get("abstain") != new_f.get("abstain")
        materially_moved = delta is not None and abs(delta) >= 0.10
        if delta is None or abs(delta) >= 0.01 or abstain_changed:
            diff.forecasts.append({
                "horizon": horizon,
                "change": ("弃权状态变化" if abstain_changed
                           else "概率调整" if delta and abs(delta) >= 0.01
                           else "已更新"),
                "old_up": old_up,
                "new_up": new_up,
                "old_abstain": old_f.get("abstain"),
                "new_abstain": new_f.get("abstain"),
                "old_median": old_f.get("median_return_pct"),
                "new_median": new_f.get("median_return_pct"),
                "delta": delta,
            })
        if materially_moved:
            diff.notes.append(f"{horizon} 上涨概率变化 {delta:+.0%}，超过 10 个百分点")

    old_factors = _factor_scores(old_data)
    new_factors = _factor_scores(new_data)
    factor_changes: List[Dict[str, Any]] = []
    for name in sorted(set(new_factors) - set(old_factors)):
        factor_changes.append({"change": "added", "name": name,
                               "old": None, "new": new_factors[name]})
    for name in sorted(set(old_factors) - set(new_factors)):
        factor_changes.append({"change": "removed", "name": name,
                               "old": old_factors[name], "new": None})
    for name in sorted(set(old_factors) & set(new_factors)):
        a, b = old_factors[name], new_factors[name]
        if a is None or b is None:
            if a != b:
                factor_changes.append({"change": "changed", "name": name,
                                       "old": a, "new": b, "delta": None})
            continue
        delta = round(b - a, 1)
        if abs(delta) >= 1.0:
            factor_changes.append({"change": "changed", "name": name,
                                   "old": a, "new": b, "delta": delta})
    diff.factors = {
        "added": [x["name"] for x in factor_changes if x["change"] == "added"],
        "removed": [x["name"] for x in factor_changes if x["change"] == "removed"],
        "changed": [x for x in factor_changes if x["change"] == "changed"],
    }

    diff.risks = _string_diff(old_data.get("risks"), new_data.get("risks"))
    diff.counterpoints = _string_diff(old_data.get("counterpoints"),
                                      new_data.get("counterpoints"))
    diff.warnings = _string_diff(old_data.get("warnings"), new_data.get("warnings"))
    diff.evidence_delta = (len(new_data.get("evidence") or [])
                           - len(old_data.get("evidence") or []))

    score_moved = (old_score is not None and new_score is not None
                   and abs(new_score - old_score) >= 10)
    diff.material = bool(score_moved or old_direction != new_direction
                         or old_status != new_status
                         or any(abs(item.get("delta") or 0) >= 0.10
                                for item in diff.forecasts))

    highlights: List[str] = []
    if diff.fields:
        for item in diff.fields:
            if item["key"] == "score":
                if item.get("delta") is not None:
                    highlights.append("评分 %+.1f → %+.1f（%+.1f）"
                                      % (item["old"], item["new"], item["delta"]))
                else:
                    highlights.append("评分 %s → %s" % (item["old"], item["new"]))
            elif item["key"] == "direction":
                highlights.append("方向 %s → %s"
                                  % (_DIRECTION_CN.get(item["old"], item["old"]),
                                     _DIRECTION_CN.get(item["new"], item["new"])))
            elif item["key"] == "quality_status":
                highlights.append("数据状态 %s → %s" % (item["old"], item["new"]))
    if diff.material:
        diff.verdict = "结论发生实质性变化：" + ("；".join(highlights[:3]) or "关键指标越过阈值") + "。"
    elif diff.fields or diff.forecasts or any(diff.factors.values()):
        diff.verdict = "结论未发生实质性变化；" + ("；".join(highlights[:3]) or "仅有小幅调整") + "。"
    else:
        diff.verdict = "两份报告的核心结论与预测没有变化。"
    return diff


def compare_report_files(old_path: Any, new_path: Any) -> ReportDiff:
    """从两个 JSON 文件读取简报并对比。"""
    return diff_reports(load_report(old_path), load_report(new_path))


__all__ = [
    "BatchResearcher", "BatchResult", "BatchRow", "ReportDiff",
    "QUALITY_RANK", "GATE_CHOICES", "MAX_BATCH_SYMBOLS",
    "parse_symbols", "quality_rank", "meets_quality", "load_report",
    "research_many", "diff_reports", "compare_report_files",
]


# LOGGING_AND_COMMENTS_DECISIONS
# - 本模块不写日志：批量与差异都是纯计算，调用方（CLI/MCP）负责把失败项
#   放进结构化结果，避免库内 print 污染 MCP stdio 帧。
# - 注释只保留"为什么"：单标的失败不能拖垮整批、质量门槛为空的语义、
#   10 个百分点/10 分视为实质性变化，这三处阈值不解释就会被误改。
