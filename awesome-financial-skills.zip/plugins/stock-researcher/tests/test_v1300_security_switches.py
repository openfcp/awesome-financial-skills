# -*- coding: utf-8 -*-
"""v13.0 安全边界测试：三处风险行为必须"显式开关 + 默认无副作用"。

覆盖市场评审点名的三类动作：
  1. 导入即改写全局 urllib opener（国内直连）；
  2. 语音兜底悄悄起 PowerShell 子进程；
  3. 外部 MCP 桥按环境变量里的命令启动任意程序。
默认路径上一律不许发生；用户显式打开开关后行为照旧。这里用假的 subprocess 证明
"根本没 fork"，而不是只看返回值。
"""
import os
import subprocess
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from stock_researcher import data_proxy_guard as guard
from stock_researcher import mcp_external_bridge as bridge
from stock_researcher import voice_interface as voice

VOICE_ENV = voice.VOICE_ENV


class _NoFork:
    """替身：任何 fork 都记下来并抛错，测试据此断言"没有起过子进程"。"""

    def __init__(self):
        self.calls = []

    def run(self, *a, **k):
        self.calls.append(("run", a, k))
        raise AssertionError("不应该起子进程")

    def Popen(self, *a, **k):
        self.calls.append(("Popen", a, k))
        raise AssertionError("不应该起子进程")

    def __getattr__(self, name):
        raise AttributeError(name)


def _off(env_name: str) -> dict:
    keys = {VOICE_ENV, guard.ENABLE_ENV, bridge.ENV_ENABLED,
            bridge.ENV_COMMAND, bridge.ENV_NAME, bridge.ENV_PREFIX + "X"}
    out = {k: v for k, v in os.environ.items() if k not in keys}
    out[env_name] = ""
    return out


class TestImportHasNoSideEffects(unittest.TestCase):
    """全新解释器里 import stock_researcher 不许动全局 opener、不许打印。"""

    @staticmethod
    def _spawn_works() -> bool:
        try:
            done = subprocess.run([sys.executable, "-c", "print('ok')"],
                                  capture_output=True, text=True, timeout=30)
            return done.returncode == 0 and "ok" in done.stdout
        except Exception:
            return False

    def test_import_does_not_install_global_opener(self):
        if not self._spawn_works():
            self.skipTest("本机无法起子进程（LibreOffice python 等受限解释器）")
        code = (
            "import sys, urllib.request;"
            "sys.path.insert(0, r'%s');"
            "import stock_researcher;"
            "from stock_researcher import data_proxy_guard as g;"
            "print(urllib.request._opener is None, g.was_checked(), g._installed)"
            % ROOT
        )
        env = {k: v for k, v in os.environ.items() if k != guard.ENABLE_ENV}
        done = subprocess.run([sys.executable, "-c", code], capture_output=True,
                              text=True, timeout=180, env=env, encoding="utf-8",
                              errors="replace")
        self.assertEqual(done.returncode, 0, done.stderr[-400:])
        self.assertEqual(done.stdout.strip(), "True False False",
                         "导入期不应评估或安装直连 opener")


class TestDirectConnectionSwitch(unittest.TestCase):
    def test_disabled_by_default(self):
        with mock.patch.dict(os.environ, _off(guard.ENABLE_ENV), clear=True):
            self.assertFalse(guard.is_enabled_by_env())
            self.assertFalse(guard.enable_direct_connection_from_env())

    def test_env_var_enables_it(self):
        with mock.patch.dict(os.environ, {guard.ENABLE_ENV: "1"}, clear=True):
            self.assertTrue(guard.is_enabled_by_env())
        for value in ("yes", "TRUE", " on ", "y"):
            with mock.patch.dict(os.environ, {guard.ENABLE_ENV: value}, clear=True):
                self.assertTrue(guard.is_enabled_by_env(), value)
        for value in ("", "0", "no", "off"):
            with mock.patch.dict(os.environ, {guard.ENABLE_ENV: value}, clear=True):
                self.assertFalse(guard.is_enabled_by_env(), repr(value))

    def test_ensure_direct_connection_still_works_when_called_explicitly(self):
        """显式调用（脚本入口）仍然是安装 opener 的正门，不能被开关挡住。"""
        installed = guard.ensure_direct_connection()
        self.assertIn(installed, (True, False))    # 首次 True，重复调用幂等 False
        self.assertTrue(guard.is_direct_opener_active())
        self.assertFalse(guard.ensure_direct_connection(), "第二次调用应为跳过")

    def test_network_helpers_only_install_when_switch_on(self):
        from stock_researcher import data_multi_source as dms
        from stock_researcher import research_data as rd

        with mock.patch.dict(os.environ, _off(guard.ENABLE_ENV), clear=True):
            self.assertFalse(dms._enable_direct_connection_if_set())
            self.assertFalse(rd._enable_direct_connection_if_set())


class TestVoiceShellGate(unittest.TestCase):
    def setUp(self):
        # sys.modules 里放 None 会让 import pyttsx3 / vosk 直接 ImportError，
        # 免得本机装了这两个可选依赖时，测试真的出声或真的去开麦克风。
        self._blocked = mock.patch.dict(
            "sys.modules", {"pyttsx3": None, "vosk": None, "sounddevice": None})
        self._blocked.start()
        self.addCleanup(self._blocked.stop)

    def test_auto_engine_does_not_spawn_powershell(self):
        fake = _NoFork()
        with mock.patch.dict(os.environ, _off(VOICE_ENV), clear=True), \
                mock.patch.object(voice, "subprocess", fake):
            self.assertFalse(voice.speak("测试播报"))
            self.assertIsNone(voice.listen_once(timeout=1))
            self.assertFalse(voice.stt_available())
        self.assertEqual(fake.calls, [])

    def test_off_engine_is_always_refused(self):
        fake = _NoFork()
        with mock.patch.dict(os.environ, {VOICE_ENV: "1"}, clear=True), \
                mock.patch.object(voice, "subprocess", fake):
            self.assertFalse(voice.shell_voice_allowed("off"))
            self.assertFalse(voice.speak("测试", engine="off"))
            self.assertIsNone(voice.listen_once(timeout=1, engine="off"))
        self.assertEqual(fake.calls, [])

    def test_explicit_sapi_engine_counts_as_authorization(self):
        want = os.name == "nt" and os.path.exists(voice._PS51)
        with mock.patch.dict(os.environ, _off(VOICE_ENV), clear=True):
            self.assertEqual(voice.shell_voice_allowed("sapi"), want)

    def test_env_var_authorizes_auto_engine(self):
        with mock.patch.dict(os.environ, {VOICE_ENV: "1"}, clear=True):
            want = os.name == "nt" and os.path.exists(voice._PS51)
            self.assertEqual(voice.shell_voice_allowed("auto"), want)
            self.assertEqual(voice.stt_available(), want)

    def test_power_shell_path_is_absolute_system32(self):
        """开关之外再加一道硬约束：只允许调用系统自带的那一个 powershell.exe。"""
        self.assertTrue(voice._PS51.startswith("C:\\Windows\\"))
        self.assertFalse(any(ch in voice._PS51 for ch in ("*", "?")))


class TestExternalMcpGate(unittest.TestCase):
    def test_command_alone_is_not_enough(self):
        env = _off(bridge.ENV_ENABLED)
        env[bridge.ENV_COMMAND] = "python some_mcp_server.py"
        with mock.patch.dict(os.environ, env, clear=True):
            cfg = bridge.load_external_mcp_config()
            self.assertTrue(cfg["configured"])
            self.assertFalse(cfg["enabled_by_env"])
            self.assertFalse(cfg["allowed"])
            self.assertFalse(bridge.external_mcp_allowed(cfg["command"]))

    def test_session_connect_does_not_spawn_without_authorization(self):
        fake = _NoFork()
        env = _off(bridge.ENV_ENABLED)
        env[bridge.ENV_COMMAND] = "python some_mcp_server.py"
        with mock.patch.dict(os.environ, env, clear=True), \
                mock.patch.object(bridge, "subprocess", fake):
            session = bridge.ExternalMCPSession("python some_mcp_server.py", name="t")
            self.assertFalse(session.connect())
            self.assertIsNone(session._process)
            self.assertFalse(bridge.ExternalMCPBridge().connect("t", "python x.py"))
        self.assertEqual(fake.calls, [])

    def test_explicit_allow_is_authorization(self):
        with mock.patch.dict(os.environ, _off(bridge.ENV_ENABLED), clear=True):
            self.assertTrue(bridge.external_mcp_allowed("python x.py", True))
            self.assertFalse(bridge.external_mcp_allowed("", True))
            self.assertFalse(bridge.external_mcp_allowed("   ", True))

    def test_env_switch_is_authorization(self):
        with mock.patch.dict(os.environ, {bridge.ENV_ENABLED: "1"}, clear=True):
            self.assertTrue(bridge.external_mcp_allowed("python x.py"))
            cfg = bridge.load_external_mcp_config()
            self.assertFalse(cfg["allowed"])      # 没配 command 仍然不许
            self.assertTrue(cfg["enabled_by_env"])

    def test_adapter_connect_refuses_before_importing_subprocess(self):
        from stock_researcher import data_multi_source as dms

        adapter = dms.ExternalMCPAdapter(command="python some_mcp_server.py")
        with mock.patch.dict(os.environ, _off(bridge.ENV_ENABLED), clear=True):
            self.assertFalse(adapter.connect())
            self.assertIsNone(adapter._process)
            self.assertFalse(adapter.available)

    def test_router_register_without_authorization_is_false(self):
        """保持既有契约：注册不成功的命令必须返回 False，且不能拉起进程。"""
        from stock_researcher.data_multi_source import get_router

        router = get_router()
        with mock.patch.dict(os.environ, _off(bridge.ENV_ENABLED), clear=True):
            self.assertFalse(router.register_external_mcp("nonexistent_command_xyz"))

    def test_self_check_reports_the_gate(self):
        with mock.patch.dict(os.environ, _off(bridge.ENV_ENABLED), clear=True):
            check = bridge.self_check()
        self.assertIn("allowed", check)
        self.assertIn("enabled_by_env", check)
        self.assertEqual(check["env_vars"]["enabled"], bridge.ENV_ENABLED)


class TestNoStdoutOnImport(unittest.TestCase):
    def test_guard_and_bridge_imports_are_silent(self):
        """MCP stdio 下 stdout 是帧通道：这些模块导入时一个字都不能打。"""
        code = ("import sys; sys.path.insert(0, r'%s');"
                "import stock_researcher.data_proxy_guard, stock_researcher.mcp_external_bridge"
                % ROOT)
        try:
            done = subprocess.run([sys.executable, "-c", code],
                                  capture_output=True, text=True, timeout=120,
                                  encoding="utf-8", errors="replace")
        except Exception as exc:
            self.skipTest("本机无法起子进程: %s" % exc)
        self.assertEqual(done.returncode, 0, done.stderr[-300:])
        self.assertEqual(done.stdout, "")


if __name__ == "__main__":
    unittest.main()
