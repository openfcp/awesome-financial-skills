# -*- coding: utf-8 -*-
"""合并测试套件（离线）：由多个旧测试文件按原顺序拼接，内容未删减。"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
SKILL_DIR = ROOT

# ==================================================================
# 来自 tests/test_v930_quant_forecast.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v9.3 量化预测增强测试（离线，纯逻辑，不联网）。

覆盖：
  - 历史形态匹配预测（pattern_predictor）：降级 / 确定性 / 排序 / 分位 / 标签
  - 基金量化增强：尾部风险 / 回撤恢复 / 稳定性 / NAV 预测 / 便捷函数回归
  - 期货量化增强：置信区间 / 波动率预测 / 仓位建议 / 展期收益
  - quant_analyze_asset 接线 + 顶层导出 + 版本号
"""
import math
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from stock_researcher.constants import VERSION
from stock_researcher.quantitative_pattern_predictor import HistoricalPatternPredictor, quick_pattern_forecast, pattern_direction_label
from stock_researcher.funds import FundQuantAnalyzer, FundPerformance, analyze_fund_performance
from stock_researcher.quantitative_futures_analyzer import FuturesAnalyzer
from stock_researcher.quantitative_asset_quant import quant_analyze_asset


# ── 确定性样本 ──────────────────────────────────────────
def _sine_prices(n=120, drift=0.001, amp=0.03, period=5.0):
    """趋势 + 正弦震荡：形态会周期性重演，保证能匹配到相似窗口。"""
    return [100 * (1 + drift * i) * (1 + amp * math.sin(i / period))
            for i in range(n)]


def _trend_nav(days=400, daily=0.0006, vol=0.008, seed=7):
    random.seed(seed)
    nav = [1.0]
    for _ in range(days):
        nav.append(nav[-1] * (1 + random.gauss(daily, vol)))
    return nav


# ══ 一、历史形态匹配预测 ══════════════════════════════
class TestPatternPredictor:
    def test_insufficient_data(self):
        r = quick_pattern_forecast([100, 101, 102], horizon=5)
        assert r["data_mode"] == "insufficient"
        assert r["confidence"] == 0.0
        assert r["prob_up"] == 50.0, "无数据时不应编造方向"

    def test_deterministic(self):
        prices = _sine_prices()
        r1 = quick_pattern_forecast(prices, horizon=5)
        r2 = quick_pattern_forecast(prices, horizon=5)
        assert r1 == r2, "纯逻辑预测必须可复现"

    def test_basic_forecast_structure(self):
        r = quick_pattern_forecast(_sine_prices(), horizon=5)
        assert r["data_mode"] == "ok"
        assert r["n_matches"] >= 1
        assert 0 <= r["prob_up"] <= 100
        assert 0 <= r["confidence"] <= 100
        assert r["p_low"] <= r["p_high"]
        assert r["current_price"] == round(_sine_prices()[-1], 4)

    def test_top_k_limit_and_sort(self):
        p = HistoricalPatternPredictor(window=20, top_k=3)
        r = p.predict(_sine_prices(150), horizon=5)
        assert len(r["matches"]) <= 3
        sims = [m["similarity"] for m in r["matches"]]
        assert sims == sorted(sims, reverse=True), "匹配应按相似度降序"
        assert all(0 <= s <= 1 for s in sims)

    def test_matches_forward_pct_consistent(self):
        r = quick_pattern_forecast(_sine_prices(), horizon=5)
        fwds = sorted(m["forward_pct"] for m in r["matches"])
        # p_low/p_high 来自 matches 的 forward 收益分位
        assert r["p_low"] >= fwds[0] - 0.01
        assert r["p_high"] <= fwds[-1] + 0.01

    def test_no_match_honest_fallback(self):
        # 恒定价格 → 收益序列全 0 → 形态窗口方差为 0 → 无有效匹配
        flat = [100.0] * 120
        r = HistoricalPatternPredictor().predict(flat, horizon=5)
        assert r["data_mode"] == "no_match"
        assert r["n_matches"] == 0

    def test_direction_label(self):
        up = {"data_mode": "ok", "predicted_pct": 3.0, "confidence": 60}
        down = {"data_mode": "ok", "predicted_pct": -3.0, "confidence": 60}
        flat = {"data_mode": "ok", "predicted_pct": 0.2, "confidence": 60}
        lowconf = {"data_mode": "ok", "predicted_pct": 5.0, "confidence": 10}
        assert pattern_direction_label(up) == "看涨"
        assert pattern_direction_label(down) == "看跌"
        assert pattern_direction_label(flat) == "震荡"
        assert pattern_direction_label(lowconf) == "震荡", "低置信度不应喊方向"
        assert pattern_direction_label({"data_mode": "insufficient"}) == "数据不足"

    def test_window_param_guard(self):
        p = HistoricalPatternPredictor(window=2, top_k=0)
        assert p.window >= 5 and p.top_k >= 1, "参数应有安全下限"


# ══ 二、基金量化增强 ══════════════════════════════════
class TestFundQuantV93:
    def _perf(self):
        nav = _trend_nav()
        bm = [random.gauss(0.0003, 0.01) for _ in range(len(nav) - 1)]
        return FundQuantAnalyzer().analyze_fund(nav, bm, fund_name="v93基金")

    def test_new_fields_exist_and_finite(self):
        p = self._perf()
        for f in ("treynor_ratio", "skewness", "excess_kurtosis",
                  "var_5pct", "stability"):
            assert math.isfinite(getattr(p, f)), f"字段 {f} 应有限"
        assert isinstance(p.recovery_days, int) and p.recovery_days >= 0
        assert isinstance(p.dd_recovered, bool)
        assert 0 <= p.stability <= 100
        assert p.var_5pct <= 0, "5% 分位 VaR 应为负值（亏损方向）"

    def test_insufficient_returns_defaults(self):
        p = FundQuantAnalyzer().analyze_fund([1.0, 1.1], fund_name="短")
        assert p.rating == "C"
        assert p.treynor_ratio == 0.0 and p.stability == 50.0
        assert p.dd_recovered is True

    def test_skew_kurtosis_math(self):
        fqa = FundQuantAnalyzer()
        sym = [-0.02, -0.01, 0.01, 0.02] * 25
        skew, kurt = fqa._skew_kurt(sym)
        assert abs(skew) < 0.2, "对称分布偏度应接近 0"
        crashy = [0.001] * 99 + [-0.2]
        skew2, kurt2 = fqa._skew_kurt(crashy)
        assert skew2 < -1, "单日暴跌应显著负偏"
        assert kurt2 > 3, "单日暴跌应肥尾"

    def test_drawdown_recovery_recovered(self):
        fqa = FundQuantAnalyzer()
        rec = fqa._drawdown_recovery([1.0, 1.2, 0.9, 1.25])
        assert rec == {"recovered": True, "recovery_days": 1}

    def test_drawdown_recovery_unrecovered(self):
        fqa = FundQuantAnalyzer()
        rec = fqa._drawdown_recovery([1.0, 1.2, 0.9, 1.0])
        assert rec["recovered"] is False
        assert rec["recovery_days"] == 1, "谷底至今未收复，应报已持续天数"

    def test_drawdown_recovery_no_drawdown(self):
        fqa = FundQuantAnalyzer()
        rec = fqa._drawdown_recovery([1.0, 1.1, 1.2, 1.3])
        assert rec == {"recovered": True, "recovery_days": 0}

    def test_forecast_nav_uptrend(self):
        nav = [1.0]
        for _ in range(100):
            nav.append(nav[-1] * 1.002)  # 稳定 +0.2%/日
        fc = FundQuantAnalyzer().forecast_nav(nav, days=5)
        assert fc["data_mode"] == "ok"
        assert fc["trend"] == "up"
        assert fc["predicted_nav"] > fc["current_nav"]
        assert fc["low"] <= fc["predicted_nav"] <= fc["high"]

    def test_forecast_nav_flat_and_insufficient(self):
        flat = [1.0] * 100
        fc = FundQuantAnalyzer().forecast_nav(flat, days=5)
        assert fc["data_mode"] == "ok"
        assert fc["trend"] == "flat"
        assert fc["predicted_nav"] == fc["current_nav"]
        assert FundQuantAnalyzer().forecast_nav([1.0, 1.1])["data_mode"] == "insufficient"

    def test_convenience_function_regression(self):
        # v9.2 之前 analyze_fund_performance 引用了不存在的字段会抛 AttributeError
        d = analyze_fund_performance(_trend_nav(), name="回归")
        assert "sharpe" in d and "sortino" in d and "calmar" in d
        for k in ("treynor", "skewness", "excess_kurtosis", "var_5pct",
                  "recovery_days", "dd_recovered", "stability"):
            assert k in d, f"v9.3 新键 {k} 缺失"


# ══ 三、期货量化增强 ══════════════════════════════════
def _fut_prices(seed=11, n=120):
    random.seed(seed)
    prices = [3800.0]
    for _ in range(n - 1):
        prices.append(prices[-1] * (1 + random.gauss(0.0004, 0.012)))
    return prices


class TestFuturesV93:
    def test_predict_futures_confidence_band(self):
        r = FuturesAnalyzer().predict_futures("IF9999", _fut_prices())
        assert "predicted_low" in r and "predicted_high" in r
        assert r["predicted_low"] <= r["predicted"] <= r["predicted_high"]
        assert 0 <= r["confidence"] <= 100
        assert "position_suggestion" in r

    def test_volatility_forecast_ok(self):
        vf = FuturesAnalyzer().volatility_forecast(_fut_prices(), horizon=20)
        assert vf["data_mode"] == "ok"
        assert vf["annual_vol_pct"] > 0
        assert vf["period_vol_pct"] > 0
        assert vf["vol_trend"] in ("扩张", "压缩", "平稳")
        # 区间波动率应随 horizon 单调不降
        vf2 = FuturesAnalyzer().volatility_forecast(_fut_prices(), horizon=60)
        assert vf2["period_vol_pct"] >= vf["period_vol_pct"]

    def test_volatility_forecast_insufficient(self):
        assert FuturesAnalyzer().volatility_forecast([1, 2, 3])["data_mode"] == "insufficient"

    def test_position_size_neutral_and_long(self):
        fa = FuturesAnalyzer()
        prices = _fut_prices()
        assert fa.position_size(prices, "neutral")["position_pct"] == 0.0
        ps = fa.position_size(prices, "long", risk_budget_pct=2.0)
        assert 0 < ps["position_pct"] <= 100
        assert ps["stop_distance_pct"] > 0
        # 风险预算减半 → 仓位减半
        ps_half = fa.position_size(prices, "long", risk_budget_pct=1.0)
        assert abs(ps_half["position_pct"] - ps["position_pct"] / 2) <= 0.2

    def test_roll_yield_contango_and_backwardation(self):
        fa = FuturesAnalyzer()
        contango = fa.roll_yield_estimate([100.0, 100.0], [103.0, 103.0], 30)
        assert contango["structure"] == "contango"
        assert contango["roll_yield_annual_pct"] < 0, "升水下多头展期应亏损"
        back = fa.roll_yield_estimate([100.0, 100.0], [97.0, 97.0], 30)
        assert back["structure"] == "backwardation"
        assert back["roll_yield_annual_pct"] > 0, "贴水下多头展期应获利"
        assert fa.roll_yield_estimate([], [1.0])["data_mode"] == "insufficient"


# ══ 四、接线与导出 ════════════════════════════════════
class TestWiringV93:
    def test_quant_analyze_asset_pattern_forecast(self):
        r = quant_analyze_asset("600519", prices=_sine_prices())
        pf = r["pattern_forecast"]
        assert set(pf.keys()) == {"short", "medium"}
        for k in pf:
            assert "predicted_pct" in pf[k]
            assert pf[k]["direction_label"] in ("看涨", "看跌", "震荡", "数据不足")

    def test_quant_analyze_asset_short_prices(self):
        r = quant_analyze_asset("600519", prices=[100.0, 101.0])
        assert r["pattern_forecast"] == {}, "数据不足时形态预测应为空而非报错"

    def test_top_level_exports_and_version(self):
        import stock_researcher
        # v9.5 起版本断言跟随最新版本（原 9.3.0）
        assert stock_researcher.__version__ == VERSION
        from stock_researcher import HistoricalPatternPredictor as TopCls, quick_pattern_forecast as top_fn, pattern_direction_label as top_label
        assert TopCls.__name__ == "HistoricalPatternPredictor"
        assert callable(top_fn) and callable(top_label)
        r = top_fn(_sine_prices(), horizon=5)
        assert r["data_mode"] == "ok"

    def test_version_consistency_v93(self):
        """v9.3 版本一致性接管：constants / _meta / settings / SKILL 四处一致。"""
        import json
        root = Path(__file__).resolve().parents[1]
        const = (root / "stock_researcher" / "constants.py").read_text(encoding="utf-8")
        assert f'VERSION = "{VERSION}"' in const
        meta = json.loads((root / "_meta.json").read_text(encoding="utf-8"))
        assert meta["version"] == VERSION
        settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
        assert settings["version"] == VERSION
        skill = (root / "SKILL.md").read_text(encoding="utf-8")
        assert f"version: {VERSION}" in skill

# ==================================================================
# 来自 tests/test_v940_quant_voice.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v9.4 升级回归测试 — 高级量化统计计算 + 语音交互（离线，不联网）。

覆盖：
  1. advanced_stats：滚动指标/稳定性/回撤剖析/仓位计算/统计检验/自相关/业绩归因/相关矩阵/一站式体检
  2. voice_command：播报压缩 / 口语指令解析；voice_interface：VoiceResearchChat 假回调闭环
  3. 接线：quantitative 包导出 + 顶层懒加载导出 + 版本一致性
"""
import math
import random
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from stock_researcher.quantitative_advanced_stats import rolling_metrics, rolling_stability, drawdown_report, kelly_fraction, fixed_fractional_size, vol_target_weight, skewness, kurtosis, jarque_bera, autocorrelation, ljung_box, tracking_error, information_ratio, up_down_capture, correlation_matrix, quick_advanced_stats
from stock_researcher.voice_command import summarize_for_speech, parse_voice_command
from stock_researcher.constants import VERSION
V_TAG = "v" + ".".join(VERSION.split(".")[:2])

try:
    from stock_researcher.voice_interface import VoiceResearchChat
except ImportError:
    # 上架包剔除了 voice_interface（SAPI shell 支路），交付副本只跑纯文本用例。
    VoiceResearchChat = None

needs_voice_shell = pytest.mark.skipif(
    VoiceResearchChat is None, reason="上架包不含 voice_interface，跳过会话用例")


# ── 确定性样本 ──────────────────────────────────────────────

def _trend_prices(n=200, drift=0.001, vol=0.01, seed=42):
    random.seed(seed)
    p, out = 100.0, []
    for _ in range(n):
        p *= 1 + drift + random.gauss(0, vol)
        out.append(p)
    return out


def _returns(prices):
    return [prices[i] / prices[i - 1] - 1 for i in range(1, len(prices))]


# ══════════════ 1. 滚动指标与稳定性 ══════════════

def test_rolling_metrics_shape_and_fields():
    prices = _trend_prices(120)
    rm = rolling_metrics(prices, window=60)
    assert len(rm) == len(prices) - 60
    row = rm[-1]
    for k in ("index", "ann_return", "ann_vol", "sharpe", "max_drawdown"):
        assert k in row
    assert row["ann_vol"] >= 0 and row["max_drawdown"] <= 0


def test_rolling_metrics_insufficient_returns_empty():
    assert rolling_metrics([100, 101, 102], window=60) == []
    assert rolling_metrics(_trend_prices(30), window=4) == []   # window < 5


def test_rolling_stability():
    prices = _trend_prices(150)
    roll = rolling_metrics(prices, window=60)
    st = rolling_stability(roll, "sharpe")
    assert st["available"] and st["n"] == len(roll)
    assert 0.0 <= st["positive_ratio"] <= 1.0
    assert isinstance(st["stable"], bool)
    assert rolling_stability([{"sharpe": 0.1}], "sharpe")["available"] is False


# ══════════════ 2. 回撤剖析 ══════════════

def test_drawdown_report_known_sequence():
    prices = [100, 90, 80, 85, 110, 99]
    rep = drawdown_report(prices)
    assert rep["max_drawdown"] == pytest.approx(-0.2, abs=1e-9)
    assert rep["n_drawdowns"] >= 2
    first = rep["drawdowns"][0]
    assert first["recovered"] is True and first["recovery_days"] is not None


def test_drawdown_report_ongoing_unrecovered():
    prices = [100, 110, 90, 85]          # 110 → 85 未恢复
    rep = drawdown_report(prices)
    assert rep["drawdowns"][0]["recovered"] is False
    assert rep["max_drawdown"] == pytest.approx(85 / 110 - 1, abs=1e-9)


def test_drawdown_report_empty():
    rep = drawdown_report([100])
    assert rep["n_drawdowns"] == 0 and rep["max_drawdown"] == 0.0


# ══════════════ 3. 仓位计算 ══════════════

def test_kelly_fraction_math():
    k = kelly_fraction(0.6, 2.0, fraction=0.5, cap=0.25)
    assert k["full_kelly"] == pytest.approx(0.6 - 0.4 / 2)      # 0.4
    assert k["suggested"] == pytest.approx(0.2)                 # 半凯利
    assert k["edge"] > 0 and k["capped"] is False


def test_kelly_fraction_cap_and_negative_edge():
    k = kelly_fraction(0.9, 5.0, fraction=1.0, cap=0.25)
    assert k["suggested"] == pytest.approx(0.25) and k["capped"] is True
    k2 = kelly_fraction(0.3, 1.0)          # 期望为负 → 不应下注
    assert k2["edge"] < 0 and k2["suggested"] == 0.0


def test_fixed_fractional_size():
    r = fixed_fractional_size(100000, 0.02, entry=100.0, stop=95.0)
    assert r["risk_amount"] == pytest.approx(2000)
    assert r["shares"] == pytest.approx(400)
    assert r["lots_a_share"] == 4
    assert r["position_value"] == pytest.approx(40000)
    bad = fixed_fractional_size(100000, 0.02, entry=100, stop=100)
    assert bad["shares"] == 0


def test_vol_target_weight():
    rets = _returns(_trend_prices(120))
    w = vol_target_weight(rets, target_vol=0.15)
    assert 0.0 <= w["weight"] <= 1.0 and w["ann_vol"] > 0
    # 零波动 → 满仓（封顶）
    w0 = vol_target_weight([0.0] * 60, target_vol=0.15)
    assert w0["weight"] == 1.0
    # 样本不足 → 0
    assert vol_target_weight([0.01, 0.02])["weight"] == 0.0


# ══════════════ 4. 统计检验 ══════════════

def test_skewness_kurtosis_edge_cases():
    assert skewness([1.0, 2.0]) is None
    assert kurtosis([1.0, 2.0, 3.0]) is None
    assert skewness([5.0] * 10) == 0.0     # 零方差
    assert kurtosis([5.0] * 10) == 0.0


def test_skewness_direction():
    random.seed(3)
    base = [random.gauss(0, 1) for _ in range(500)]
    left_tail = base + [-8.0, -9.0, -10.0]
    assert skewness(left_tail) < -0.5      # 左尾肥 → 负偏度


def test_jarque_bera():
    rets = _returns(_trend_prices(200))
    jb = jarque_bera(rets)
    assert jb["available"] and jb["statistic"] >= 0
    assert 0.0 <= jb["p_value"] <= 1.0
    assert jb["verdict"]
    assert jarque_bera([0.01] * 5)["available"] is False


def test_autocorrelation_directions():
    momentum = [0.01] * 50 + [0.02] * 50        # 持续 → 正自相关
    assert autocorrelation(momentum, 1) > 0
    alternating = [(-1) ** i * 0.01 for i in range(60)]
    assert autocorrelation(alternating, 1) < -0.5
    assert autocorrelation([0.01, 0.02], 1) is None


def test_ljung_box():
    rets = _returns(_trend_prices(250))
    lb = ljung_box(rets, lags=10)
    assert lb["available"] and lb["lags"] == 10
    assert lb["statistic"] >= 0 and 0.0 <= lb["p_value"] <= 1.0
    assert len(lb["acf"]) == 10
    assert ljung_box(rets[:10])["available"] is False


# ══════════════ 5. 业绩归因 ══════════════

def test_tracking_error_and_ir_identical():
    rets = _returns(_trend_prices(100))
    assert tracking_error(rets, rets) == pytest.approx(0.0, abs=1e-12)
    assert information_ratio(rets, rets) is None   # TE=0 → 无定义


def test_information_ratio_positive_for_outperformer():
    random.seed(5)
    bench = [random.gauss(0.0005, 0.01) for _ in range(200)]
    active = [b + 0.001 + random.gauss(0, 0.002) for b in bench]
    ir = information_ratio(active, bench)
    assert ir is not None and ir > 0
    assert tracking_error(active, bench) > 0


def test_up_down_capture_verdicts():
    random.seed(6)
    bench = [random.gauss(0, 0.01) for _ in range(200)]
    # 进攻型：跟涨 1.2 倍，回撤也 1.2 倍
    aggressive = [b * 1.2 for b in bench]
    cap = up_down_capture(aggressive, bench)
    assert cap["up_capture"] == pytest.approx(1.2, abs=1e-9)
    assert cap["verdict"] == "进攻型（跟涨强，回撤也大）"
    # 防御型：涨时弱、跌时抗跌
    defensive = [b * 0.8 if b > 0 else b * 0.5 for b in bench]
    cap2 = up_down_capture(defensive, bench)
    assert cap2["verdict"] == "防御型（抗跌但跟涨弱）"
    assert cap2["capture_ratio"] == pytest.approx(
        cap2["up_capture"] / cap2["down_capture"])


def test_up_down_capture_insufficient():
    assert up_down_capture([0.01] * 3, [0.01] * 3)["verdict"] == "样本不足"


# ══════════════ 6. 相关矩阵与一站式体检 ══════════════

def test_correlation_matrix():
    a = [float(i) for i in range(30)]
    b = [2 * x + 5 for x in a]
    c = [-x for x in a]
    out = correlation_matrix({"A": a, "B": b, "C": c})
    assert out["n_series"] == 3
    assert out["pairs"][("A", "B")] == pytest.approx(1.0, abs=1e-9)
    assert out["pairs"][("A", "C")] == pytest.approx(-1.0, abs=1e-9)
    short = correlation_matrix({"X": [1, 2], "Y": [2, 3]})
    assert short["pairs"][("X", "Y")] is None


def test_quick_advanced_stats_short_and_full():
    assert quick_advanced_stats([100, 101])["available"] is False
    prices = _trend_prices(200)
    r = quick_advanced_stats(prices, window=60)
    assert r["available"]
    assert r["rolling"]["n_windows"] == len(prices) - 60
    assert r["drawdown"]["max_drawdown"] <= 0
    assert 0.0 <= r["kelly"]["suggested"] <= 0.25
    assert r["stats_tests"]["jarque_bera"]["available"]
    assert 0.0 <= r["position"]["weight"] <= 1.0
    assert "attribution" not in r          # 未给基准


def test_quick_advanced_stats_with_benchmark():
    prices = _trend_prices(160)
    bench = _trend_prices(160, drift=0.0005, seed=7)
    r = quick_advanced_stats(prices, benchmark=bench)
    attr = r["attribution"]
    assert attr["tracking_error"] is not None
    assert "up_down_capture" in attr


# ══════════════ 7. 语音：播报压缩 ══════════════

def test_summarize_for_speech_strips_markdown_and_url():
    reply = "## 预测结果\n**评分 78/100**\n- 5日上涨概率 62%，详见：https://x.com/a"
    out = summarize_for_speech(reply)
    assert "http" not in out and "#" not in out and "**" not in out
    assert "评分" in out and "62" in out


def test_summarize_for_speech_truncates():
    reply = "。".join(f"第{i}条预测结论内容比较长" for i in range(80))
    out = summarize_for_speech(reply, max_chars=100)
    assert len(out) <= 120
    assert out.endswith("（更多内容见终端输出）")


def test_summarize_for_speech_empty():
    assert summarize_for_speech("") == ""


# ══════════════ 8. 语音：口语指令解析 ══════════════

def test_parse_predict_with_alias():
    cmd = parse_voice_command("预测茅台")
    assert cmd["intent"] == "predict" and cmd["code"] == "600519"
    assert cmd["echo"]
    cmd2 = parse_voice_command("帮我分析一下腾讯")
    assert cmd2["code"] == "hk:00700"


def test_parse_predict_numeric_and_us_code():
    assert parse_voice_command("分析600519")["code"] == "600519"
    assert parse_voice_command("看看 300750")["code"] == "300750"
    assert parse_voice_command("分析美股AAPL")["code"] == "us:AAPL"


def test_parse_v90_intents():
    assert parse_voice_command("A股板块排名")["intent"] == "sector_ranking"
    hk = parse_voice_command("港股板块强度对比")
    assert hk["intent"] == "sector_ranking" and hk["params"]["market"] == "hk"
    reg = parse_voice_command("上证指数体制怎么样")
    assert reg["intent"] == "index_regime" and reg["code"] == "idx:SSE"
    assert parse_voice_command("上证指数体制")["code"] == "idx:SSE"
    assert parse_voice_command("情景分析")["intent"] == "scenario"
    td = parse_voice_command("自上而下美股全景")
    assert td["intent"] == "topdown" and td["params"]["market"] == "us"


def test_parse_quant_check_help_exit_unknown():
    qc = parse_voice_command("量化体检招商银行")
    assert qc["intent"] == "quant_check" and qc["code"] == "600036"
    assert parse_voice_command("量化体检")["code"] is None     # 需追问标的
    assert parse_voice_command("帮助")["intent"] == "help"
    assert parse_voice_command("退出")["intent"] == "exit"
    assert parse_voice_command("你好啊谢谢")['intent'] == "unknown"
    assert parse_voice_command("")["intent"] == "unknown"


# ══════════════ 9. 语音：会话闭环（假回调） ══════════════

@needs_voice_shell
def test_voice_chat_handle_text_with_fake_executor():
    spoken = []
    vc = VoiceResearchChat(
        executor=lambda cmd: f"已执行:{cmd['intent']}:{cmd.get('code')}",
        speak_fn=lambda t: spoken.append(t) or True,
        tts=True)
    reply = vc.handle_text("预测茅台")
    assert reply == "已执行:predict:600519"
    assert vc.history[-1]["user"] == "预测茅台"
    assert spoken, "TTS 未被调用"


@needs_voice_shell
def test_voice_chat_no_tts_and_history():
    vc = VoiceResearchChat(executor=lambda cmd: "ok", tts=False)
    assert vc.handle_text("你好") == "ok"
    assert len(vc.history) == 1


@needs_voice_shell
def test_voice_chat_default_executor_help_offline():
    """默认执行器处理 help/exit 不触网。"""
    vc = VoiceResearchChat(tts=False)
    assert "支持指令" in vc._default_execute({"intent": "help"})
    assert "退出" in vc._default_execute({"intent": "exit"})
    assert "没听懂" in vc._default_execute({"intent": "unknown"})


@needs_voice_shell
def test_voice_chat_run_text_mode(monkeypatch):
    """非默认 listen → 文本输入循环，max_turns 与 exit 均可终止。"""
    lines = iter(["预测茅台", "退出"])
    monkeypatch.setattr("builtins.input", lambda *_: next(lines))
    executed = []
    vc = VoiceResearchChat(
        listen=lambda timeout=8: None,      # 非 listen_once → 文本路径
        executor=lambda cmd: executed.append(cmd["intent"]) or "ok",
        tts=False)
    vc.run(max_turns=5)
    assert executed[:2] == ["predict", "exit"]
    assert len(vc.history) == 2


# ══════════════ 10. 接线与版本 ══════════════

def test_quantitative_package_exports():
    from stock_researcher import quantitative_advanced_stats as q
    for name in ("rolling_metrics", "drawdown_report", "kelly_fraction",
                 "jarque_bera", "ljung_box", "up_down_capture",
                 "correlation_matrix", "quick_advanced_stats"):
        assert hasattr(q, name), f"quantitative 缺少导出 {name}"


def test_top_level_lazy_exports():
    import stock_researcher as sr
    assert sr.__version__ == VERSION
    for name in ("rolling_metrics", "rolling_stability", "drawdown_report",
                 "kelly_fraction", "fixed_fractional_size", "vol_target_weight",
                 "skewness", "kurtosis", "jarque_bera", "autocorrelation",
                 "ljung_box", "tracking_error", "information_ratio",
                 "up_down_capture", "correlation_matrix", "quick_advanced_stats",
                 "parse_voice_command", "summarize_for_speech"):
        assert getattr(sr, name) is not None, f"顶层缺少导出 {name}"
    if VoiceResearchChat is not None:
        assert getattr(sr, "VoiceResearchChat") is not None


def test_version_files_consistent_940():
    import json
    root = Path(__file__).resolve().parents[1]
    meta = json.loads((root / "_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == VERSION
    assert meta["maintenance"]["changelog"][0]["version"] == VERSION
    settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
    assert settings["version"] == VERSION
    assert settings["_version_info"]["version"] == VERSION

# ==================================================================
# 来自 tests/test_v950_masters_perf.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v9.5 升级回归测试 — 大佬策略参考面板 + 分析性能优化（离线，不联网）。

覆盖：
  1. MasterInput：快照构建与派生特征（动量/波动/回撤/52周位置）
  2. 六位大佬策略：索罗斯/费雪/达利欧/马克斯/格林布拉特/利弗莫尔 方向性 + 降级
  3. MasterCouncil：圆桌加权共识/一致度/中文报告
  4. 性能优化：行情+K线并行拉取 / predict 并行链路冒烟
  5. 接线：语音意图 masters + 顶层懒加载导出 + 版本一致性
"""
import json
import math
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from stock_researcher.constants import VERSION
from stock_researcher.agents_master_input import MasterInput, MasterResult, score_to_signal
from stock_researcher.agents_master_council import MasterCouncil, CouncilReport, quick_master_council
from stock_researcher.agents_soros import SorosAnalyzer
from stock_researcher.agents_fisher import FisherAnalyzer
from stock_researcher.agents_dalio import DalioAnalyzer
from stock_researcher.agents_marks import MarksAnalyzer
from stock_researcher.agents_greenblatt import GreenblattAnalyzer
from stock_researcher.agents_livermore import LivermoreAnalyzer


# ── 确定性样本 ──────────────────────────────────────────────

def _up_series(n=300, daily=0.002):
    """平滑上行序列（低波动牛市代理）"""
    p, out = 100.0, []
    for _ in range(n):
        p *= 1 + daily
        out.append(p)
    return out


def _down_series(n=300, daily=-0.003):
    """平滑下行序列（熊市代理）"""
    p, out = 100.0, []
    for _ in range(n):
        p *= 1 + daily
        out.append(p)
    return out


def _bull_snapshot(**kw):
    defaults = dict(code="600519", name="测试牛", price=0, pe=25,
                    roe=20, revenue_growth=25, net_margin=22,
                    closes=_up_series())
    defaults.update(kw)
    return MasterInput.from_market(**defaults)


def _bear_snapshot(**kw):
    defaults = dict(code="600519", name="测试熊", price=0, pe=60,
                    roe=-3, revenue_growth=-12, net_margin=-5,
                    closes=_down_series())
    defaults.update(kw)
    return MasterInput.from_market(**defaults)


# ══════════════ 1. MasterInput 快照与派生特征 ══════════════

def test_master_input_derived_features():
    inp = MasterInput.from_market(code="600519", closes=_up_series())
    assert inp.has_prices
    assert inp.ret_20 > 0 and inp.ret_60 > inp.ret_20
    assert inp.ann_vol >= 0
    assert inp.max_dd_250 <= 0
    assert 0.99 <= inp.pos_52w <= 1.0          # 平滑上行 → 顶部
    assert inp.price == pytest.approx(inp.closes[-1])


def test_master_input_bear_position_at_bottom():
    inp = MasterInput.from_market(closes=_down_series())
    assert 0.0 <= inp.pos_52w <= 0.02
    assert inp.ret_250 < -30


def test_master_input_insufficient_data():
    inp = MasterInput.from_market(closes=[100.0] * 5)
    assert not inp.has_prices
    assert inp.ret_20 == 0 and inp.ann_vol == 0


def test_master_input_filters_bad_prices():
    inp = MasterInput.from_market(closes=[0, -1, None, 100, 101] + [102] * 30)
    assert all(c > 0 for c in inp.closes)


def test_score_to_signal_mapping():
    assert score_to_signal(60) == "强烈买入"
    assert score_to_signal(30) == "买入"
    assert score_to_signal(0) == "中性"
    assert score_to_signal(-30) == "卖出"
    assert score_to_signal(-60) == "强烈卖出"
    assert score_to_signal(90, confidence=0.1) == "数据不足"


# ══════════════ 2. 六位大佬策略 ══════════════

def test_soros_bull_positive_bear_negative():
    az = SorosAnalyzer()
    bull, bear = az.analyze(_bull_snapshot()), az.analyze(_bear_snapshot())
    assert bull.score > 0 and bull.signal in ("买入", "强烈买入")
    assert bear.score < 0
    assert any("盛衰" in p or "反身" in p for p in bull.key_points)


def test_soros_no_prices_degrades():
    r = SorosAnalyzer().analyze(MasterInput())
    assert r.signal == "数据不足" and r.confidence == 0


def test_fisher_growth_scoring():
    az = FisherAnalyzer()
    bull = az.analyze(_bull_snapshot(pe=30))
    assert bull.score > 0                       # 高成长+高利润率+合理PEG
    bear = az.analyze(_bear_snapshot(pe=90))
    assert bear.score < 0                       # 负增长+亏损+高估值


def test_fisher_no_data_degrades():
    r = FisherAnalyzer().analyze(MasterInput())
    assert r.signal == "数据不足"


def test_dalio_quadrant_direction():
    az = DalioAnalyzer()
    bull, bear = az.analyze(_bull_snapshot()), az.analyze(_bear_snapshot())
    assert bull.score > 0
    assert bear.score < 0
    assert abs(bull.score) <= 60 and abs(bear.score) <= 60   # 宏观视角保守上限
    assert any("分散" in p for p in bull.key_points)


def test_marks_contrarian_temperature():
    az = MarksAnalyzer()
    hot = az.analyze(_bull_snapshot(pe=60))     # 高位+高估值+强动量 → 高温低分
    cold = az.analyze(_bear_snapshot(pe=8))     # 低位+低估值 → 低温高分
    assert hot.score < 0 < cold.score
    assert any("风险温度" in p for p in hot.key_points)
    assert any("钟摆" in p for p in cold.key_points)


def test_greenblatt_magic_formula():
    az = GreenblattAnalyzer()
    good = az.analyze(MasterInput.from_market(pe=12, roe=22, closes=_up_series()))
    bad = az.analyze(MasterInput.from_market(pe=90, roe=-3, closes=_up_series()))
    assert good.score > 0 and bad.score < 0
    r = az.analyze(MasterInput())
    assert r.signal == "数据不足"


def test_livermore_trend_structure():
    az = LivermoreAnalyzer()
    bull, bear = az.analyze(_bull_snapshot()), az.analyze(_bear_snapshot())
    assert bull.score > 0 and bull.signal in ("买入", "强烈买入")
    assert bear.score < 0
    assert any("关键点" in p or "多头排列" in p for p in bull.key_points)


def test_livermore_no_prices_degrades():
    r = LivermoreAnalyzer().analyze(MasterInput())
    assert r.signal == "数据不足"


# ══════════════ 3. MasterCouncil 圆桌共识 ══════════════

def test_council_full_snapshot_consensus():
    rep = MasterCouncil().analyze(_bull_snapshot(pe=25))
    assert rep.valid_count == 6
    assert -100 <= rep.consensus_score <= 100
    assert rep.consensus_signal != "数据不足"
    assert 0 <= rep.agreement <= 1
    assert rep.most_bullish and rep.most_bearish
    assert len(rep.results) == 6


def test_council_empty_snapshot_all_degrade():
    rep = MasterCouncil().analyze(MasterInput())
    assert rep.valid_count == 0
    assert rep.consensus_signal == "数据不足"


def test_council_format_report():
    rep = MasterCouncil().analyze(_bull_snapshot())
    txt = MasterCouncil.format(rep)
    assert "大佬圆桌" in txt
    for name in ("索罗斯", "费雪", "达利欧", "马克斯", "格林布拉特", "利弗莫尔"):
        assert name in txt
    assert "圆桌共识" in txt
    assert "不构成投资建议" in txt


def test_council_custom_weights():
    w = {"livermore": 1.0}  # 仅趋势大佬有权重，其余按默认小权重
    rep = MasterCouncil(weights=w).analyze(_bull_snapshot())
    assert rep.weights["livermore"] == 1.0
    assert rep.consensus_score != 0


def test_quick_master_council_helper():
    rep = quick_master_council(_bear_snapshot())
    assert isinstance(rep, CouncilReport)
    assert rep.valid_count >= 1


# ══════════════ 4. 性能优化 ══════════════

def test_fetch_quote_kline_parallel(monkeypatch):
    """行情+K线并行拉取：两个独立请求都返回结果"""
    import stock_predict as sp
    calls = []

    def fake_quote(code, silent=False, max_retries=3):
        calls.append("quote")
        return {"price": 10.0, "name": code}

    def fake_kline(code, days=120, silent=False):
        calls.append("kline")
        return [{"close": 10.0}]

    monkeypatch.setattr(sp, "fetch_quote", fake_quote)
    monkeypatch.setattr(sp, "fetch_kline", fake_kline)
    q, kl = sp.fetch_quote_kline("600519")
    assert q["price"] == 10.0 and kl
    assert calls.count("quote") == 1 and calls.count("kline") == 1


def test_predict_parallel_pipeline_smoke(monkeypatch):
    """predict 并行链路冒烟：假行情+假K线 → 完整评分输出"""
    import stock_predict as sp
    kl = [{"date": f"d{i}", "open": 10.0, "close": 10.0 + i * 0.01,
           "high": 11.0, "low": 9.5, "vol": 10000.0} for i in range(130)]

    monkeypatch.setattr(sp, "fetch_quote", lambda code, silent=False, max_retries=3: {
        "name": "测试股", "code": code, "market": "cn", "price": 11.3,
        "prev_close": 11.2, "open": 11.2, "vol": 1e6, "high": 11.4,
        "low": 11.1, "amount": 1e8, "change": 0.1, "chg_pct": 0.9,
        "pe": 15.0, "turnover": 1.2, "currency": "CNY"})
    monkeypatch.setattr(sp, "fetch_kline", lambda code, days=120, silent=False: kl)
    monkeypatch.setattr(sp, "_get_cached_risk_appetite", lambda: None)
    monkeypatch.setattr(sp, "_get_cached_gold_factors", lambda: None)

    r = sp.predict("600519", silent=True)
    assert "error" not in r
    assert r["technical"]["atr"] >= 0
    assert r["technical"]["atr_pct"] >= 0
    assert 0 <= r["score"]["total"] <= 100
    assert r["monte_carlo"]["5d"]["up"] >= 0


def test_predict_quote_error_short_circuit(monkeypatch):
    """行情失败时并行链路仍正确短路返回错误"""
    import stock_predict as sp
    monkeypatch.setattr(sp, "fetch_quote", lambda *a, **k: {"error": "网络失败"})
    monkeypatch.setattr(sp, "fetch_kline", lambda *a, **k: [])
    r = sp.predict("600519", silent=True)
    assert "error" in r and r["code"] == "600519"


# ══════════════ 5. 接线：语音意图 + 导出 + 版本 ══════════════

def test_voice_intent_masters():
    from stock_researcher.voice_command import parse_voice_command
    cmd = parse_voice_command("大佬们怎么看茅台")
    assert cmd["intent"] == "masters" and cmd["code"] == "600519"
    cmd2 = parse_voice_command("圆桌讨论600519")
    assert cmd2["intent"] == "masters" and cmd2["code"] == "600519"
    cmd3 = parse_voice_command("大师们怎么看")
    assert cmd3["intent"] == "masters" and cmd3["code"] is None
    cmd4 = parse_voice_command("帮助")
    assert "大佬圆桌" in cmd4["echo"]


def test_agents_package_exports():
    # 平铺后 agents 命名空间由 agents_* 平铺模块聚合
    import types
    import stock_researcher.agents_master_input as _mi
    import stock_researcher.agents_master_council as _mc
    import stock_researcher.agents_buffett as _bu
    import stock_researcher.agents_graham as _gr
    import stock_researcher.agents_lynch as _ly
    ag = types.SimpleNamespace()
    for _m in (_mi, _mc, _bu, _gr, _ly):
        for _k in dir(_m):
            if not _k.startswith("_"):
                setattr(ag, _k, getattr(_m, _k))
    for name in ("MasterInput", "MasterResult", "score_to_signal",
                 "SorosAnalyzer", "FisherAnalyzer", "DalioAnalyzer",
                 "MarksAnalyzer", "GreenblattAnalyzer", "LivermoreAnalyzer",
                 "MasterCouncil", "CouncilReport", "quick_master_council",
                 "BuffettAnalyzer", "GrahamAnalyzer", "LynchAnalyzer"):
        assert hasattr(ag, name), name


def test_top_level_lazy_exports_masters():
    import stock_researcher as sr
    # 双重导入路径下不做 identity 断言，校验懒加载导出存在且类名正确（同 test_v940 写法）
    for name in ("MasterInput", "MasterResult", "score_to_signal",
                 "SorosAnalyzer", "FisherAnalyzer", "DalioAnalyzer",
                 "MarksAnalyzer", "GreenblattAnalyzer", "LivermoreAnalyzer",
                 "MasterCouncil", "CouncilReport", "quick_master_council"):
        obj = getattr(sr, name)
        assert obj is not None, f"顶层缺少导出 {name}"
    assert sr.MasterCouncil.__name__ == "MasterCouncil"
    assert sr.MasterInput.__name__ == "MasterInput"
    assert callable(sr.quick_master_council)
    assert sr.__version__ == VERSION


def test_version_sync_all_files():
    """v9.5 版本同步：7 处来源一致"""
    root = Path(__file__).resolve().parents[1]
    import re as _re
    import stock_researcher
    assert stock_researcher.__version__ == VERSION

    init = (root / "stock_researcher" / "__init__.py").read_text(encoding="utf-8")
    const = (root / "stock_researcher" / "constants.py").read_text(encoding="utf-8")
    m_init = _re.search(r"__version__\s*=\s*[\"']([^\"']+)[\"']", init)
    m_const = _re.search(r"VERSION\s*=\s*[\"']([^\"']+)[\"']", const)
    assert m_init and m_init.group(1) == VERSION
    assert m_const and m_const.group(1) == VERSION

    meta = json.loads((root / "_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == VERSION
    assert meta["maintenance"]["changelog"][0]["version"] == VERSION
    settings = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
    assert settings["version"] == VERSION
    assert settings["_version_info"]["version"] == VERSION
    skill = (root / "SKILL.md").read_text(encoding="utf-8")
    assert f"version: {VERSION}" in skill
