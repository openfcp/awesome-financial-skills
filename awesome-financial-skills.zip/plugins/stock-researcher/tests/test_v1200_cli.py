﻿# -*- coding: utf-8 -*-
"""v12 CLI 离线自检测试。"""
import contextlib
import importlib.util
import io
import json
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def load_cli():
    path = ROOT / "scripts" / "research_hub_cli.py"
    spec = importlib.util.spec_from_file_location("research_hub_cli_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestCLI(unittest.TestCase):
    def test_doctor_offline(self):
        cli = load_cli()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = cli.main(["doctor", "--offline"])
        self.assertEqual(code, 0)
        payload = json.loads(buf.getvalue())
        self.assertEqual(payload["status"], "ok")
        self.assertEqual(payload["version"], "14.0.0")
        self.assertEqual(payload["schema_version"], "12.0")

    def test_parser_has_core_commands(self):
        cli = load_cli()
        parser = cli.build_parser()
        help_text = parser.format_help()
        for cmd in ("doctor", "live", "analyze", "file"):
            self.assertIn(cmd, help_text)
        self.assertIsNotNone(cli.main(["doctor", "--offline"]))
