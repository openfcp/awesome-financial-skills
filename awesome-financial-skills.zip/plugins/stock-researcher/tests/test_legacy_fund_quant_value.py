# -*- coding: utf-8 -*-
"""合并测试套件（离线）：由多个旧测试文件按原顺序拼接，内容未删减。"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
SKILL_DIR = ROOT

# ==================================================================
# 来自 tests/test_fund_v3.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基金 v3 评分测试（v5.0 新增）

测试 v3 新增维度：
- Sortino 比率（仅惩罚下行波动）
- 最大回撤 + Calmar 比率
- 持仓穿透风格推断
- 费率性价比评分
- 9 维权重和 = 1
- v3 与 v2 一致性（v3 在 v2 基础上扩展，不矛盾）

所有测试用 mock 数据，不打网络。
"""
import sys
import math
from pathlib import Path


sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "pkg"))

import pytest


# ============================================================
# Sortino / Calmar / 最大回撤 纯数学测试
# ============================================================

class TestDownsideRiskMetrics:
    def test_sortino_only_penalizes_downside(self):
        """Sortino 仅惩罚下行波动，正收益不算入分母"""
        from fund_analyzer import _calc_sortino_ratio
        # 全正收益 -> Sortino 应很高（下行 std = 0 时返回 0，但这里用收益率序列）
        # 用混合收益测试
        rets = [0.01, -0.02, 0.03, -0.01, 0.02, -0.005] * 10
        sortino = _calc_sortino_ratio(rets)
        assert isinstance(sortino, float)
        # 有正有负时 Sortino 应为有限值
        assert math.isfinite(sortino)

    def test_sortino_insufficient_data(self):
        from fund_analyzer import _calc_sortino_ratio
        assert _calc_sortino_ratio([0.01, 0.02]) == 0.0  # < 20 个样本

    def test_max_drawdown_calculation(self):
        """最大回撤计算：峰值 100 -> 谷值 80 -> 回撤 20%"""
        from fund_analyzer import _calc_max_drawdown
        navs = [100, 110, 80, 90, 95]  # 峰 110, 谷 80, 回撤 27.3%
        dd = _calc_max_drawdown(navs)
        assert abs(dd - (110 - 80) / 110) < 1e-6

    def test_max_drawdown_no_drawdown(self):
        from fund_analyzer import _calc_max_drawdown
        navs = [1, 2, 3, 4, 5]  # 单调上升 -> 无回撤
        assert _calc_max_drawdown(navs) == 0.0

    def test_calmar_ratio(self):
        from fund_analyzer import _calc_calmar_ratio
        # 构造 5% 日均收益 + 20% 回撤
        rets = [0.005] * 50 + [-0.02] * 10 + [0.005] * 50
        navs = [1.0]
        for r in rets:
            navs.append(navs[-1] * (1 + r))
        calmar = _calc_calmar_ratio(rets, navs)
        assert isinstance(calmar, float)
        assert math.isfinite(calmar)

    def test_tracking_error(self):
        from fund_analyzer import _calc_tracking_error
        # 基金与基准收益完全相同 -> 跟踪误差 = 0
        rets = [0.01] * 30
        te = _calc_tracking_error(rets, rets)
        assert te == 0.0

    def test_tracking_error_with_divergence(self):
        from fund_analyzer import _calc_tracking_error
        fund_rets = [0.02, -0.01, 0.03, -0.02] * 10
        bench_rets = [0.01, -0.01, 0.01, -0.01] * 10
        te = _calc_tracking_error(fund_rets, bench_rets)
        assert te > 0  # 有差异时跟踪误差 > 0


# ============================================================
# v3 权重和测试
# ============================================================

class TestV3Weights:
    def test_v3_weights_documented_in_docstring(self):
        """v3 评分函数的 9 维权重应在文档中明确标注"""
        from fund_analyzer import score_fund_v3
        docstring = score_fund_v3.__doc__ or ""
        # 文档应包含关键维度名称
        assert "Sortino" in docstring
        assert "Calmar" in docstring
        assert "跟踪误差" in docstring
        assert "费率" in docstring

    def test_v3_weights_sum_in_code(self):
        """v3 权重字典的和应为 1.0"""
        # 从源码中提取 v3_weights 字典验证
        import inspect
        from fund_analyzer import score_fund_v3
        source = inspect.getsource(score_fund_v3)
        # 验证权重值在源码中存在且可加和到 1
        # 12+13+18+12+10+12+8+5+10 = 100
        assert "0.12" in source  # perf
        assert "0.13" in source  # style
        assert "0.18" in source  # alpha
        assert "0.10" in source  # sortino
        assert "0.12" in source  # drawdown
        assert "0.08" in source  # tracking
        assert "0.05" in source  # fee
        assert "0.10" in source  # prediction


# ============================================================
# 费率性价比测试
# ============================================================

class TestExpenseRatio:
    def test_low_fee_gets_high_score(self):
        """管理费 <0.5% 应得高分"""
        # 直接验证评分逻辑（从源码提取的阈值）
        mgmt_fee = 0.3  # 0.3%
        if mgmt_fee < 0.5:
            fee_score = 95
        elif mgmt_fee < 1.0:
            fee_score = 80
        elif mgmt_fee < 1.5:
            fee_score = 60
        else:
            fee_score = 25
        assert fee_score == 95

    def test_high_fee_without_alpha_gets_low_score(self):
        """管理费 >2% 且无 alpha 应得低分"""
        mgmt_fee = 2.0
        alpha_val = 0  # 无超额收益
        if mgmt_fee < 0.5:
            fee_score = 95
        elif mgmt_fee < 1.0:
            fee_score = 80
        elif mgmt_fee < 1.5:
            fee_score = 60
        else:
            if alpha_val > 5:
                fee_score = 65
            elif alpha_val > 0:
                fee_score = 45
            else:
                fee_score = 25
        assert fee_score == 25

    def test_high_fee_with_alpha_gets_medium_score(self):
        """管理费 >2% 但有显著 alpha 应得中等分"""
        mgmt_fee = 2.0
        alpha_val = 8  # 显著超额收益
        if mgmt_fee < 0.5:
            fee_score = 95
        elif mgmt_fee < 1.0:
            fee_score = 80
        elif mgmt_fee < 1.5:
            fee_score = 60
        else:
            if alpha_val > 5:
                fee_score = 65
            elif alpha_val > 0:
                fee_score = 45
            else:
                fee_score = 25
        assert fee_score == 65


# ============================================================
# compare_funds_v2 测试
# ============================================================

class TestCompareFundsV2:
    def test_compare_returns_rankings_structure(self):
        """compare_funds_v2 返回结构应包含 rankings / radar_data / total_funds"""
        from fund_analyzer import compare_funds_v2
        # 用空列表测试（会返回 error）
        result = compare_funds_v2([], use_v3=False)
        assert "error" in result or "rankings" in result


# ============================================================
# 持仓穿透风格测试
# ============================================================

class TestHoldingsAnalysis:
    def test_fund_type_inference_by_position(self):
        """平均股票仓位 >80% 应推断为股票型"""
        # 模拟仓位数据
        avg_position = 94.0
        if avg_position >= 80:
            fund_type = "股票型"
        elif avg_position >= 50:
            fund_type = "混合型"
        elif avg_position >= 20:
            fund_type = "债券型"
        else:
            fund_type = "货币型"
        assert fund_type == "股票型"

    def test_bond_fund_inference(self):
        avg_position = 30.0
        if avg_position >= 80:
            fund_type = "股票型"
        elif avg_position >= 50:
            fund_type = "混合型"
        elif avg_position >= 20:
            fund_type = "债券型"
        else:
            fund_type = "货币型"
        assert fund_type == "债券型"

# ==================================================================
# 来自 tests/test_quant_metrics.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一量化绩效与风险指标测试（纯标准库，不依赖 numpy/pandas）"""
import sys
from pathlib import Path

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "pkg"))

import unittest


class TestQuantMetrics(unittest.TestCase):
    def test_basic_metrics(self):
        from stock_researcher.quantitative_metrics import compute_quant_metrics
        prices = [100, 110, 121, 108.9, 119.79]
        m = compute_quant_metrics(prices, symbol="TEST")
        self.assertAlmostEqual(m.total_return_pct, 19.79, places=2)
        self.assertAlmostEqual(m.max_drawdown_pct, 10.0, places=2)
        self.assertEqual(m.positive_days, 3)
        self.assertEqual(m.negative_days, 1)
        self.assertAlmostEqual(m.best_day_pct, 10.0, places=2)
        self.assertAlmostEqual(m.worst_day_pct, -10.0, places=2)
        self.assertGreater(m.sharpe_ratio, 0)
        self.assertGreater(m.sortino_ratio, 0)

    def test_benchmark_metrics(self):
        from stock_researcher.quantitative_metrics import compute_quant_metrics
        prices = [100.0]
        for i in range(1, 30):
            chg = 0.01 if i % 2 else -0.005
            prices.append(round(prices[-1] * (1 + chg), 6))
        m = compute_quant_metrics(prices, benchmark_prices=prices,
                                  risk_free=0.0, symbol="BENCH")
        self.assertAlmostEqual(m.beta, 1.0, places=4)
        self.assertAlmostEqual(m.correlation, 1.0, places=4)
        self.assertAlmostEqual(m.tracking_error_pct, 0.0, places=4)
        self.assertAlmostEqual(m.alpha_annual_pct, 0.0, places=2)

    def test_insufficient_data(self):
        from stock_researcher.quantitative_metrics import compute_quant_metrics
        m = compute_quant_metrics([100], symbol="SHORT")
        self.assertEqual(m.data_points, 1)
        self.assertIsNone(m.total_return_pct)
        self.assertIsNone(m.sharpe_ratio)

    def test_daily_returns_clean_invalid(self):
        from stock_researcher.quantitative_metrics import daily_returns
        rets = daily_returns([100, "bad", 110, None, 121])
        self.assertEqual(len(rets), 2)
        self.assertAlmostEqual(rets[0], 0.10, places=6)
        self.assertAlmostEqual(rets[1], 0.10, places=6)

    def test_top_level_export_without_numpy(self):
        from stock_researcher.quantitative_metrics import compute_quant_metrics, QuantMetrics
        m = compute_quant_metrics([100, 101, 102, 103, 104])
        self.assertIsInstance(m, QuantMetrics)

    def test_format_output(self):
        from stock_researcher.quantitative_metrics import compute_quant_metrics, format_quant_metrics
        m = compute_quant_metrics([100, 101, 102, 103, 104], symbol="TEST")
        text = format_quant_metrics(m)
        self.assertIn("量化体检", text)
        self.assertIn("TEST", text)

# ==================================================================
# 来自 tests/test_quant_v71.py
# ==================================================================

# -*- coding: utf-8 -*-
"""
量化模块 v7.1.0 测试

测试内容：
1. 数据源管理器（多源冗余 + 自动降级）
2. 因子库（多因子模型）
3. 策略回测引擎
"""

import os
import sys
import pytest
from unittest.mock import MagicMock, patch

# 添加项目路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))


# ============================================================
# 数据源管理器测试
# ============================================================

class TestDataSourceManager:
    """数据源管理器测试"""

    def test_source_registration(self):
        """测试数据源注册"""
        from stock_researcher.data_source_manager import DataSourceManager, DataSource

        manager = DataSourceManager()

        # 注册数据源
        source = DataSource(
            name="test_source",
            fetch_func=lambda codes: {"600519": {"price": 1800}},
            priority=1,
        )
        manager.register_source("realtime", source)

        assert "realtime" in manager._sources
        assert len(manager._sources["realtime"]) == 1
        assert manager._sources["realtime"][0].name == "test_source"

    def test_source_priority_order(self):
        """测试数据源优先级排序"""
        from stock_researcher.data_source_manager import DataSourceManager, DataSource

        manager = DataSourceManager()

        # 注册多个数据源（不同优先级）
        manager.register_source("realtime", DataSource(
            name="low_priority",
            fetch_func=lambda: {},
            priority=2,
        ))
        manager.register_source("realtime", DataSource(
            name="high_priority",
            fetch_func=lambda: {},
            priority=1,
        ))

        # 验证排序
        assert manager._sources["realtime"][0].name == "high_priority"
        assert manager._sources["realtime"][1].name == "low_priority"

    def test_fetch_with_fallback(self):
        """测试自动降级获取"""
        from stock_researcher.data_source_manager import DataSourceManager, DataSource

        manager = DataSourceManager()

        # 主数据源（会失败）
        def failing_fetch(**kwargs):
            raise Exception("主数据源失败")

        # 备用数据源（成功）
        def backup_fetch(**kwargs):
            return {"600519": {"price": 1800}}

        manager.register_source("realtime", DataSource(
            name="primary",
            fetch_func=failing_fetch,
            priority=1,
            max_retries=0,
        ))
        manager.register_source("realtime", DataSource(
            name="backup",
            fetch_func=backup_fetch,
            priority=2,
        ))

        # 应该自动降级到备用源
        result = manager.fetch("realtime")
        assert result is not None
        assert "600519" in result

    def test_cache_mechanism(self):
        """测试缓存机制"""
        from stock_researcher.data_source_manager import DataSourceManager, DataSource

        manager = DataSourceManager()

        call_count = 0

        def fetch_func(**kwargs):
            nonlocal call_count
            call_count += 1
            return {"data": call_count}

        manager.register_source("test", DataSource(
            name="test",
            fetch_func=fetch_func,
            priority=1,
            cache_ttl=60,
        ))

        # 第一次调用
        result1 = manager.fetch("test", use_cache=True)
        assert call_count == 1

        # 第二次调用（应该使用缓存）
        result2 = manager.fetch("test", use_cache=True)
        assert call_count == 1  # 没有再次调用
        assert result1 == result2

    def test_health_report(self):
        """测试健康报告"""
        from stock_researcher.data_source_manager import DataSourceManager, DataSource

        manager = DataSourceManager()

        manager.register_source("test", DataSource(
            name="test_source",
            fetch_func=lambda: {},
            priority=1,
        ))

        report = manager.get_health_report()
        assert "test" in report
        assert len(report["test"]) == 1
        assert report["test"][0]["name"] == "test_source"


# ============================================================
# 因子库测试
# ============================================================

class TestFactorLibrary:
    """因子库测试"""

    def test_value_factor_calculation(self):
        """测试价值因子计算"""
        from stock_researcher.quantitative_factors import FactorLibrary

        library = FactorLibrary()

        # 低估值股票（PE=10, PB=1.5）
        result = library.calc_value_factor(pe=10, pb=1.5)

        assert result.name == "value"
        assert result.value > 50  # 应该高于平均分
        assert result.category == "价值因子"

    def test_growth_factor_calculation(self):
        """测试成长因子计算"""
        from stock_researcher.quantitative_factors import FactorLibrary

        library = FactorLibrary()

        # 高成长股票
        result = library.calc_growth_factor(
            revenue_growth=0.3,
            earnings_growth=0.4
        )

        assert result.name == "growth"
        assert result.value > 60  # 高成长应该得高分

    def test_quality_factor_calculation(self):
        """测试质量因子计算"""
        from stock_researcher.quantitative_factors import FactorLibrary

        library = FactorLibrary()

        # 高质量公司
        result = library.calc_quality_factor(
            roe=0.20,
            gross_margin=0.40,
            debt_ratio=0.30
        )

        assert result.name == "quality"
        assert result.value > 60

    def test_momentum_factor_calculation(self):
        """测试动量因子计算"""
        from stock_researcher.quantitative_factors import FactorLibrary

        library = FactorLibrary()

        # 上涨趋势
        result = library.calc_momentum_factor(
            returns_5d=0.05,
            returns_20d=0.15
        )

        assert result.name == "momentum"
        assert result.value > 50

    def test_volatility_factor_calculation(self):
        """测试波动因子计算"""
        from stock_researcher.quantitative_factors import FactorLibrary

        library = FactorLibrary()

        # 低波动股票
        result = library.calc_volatility_factor(
            volatility_20d=0.20,
            beta=0.9
        )

        assert result.name == "volatility"
        assert result.value > 50

    def test_composite_score(self):
        """测试综合评分"""
        from stock_researcher.quantitative_factors import FactorLibrary

        library = FactorLibrary()

        # 优质股票数据
        result = library.calc_composite_score({
            'pe': 12,
            'pb': 1.5,
            'roe': 0.18,
            'revenue_growth': 0.25,
            'volatility_20d': 0.25,
        })

        assert result.total_score > 60
        assert result.recommendation in ["强烈买入", "买入"]
        assert result.confidence > 0

    def test_quick_score(self):
        """测试快速评分函数"""
        from stock_researcher.quantitative_factors import quick_score

        result = quick_score(pe=15, pb=2.0, roe=0.15, growth=0.20)

        assert "score" in result
        assert "recommendation" in result
        assert "confidence" in result


# ============================================================
# 策略回测测试
# ============================================================

class TestBacktester:
    """策略回测测试"""

    def test_rsi_strategy_buy_signal(self):
        """测试RSI策略买入信号"""
        from stock_researcher.quantitative_backtest import RSIStrategy

        strategy = RSIStrategy(oversold=30, overbought=70)

        # RSI < 30 应该触发买入
        data = {'rsi': [50, 40, 25, 35]}
        assert strategy.should_buy(data, 2) == True
        assert strategy.should_buy(data, 3) == False

    def test_rsi_strategy_sell_signal(self):
        """测试RSI策略卖出信号"""
        from stock_researcher.quantitative_backtest import RSIStrategy

        strategy = RSIStrategy(oversold=30, overbought=70)

        # RSI > 70 应该触发卖出
        data = {'rsi': [50, 60, 75, 65]}
        assert strategy.should_sell(data, 2) == True
        assert strategy.should_sell(data, 3) == False

    def test_macd_strategy_signals(self):
        """测试MACD策略信号"""
        from stock_researcher.quantitative_backtest import MACDStrategy

        strategy = MACDStrategy()

        # MACD金叉（从负转正）
        data = {'macd_hist': [-0.5, -0.2, 0.1, 0.3]}
        assert strategy.should_buy(data, 2) == True
        assert strategy.should_buy(data, 3) == False

        # MACD死叉（从正转负）
        data = {'macd_hist': [0.5, 0.2, -0.1, -0.3]}
        assert strategy.should_sell(data, 2) == True

    def test_backtester_run(self):
        """测试回测引擎运行"""
        from stock_researcher.quantitative_backtest import Backtester, RSIStrategy

        # 准备测试数据
        prices = [100, 102, 98, 95, 97, 103, 108, 105, 110, 115]
        rsi = [50, 55, 35, 25, 30, 55, 65, 60, 70, 75]

        data = {
            'close': prices,
            'rsi': rsi,
        }

        backtester = Backtester(initial_capital=100000)
        result = backtester.run(
            strategy=RSIStrategy(oversold=30, overbought=70),
            data=data
        )

        # 验证结果结构
        assert result.strategy_name == "RSI策略"
        assert result.initial_capital == 100000
        assert result.final_capital > 0
        assert len(result.equity_curve) == len(prices)

    def test_backtester_metrics(self):
        """测试回测指标计算"""
        from stock_researcher.quantitative_backtest import Backtester, RSIStrategy

        # 创建一个盈利的场景
        prices = [100, 95, 90, 85, 95, 105, 110, 115, 120, 125]
        rsi = [50, 40, 30, 20, 30, 50, 60, 65, 70, 75]

        data = {'close': prices, 'rsi': rsi}

        backtester = Backtester(initial_capital=100000)
        result = backtester.run(RSIStrategy(), data)

        # 应该有盈利
        assert result.total_return > 0
        assert result.win_rate > 0

    def test_quick_backtest(self):
        """测试快速回测函数"""
        from stock_researcher.quantitative_backtest import quick_backtest, RSIStrategy

        prices = [100, 102, 98, 95, 105, 110, 108, 115]
        rsi = [50, 55, 35, 25, 45, 60, 55, 70]

        result = quick_backtest(
            strategy=RSIStrategy(),
            prices=prices,
            indicators={'rsi': rsi}
        )

        assert "strategy" in result
        assert "total_return" in result
        assert "sharpe_ratio" in result

    def test_backtester_with_commission(self):
        """测试手续费对回测的影响"""
        from stock_researcher.quantitative_backtest import Backtester, RSIStrategy

        prices = [100, 90, 100, 110, 100]
        rsi = [50, 25, 50, 75, 50]
        data = {'close': prices, 'rsi': rsi}

        # 高手续费
        backtester_high = Backtester(initial_capital=100000, commission=0.01)
        result_high = backtester_high.run(RSIStrategy(), data)

        # 低手续费
        backtester_low = Backtester(initial_capital=100000, commission=0.001)
        result_low = backtester_low.run(RSIStrategy(), data)

        # 低手续费应该有更好的收益
        assert result_low.final_capital >= result_high.final_capital


# ============================================================
# 集成测试
# ============================================================

class TestQuantIntegration:
    """量化模块集成测试"""

    def test_factor_library_with_backtest(self):
        """测试因子库与回测引擎集成"""
        from stock_researcher.quantitative_factors import FactorLibrary
        from stock_researcher.quantitative_backtest import Backtester, Strategy

        # 使用因子评分来决定交易
        library = FactorLibrary()

        class FactorBasedStrategy(Strategy):
            def __init__(self):
                super().__init__("因子策略")
                self.library = FactorLibrary()

            def should_buy(self, data, index):
                pe = data.get('pe', [20])[min(index, len(data.get('pe', [])) - 1)]
                roe = data.get('roe', [0.1])[min(index, len(data.get('roe', [])) - 1)]
                result = self.library.calc_composite_score({'pe': pe, 'roe': roe})
                return result.total_score > 65

            def should_sell(self, data, index):
                pe = data.get('pe', [20])[min(index, len(data.get('pe', [])) - 1)]
                roe = data.get('roe', [0.1])[min(index, len(data.get('roe', [])) - 1)]
                result = self.library.calc_composite_score({'pe': pe, 'roe': roe})
                return result.total_score < 35

        # 准备数据
        data = {
            'close': [100, 105, 110, 108, 115, 120, 118, 125],
            'pe': [25, 23, 20, 22, 18, 16, 17, 15],
            'roe': [0.12, 0.13, 0.15, 0.14, 0.16, 0.18, 0.17, 0.19],
        }

        backtester = Backtester(initial_capital=100000)
        result = backtester.run(FactorBasedStrategy(), data)

        assert result.strategy_name == "因子策略"
        assert result.final_capital > 0

# ==================================================================
# 来自 tests/test_value_investing.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
价值投资分析框架测试（v5.0 新增）

测试 6 模块的核心数学计算：
- WACC/CAPM (beta, cost_of_equity, wacc)
- 护城河评分 (moat_score, moat_type)
- 财务健康 (Altman Z, Piotroski F, Beneish M)
- DCF 估值 (intrinsic_value, sensitivity matrix)
- 管理层评分 (6 维加权)
- 行业分析 (Porter 五力)
- 决策整合 (6 模块加权 + verdict 映射)
- 数据不足降级路径

所有测试用 mock 财务数据（fixture 字典），不打网络。
"""
import sys
import math
from pathlib import Path

# 确保项目根在 sys.path

sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "pkg"))

import pytest


# ============================================================
# Mock 财务数据 fixtures
# ============================================================

MOCK_INCOME = [
    {"report_date": "2024-12-31", "TOTAL_OPERATE_INCOME": 1500e8, "OPERATE_INCOME": 1500e8,
     "OPERATE_COST": 130e8, "PARENT_NETPROFIT": 700e8, "NETPROFIT": 700e8,
     "BASIC_EPS": 55.0, "ROE": 30.0, "GROSS_MARGIN": 91.3, "XSJLL": 91.3,
     "REVENUE_GROWTH": 15.0, "PROFIT_GROWTH": 18.0,
     "OPERATE_PROFIT": 850e8, "TOTAL_PROFIT": 850e8,
     "FINANCE_EXPENSE": 5e8, "RESEARCH_EXPENSE": 2e8,
     "SALE_EXPENSE": 50e8, "MANAGE_EXPENSE": 30e8, "INCOME_TAX": 150e8},
    {"report_date": "2023-12-31", "TOTAL_OPERATE_INCOME": 1300e8, "OPERATE_INCOME": 1300e8,
     "OPERATE_COST": 115e8, "PARENT_NETPROFIT": 600e8, "NETPROFIT": 600e8,
     "BASIC_EPS": 48.0, "ROE": 28.0, "GROSS_MARGIN": 91.2, "XSJLL": 91.2,
     "REVENUE_GROWTH": 14.0, "PROFIT_GROWTH": 16.0,
     "OPERATE_PROFIT": 730e8, "TOTAL_PROFIT": 730e8,
     "FINANCE_EXPENSE": 4e8, "RESEARCH_EXPENSE": 1.8e8,
     "SALE_EXPENSE": 45e8, "MANAGE_EXPENSE": 28e8, "INCOME_TAX": 130e8},
    {"report_date": "2022-12-31", "TOTAL_OPERATE_INCOME": 1140e8, "OPERATE_INCOME": 1140e8,
     "OPERATE_COST": 100e8, "PARENT_NETPROFIT": 520e8, "NETPROFIT": 520e8,
     "BASIC_EPS": 42.0, "ROE": 27.0, "GROSS_MARGIN": 91.2, "XSJLL": 91.2,
     "REVENUE_GROWTH": 13.0, "PROFIT_GROWTH": 15.0,
     "OPERATE_PROFIT": 640e8, "TOTAL_PROFIT": 640e8,
     "FINANCE_EXPENSE": 3e8, "RESEARCH_EXPENSE": 1.5e8,
     "SALE_EXPENSE": 40e8, "MANAGE_EXPENSE": 25e8, "INCOME_TAX": 120e8},
    {"report_date": "2021-12-31", "TOTAL_OPERATE_INCOME": 1000e8, "OPERATE_INCOME": 1000e8,
     "OPERATE_COST": 90e8, "PARENT_NETPROFIT": 450e8, "NETPROFIT": 450e8,
     "BASIC_EPS": 36.0, "ROE": 26.0, "GROSS_MARGIN": 91.0, "XSJLL": 91.0,
     "REVENUE_GROWTH": 12.0, "PROFIT_GROWTH": 14.0,
     "OPERATE_PROFIT": 550e8, "TOTAL_PROFIT": 550e8,
     "FINANCE_EXPENSE": 2.5e8, "RESEARCH_EXPENSE": 1.2e8,
     "SALE_EXPENSE": 35e8, "MANAGE_EXPENSE": 22e8, "INCOME_TAX": 100e8},
    {"report_date": "2020-12-31", "TOTAL_OPERATE_INCOME": 890e8, "OPERATE_INCOME": 890e8,
     "OPERATE_COST": 80e8, "PARENT_NETPROFIT": 400e8, "NETPROFIT": 400e8,
     "BASIC_EPS": 32.0, "ROE": 25.0, "GROSS_MARGIN": 91.0, "XSJLL": 91.0,
     "REVENUE_GROWTH": 11.0, "PROFIT_GROWTH": 13.0,
     "OPERATE_PROFIT": 490e8, "TOTAL_PROFIT": 490e8,
     "FINANCE_EXPENSE": 2e8, "RESEARCH_EXPENSE": 1e8,
     "SALE_EXPENSE": 30e8, "MANAGE_EXPENSE": 20e8, "INCOME_TAX": 90e8},
]

MOCK_BALANCE = [
    {"report_date": "2024-12-31", "TOTAL_ASSETS": 2500e8, "TOTAL_LIABILITIES": 400e8,
     "TOTAL_EQUITY": 2100e8, "TOTAL_PARENT_EQUITY": 2100e8,
     "TOTAL_CURRENT_ASSETS": 1800e8, "TOTAL_CURRENT_LIAB": 240e8,
     "FIXED_ASSET": 200e8, "CASH": 800e8, "MONETARY_FUNDS": 800e8,
     "ACCOUNTS_RECE": 5e8, "INVENTORY": 300e8, "GOODWILL": 10e8,
     "SHORT_LOAN": 50e8, "LONG_LOAN": 100e8, "BOND_PAYABLE": 0,
     "UNDISTRIBUTED_PROFIT": 1500e8, "RETAINED_EARNINGS": 1500e8,
     "CURRENT_RATIO": 750, "DEBT_ASSET_RATIO": 16.0, "ZCFZL": 16.0, "LDBL": 750},
    {"report_date": "2023-12-31", "TOTAL_ASSETS": 2200e8, "TOTAL_LIABILITIES": 380e8,
     "TOTAL_EQUITY": 1820e8, "TOTAL_PARENT_EQUITY": 1820e8,
     "TOTAL_CURRENT_ASSETS": 1600e8, "TOTAL_CURRENT_LIAB": 230e8,
     "FIXED_ASSET": 190e8, "CASH": 700e8, "MONETARY_FUNDS": 700e8,
     "ACCOUNTS_RECE": 4e8, "INVENTORY": 280e8, "GOODWILL": 10e8,
     "SHORT_LOAN": 45e8, "LONG_LOAN": 90e8, "BOND_PAYABLE": 0,
     "UNDISTRIBUTED_PROFIT": 1300e8, "RETAINED_EARNINGS": 1300e8,
     "CURRENT_RATIO": 696, "DEBT_ASSET_RATIO": 17.3, "ZCFZL": 17.3, "LDBL": 696},
    {"report_date": "2022-12-31", "TOTAL_ASSETS": 1900e8, "TOTAL_LIABILITIES": 350e8,
     "TOTAL_EQUITY": 1550e8, "TOTAL_PARENT_EQUITY": 1550e8,
     "TOTAL_CURRENT_ASSETS": 1400e8, "TOTAL_CURRENT_LIAB": 210e8,
     "FIXED_ASSET": 180e8, "CASH": 600e8, "MONETARY_FUNDS": 600e8,
     "ACCOUNTS_RECE": 3.5e8, "INVENTORY": 250e8, "GOODWILL": 10e8,
     "SHORT_LOAN": 40e8, "LONG_LOAN": 80e8, "BOND_PAYABLE": 0,
     "UNDISTRIBUTED_PROFIT": 1100e8, "RETAINED_EARNINGS": 1100e8,
     "CURRENT_RATIO": 667, "DEBT_ASSET_RATIO": 18.4, "ZCFZL": 18.4, "LDBL": 667},
    {"report_date": "2021-12-31", "TOTAL_ASSETS": 1600e8, "TOTAL_LIABILITIES": 320e8,
     "TOTAL_EQUITY": 1280e8, "TOTAL_PARENT_EQUITY": 1280e8,
     "TOTAL_CURRENT_ASSETS": 1200e8, "TOTAL_CURRENT_LIAB": 190e8,
     "FIXED_ASSET": 170e8, "CASH": 500e8, "MONETARY_FUNDS": 500e8,
     "ACCOUNTS_RECE": 3e8, "INVENTORY": 220e8, "GOODWILL": 10e8,
     "SHORT_LOAN": 35e8, "LONG_LOAN": 70e8, "BOND_PAYABLE": 0,
     "UNDISTRIBUTED_PROFIT": 900e8, "RETAINED_EARNINGS": 900e8,
     "CURRENT_RATIO": 632, "DEBT_ASSET_RATIO": 20.0, "ZCFZL": 20.0, "LDBL": 632},
    {"report_date": "2020-12-31", "TOTAL_ASSETS": 1300e8, "TOTAL_LIABILITIES": 300e8,
     "TOTAL_EQUITY": 1000e8, "TOTAL_PARENT_EQUITY": 1000e8,
     "TOTAL_CURRENT_ASSETS": 1000e8, "TOTAL_CURRENT_LIAB": 180e8,
     "FIXED_ASSET": 160e8, "CASH": 400e8, "MONETARY_FUNDS": 400e8,
     "ACCOUNTS_RECE": 2.5e8, "INVENTORY": 200e8, "GOODWILL": 10e8,
     "SHORT_LOAN": 30e8, "LONG_LOAN": 60e8, "BOND_PAYABLE": 0,
     "UNDISTRIBUTED_PROFIT": 700e8, "RETAINED_EARNINGS": 700e8,
     "CURRENT_RATIO": 556, "DEBT_ASSET_RATIO": 23.1, "ZCFZL": 23.1, "LDBL": 556},
]

MOCK_CASHFLOW = [
    {"report_date": "2024-12-31", "NETCASH_OPERATE": 600e8, "NETCASH_INVEST": -100e8,
     "NETCASH_FINANCE": -200e8, "BUY_FIX_ASSET_OTHER": 100e8},
    {"report_date": "2023-12-31", "NETCASH_OPERATE": 550e8, "NETCASH_INVEST": -90e8,
     "NETCASH_FINANCE": -180e8, "BUY_FIX_ASSET_OTHER": 90e8},
    {"report_date": "2022-12-31", "NETCASH_OPERATE": 500e8, "NETCASH_INVEST": -80e8,
     "NETCASH_FINANCE": -160e8, "BUY_FIX_ASSET_OTHER": 80e8},
    {"report_date": "2021-12-31", "NETCASH_OPERATE": 450e8, "NETCASH_INVEST": -70e8,
     "NETCASH_FINANCE": -140e8, "BUY_FIX_ASSET_OTHER": 70e8},
    {"report_date": "2020-12-31", "NETCASH_OPERATE": 400e8, "NETCASH_INVEST": -60e8,
     "NETCASH_FINANCE": -120e8, "BUY_FIX_ASSET_OTHER": 60e8},
]

MOCK_INDICATORS = [
    {"report_date": "2024-12-31", "ROE": 30.0, "ROEJQ": 30.0, "ROA": 25.0,
     "GROSS_PROFIT_RATIO": 91.3, "XSJLL": 91.3, "DEBT_ASSET_RATIO": 16.0,
     "ZCFZL": 16.0, "CURRENT_RATIO": 750, "LDBL": 750,
     "REVENUE_GROWTH": 15.0, "PROFIT_GROWTH": 18.0,
     "TOTAL_OPERATE_INCOME": 1500e8, "PARENT_NETPROFIT": 700e8, "TOTAL_ASSETS": 2500e8},
    {"report_date": "2023-12-31", "ROE": 28.0, "ROEJQ": 28.0, "ROA": 24.0,
     "GROSS_PROFIT_RATIO": 91.2, "XSJLL": 91.2, "DEBT_ASSET_RATIO": 17.3,
     "ZCFZL": 17.3, "CURRENT_RATIO": 696, "LDBL": 696,
     "REVENUE_GROWTH": 14.0, "PROFIT_GROWTH": 16.0,
     "TOTAL_OPERATE_INCOME": 1300e8, "PARENT_NETPROFIT": 600e8, "TOTAL_ASSETS": 2200e8},
    {"report_date": "2022-12-31", "ROE": 27.0, "ROEJQ": 27.0, "ROA": 23.0,
     "GROSS_PROFIT_RATIO": 91.2, "XSJLL": 91.2, "DEBT_ASSET_RATIO": 18.4,
     "ZCFZL": 18.4, "CURRENT_RATIO": 667, "LDBL": 667,
     "REVENUE_GROWTH": 13.0, "PROFIT_GROWTH": 15.0,
     "TOTAL_OPERATE_INCOME": 1140e8, "PARENT_NETPROFIT": 520e8, "TOTAL_ASSETS": 1900e8},
    {"report_date": "2021-12-31", "ROE": 26.0, "ROEJQ": 26.0, "ROA": 22.0,
     "GROSS_PROFIT_RATIO": 91.0, "XSJLL": 91.0, "DEBT_ASSET_RATIO": 20.0,
     "ZCFZL": 20.0, "CURRENT_RATIO": 632, "LDBL": 632,
     "REVENUE_GROWTH": 12.0, "PROFIT_GROWTH": 14.0,
     "TOTAL_OPERATE_INCOME": 1000e8, "PARENT_NETPROFIT": 450e8, "TOTAL_ASSETS": 1600e8},
    {"report_date": "2020-12-31", "ROE": 25.0, "ROEJQ": 25.0, "ROA": 21.0,
     "GROSS_PROFIT_RATIO": 91.0, "XSJLL": 91.0, "DEBT_ASSET_RATIO": 23.1,
     "ZCFZL": 23.1, "CURRENT_RATIO": 556, "LDBL": 556,
     "REVENUE_GROWTH": 11.0, "PROFIT_GROWTH": 13.0,
     "TOTAL_OPERATE_INCOME": 890e8, "PARENT_NETPROFIT": 400e8, "TOTAL_ASSETS": 1300e8},
]

MOCK_FINANCIALS = {
    "income": MOCK_INCOME,
    "balance": MOCK_BALANCE,
    "cashflow": MOCK_CASHFLOW,
    "indicators": MOCK_INDICATORS,
    "shareholders": {"top10": [{"name": "大股东", "pct": 55.0}], "controller": "大股东", "institutional_pct": 15.0, "latest_date": "2024-12-31"},
    "dividends": [{"report_date": "2024-12-31", "total_amount": 200e8}, {"report_date": "2023-12-31", "total_amount": 180e8}],
    "management": {"board_size": 11, "independent_directors": 4, "independent_pct": 36.4, "top3_salary": 500e4, "exec_list": []},
}


# ============================================================
# WACC 测试
# ============================================================

class TestWACC:
    def test_beta_with_sufficient_data(self):
        from stock_researcher.value_investing_wacc import calc_beta
        # 构造完全正相关的收益序列
        stock_rets = [0.01 * i for i in range(1, 31)]
        bench_rets = [0.01 * i for i in range(1, 31)]
        beta = calc_beta(stock_rets, bench_rets, window=60)
        assert 0.9 <= beta <= 1.1  # 完全正相关 beta 应接近 1

    def test_beta_insufficient_data_returns_default(self):
        from stock_researcher.value_investing_wacc import calc_beta
        beta = calc_beta([0.01, 0.02, 0.03], [0.01, 0.02, 0.03], window=60)
        assert beta == 1.0  # 数据不足返回默认 1.0

    def test_cost_of_equity_capm(self):
        from stock_researcher.value_investing_wacc import calc_cost_of_equity
        ke = calc_cost_of_equity(beta=1.2, rf=0.03, erp=0.06)
        assert abs(ke - 0.102) < 1e-6  # 3% + 1.2 × 6% = 10.2%

    def test_cost_of_debt_with_valid_data(self):
        from stock_researcher.value_investing_wacc import calc_cost_of_debt
        kd = calc_cost_of_debt(interest_expense=5e8, total_debt=100e8, tax_rate=0.25)
        # 5% 税前 × 0.75 = 3.75%
        assert abs(kd - 0.0375) < 1e-6

    def test_cost_of_debt_zero_debt(self):
        from stock_researcher.value_investing_wacc import calc_cost_of_debt
        assert calc_cost_of_debt(5e8, 0, 0.25) == 0.0

    def test_wacc_clipped_to_range(self):
        from stock_researcher.value_investing_wacc import calc_wacc
        # 极高 beta + 高负债 -> WACC 应被 clip 到 [6%, 15%]
        result = calc_wacc(
            code="TEST",
            stock_returns=[0.05 * i for i in range(1, 61)],
            benchmark_returns=[0.001] * 60,
            interest_expense=1e10,
            total_debt=1e12,
            market_cap=1e10,
        )
        assert 0.06 <= result["wacc"] <= 0.15


# ============================================================
# 护城河测试
# ============================================================

class TestMoat:
    def test_moat_analysis_with_mock_data(self):
        from stock_researcher.value_investing_moat import MoatAnalyzer
        analyzer = MoatAnalyzer(years=5)
        result = analyzer.analyze("TEST", financials=MOCK_FINANCIALS)
        assert not result.insufficient_data
        assert 0 <= result.moat_score <= 100
        assert result.moat_type in ("宽护城河", "窄护城河", "无显著护城河")
        assert len(result.sub_scores) > 0
        assert len(result.evidence) > 0

    def test_moat_high_gross_margin_gets_high_score(self):
        """毛利率 91% 的公司应有较高护城河分"""
        from stock_researcher.value_investing_moat import MoatAnalyzer
        analyzer = MoatAnalyzer(years=5)
        result = analyzer.analyze("TEST", financials=MOCK_FINANCIALS)
        # 91% 毛利率 + 高稳定性 -> 高分
        assert result.moat_score >= 60
        assert "毛利率" in result.evidence[0]

    def test_moat_insufficient_data(self):
        from stock_researcher.value_investing_moat import MoatAnalyzer
        analyzer = MoatAnalyzer(years=5)
        result = analyzer.analyze("TEST", financials={"income": [], "balance": []})
        assert result.insufficient_data


# ============================================================
# 财务健康测试
# ============================================================

class TestFinancialHealth:
    def test_altman_z_safe_company(self):
        """高现金流/低负债公司 Altman Z 应在安全区（>2.99）"""
        from stock_researcher.value_investing_financial_health import FinancialHealthChecker
        checker = FinancialHealthChecker(years=5)
        z = checker.calc_altman_z(MOCK_BALANCE, MOCK_INCOME, market_cap=2e12)
        assert z is not None
        assert z > 2.99  # 安全区

    def test_piotroski_f_strong_company(self):
        """营收/利润/现金流均增长的公司 F-score 应较高"""
        from stock_researcher.value_investing_financial_health import FinancialHealthChecker
        checker = FinancialHealthChecker(years=5)
        f = checker.calc_piotroski_f(MOCK_INDICATORS, MOCK_BALANCE, MOCK_INCOME, MOCK_CASHFLOW)
        assert f is not None
        assert 5 <= f <= 9  # 中到强

    def test_beneish_m_skipped_when_sga_missing(self):
        """当 SALE_EXPENSE/MANAGE_EXPENSE 为 0 时 Beneish 应返回 None"""
        from stock_researcher.value_investing_financial_health import FinancialHealthChecker
        checker = FinancialHealthChecker(years=5)
        # 构造无 SGA 数据的利润表
        income_no_sga = [
            {**MOCK_INCOME[0], "SALE_EXPENSE": 0, "MANAGE_EXPENSE": 0},
            {**MOCK_INCOME[1], "SALE_EXPENSE": 0, "MANAGE_EXPENSE": 0},
        ]
        m = checker.calc_beneish_m(income_no_sga, MOCK_BALANCE[:2], MOCK_CASHFLOW[:2])
        assert m is None  # 关键字段缺失时返回 None

    def test_health_check_with_mock_data(self):
        from stock_researcher.value_investing_financial_health import FinancialHealthChecker
        checker = FinancialHealthChecker(years=5)
        result = checker.check("TEST", market_cap=2e12, financials=MOCK_FINANCIALS)
        assert not result.insufficient_data
        assert 0 <= result.score <= 100
        assert result.grade in ("A", "B", "C", "D")
        assert "altman_z" in result.sub_scores
        assert "piotroski_f" in result.sub_scores

    def test_health_red_flags_for_distressed_company(self):
        """负债率 >80% + 低市值 + 亏损的公司 Altman Z 应在危险区（<1.81）"""
        from stock_researcher.value_investing_financial_health import FinancialHealthChecker
        checker = FinancialHealthChecker(years=5)
        # 构造全维度恶化的困境公司
        bad_balance = [{
            "TOTAL_ASSETS": 100e8, "TOTAL_LIABILITIES": 90e8,
            "TOTAL_EQUITY": 10e8, "TOTAL_PARENT_EQUITY": 10e8,
            "TOTAL_CURRENT_ASSETS": 20e8, "TOTAL_CURRENT_LIAB": 70e8,
            "FIXED_ASSET": 70e8, "CASH": 5e8, "MONETARY_FUNDS": 5e8,
            "ACCOUNTS_RECE": 10e8, "INVENTORY": 5e8, "GOODWILL": 0,
            "SHORT_LOAN": 50e8, "LONG_LOAN": 30e8, "BOND_PAYABLE": 10e8,
            "UNDISTRIBUTED_PROFIT": -20e8, "RETAINED_EARNINGS": -20e8,
            "CURRENT_RATIO": 28.6, "DEBT_ASSET_RATIO": 90.0, "ZCFZL": 90.0, "LDBL": 28.6,
        }]
        bad_income = [{
            "TOTAL_OPERATE_INCOME": 50e8, "OPERATE_INCOME": 50e8,
            "OPERATE_COST": 45e8, "PARENT_NETPROFIT": -5e8, "NETPROFIT": -5e8,
            "OPERATE_PROFIT": -2e8, "TOTAL_PROFIT": -5e8,
            "FINANCE_EXPENSE": 8e8,  # 高利息支出
        }]
        z = checker.calc_altman_z(bad_balance, bad_income, market_cap=5e8)
        assert z < 1.81  # 危险区


# ============================================================
# DCF 估值测试
# ============================================================

class TestDCFValuation:
    def test_dcf_intrinsic_value_positive(self):
        """FCF > 0 时内在价值应为正"""
        from stock_researcher.value_investing_dcf_valuation import DCFValuation
        valuator = DCFValuation(forecast_years=5)
        result = valuator.valuate(
            "TEST", current_price=1000, shares_outstanding=12.5e8,
            market_cap=1.25e12, financials=MOCK_FINANCIALS,
        )
        assert not result.insufficient_data
        assert result.intrinsic_value_per_share > 0
        assert len(result.fair_value_range) == 3
        assert len(result.sensitivity) == 3  # WACC ±1%

    def test_dcf_sensitivity_matrix(self):
        """敏感性矩阵应有 3×3 = 9 个值"""
        from stock_researcher.value_investing_dcf_valuation import DCFValuation
        valuator = DCFValuation(forecast_years=5)
        result = valuator.valuate(
            "TEST", current_price=1000, shares_outstanding=12.5e8,
            market_cap=1.25e12, financials=MOCK_FINANCIALS,
        )
        for wacc_key, row in result.sensitivity.items():
            assert len(row) == 3  # 终值增长 ±0.5%

    def test_dcf_shares_from_eps(self):
        """未提供 shares_outstanding 时从 EPS + 净利润推导"""
        from stock_researcher.value_investing_dcf_valuation import DCFValuation
        valuator = DCFValuation(forecast_years=5)
        result = valuator.valuate(
            "TEST", current_price=1000, shares_outstanding=0,
            market_cap=0, financials=MOCK_FINANCIALS,
        )
        # EPS=55, 净利润=700e8 -> shares = 700e8/55 ≈ 12.73e8
        # 内在价值应为正
        assert result.intrinsic_value_per_share > 0

    def test_dcf_insufficient_data(self):
        from stock_researcher.value_investing_dcf_valuation import DCFValuation
        valuator = DCFValuation(forecast_years=5)
        result = valuator.valuate("TEST", financials={"cashflow": []})
        assert result.insufficient_data


# ============================================================
# 管理层评估测试
# ============================================================

class TestManagement:
    def test_management_score_with_mock_data(self):
        from stock_researcher.value_investing_management import ManagementAssessment
        assessor = ManagementAssessment(years=5)
        result = assessor.assess("TEST", financials=MOCK_FINANCIALS)
        assert not result.insufficient_data
        assert 0 <= result.score <= 100
        assert result.verdict in ("优秀", "良好", "一般", "较差")
        assert "roe_roic_trend" in result.sub_scores

    def test_dupont_breakdown(self):
        from stock_researcher.value_investing_management import ManagementAssessment
        assessor = ManagementAssessment(years=5)
        result = assessor.assess("TEST", financials=MOCK_FINANCIALS)
        if result.dupont_breakdown:
            assert "net_margin" in result.dupont_breakdown
            assert "asset_turnover" in result.dupont_breakdown
            assert "equity_multiplier" in result.dupont_breakdown


# ============================================================
# 决策整合测试
# ============================================================

class TestDecisionIntegration:
    def test_decision_weights_sum_to_one(self):
        from stock_researcher.value_investing_decision_integration import ValueInvestingDecision
        total = sum(ValueInvestingDecision.WEIGHTS.values())
        assert abs(total - 1.0) < 1e-6

    def test_dcf_to_score_mapping(self):
        from stock_researcher.value_investing_decision_integration import ValueInvestingDecision
        from stock_researcher.value_investing_dcf_valuation import DCFResult
        # 安全边际 60% -> 高分
        dcf = DCFResult(code="TEST", margin_of_safety_pct=60, intrinsic_value_per_share=1000, insufficient_data=False)
        score = ValueInvestingDecision._dcf_to_score(dcf)
        assert score == 100
        # 安全边际 -50% -> 低分
        dcf2 = DCFResult(code="TEST", margin_of_safety_pct=-50, intrinsic_value_per_share=1000, insufficient_data=False)
        score2 = ValueInvestingDecision._dcf_to_score(dcf2)
        assert score2 == 10

    def test_signal_agreement(self):
        from stock_researcher.value_investing_decision_integration import ValueInvestingDecision
        # 6 个模块全部 >65（看多）-> 一致性 = 1
        breakdown = {k: {"score": 80, "weight": 0.15} for k in ["dcf", "moat", "health", "mgmt", "industry", "factor"]}
        agreement = ValueInvestingDecision._signal_agreement(breakdown)
        assert agreement == 1.0
        # 3 看多 + 3 看空 -> 一致性 = 0
        breakdown2 = {}
        for i, k in enumerate(["dcf", "moat", "health", "mgmt", "industry", "factor"]):
            breakdown2[k] = {"score": 80 if i < 3 else 20, "weight": 0.15}
        agreement2 = ValueInvestingDecision._signal_agreement(breakdown2)
        assert agreement2 == 0.0


# ============================================================
# 数据不足降级测试
# ============================================================

class TestInsufficientData:
    def test_moat_degrades_gracefully(self):
        """只有 1 年数据时，护城河分析应降级（仅用可用维度），不报 insufficient_data"""
        from stock_researcher.value_investing_moat import MoatAnalyzer
        analyzer = MoatAnalyzer(years=5)
        # 只有 1 年数据 -> 部分维度（毛利率稳定性/ROIC一致性等需3年）不可用
        # 但 pricing_power/market_share 仅需 1 年 -> 仍可计算
        result = analyzer.analyze("TEST", financials={
            "income": MOCK_INCOME[:1], "balance": MOCK_BALANCE[:1], "indicators": MOCK_INDICATORS[:1]
        })
        # 应使用降级模式：子评分维度 < 7（部分维度不可用）
        assert len(result.sub_scores) < 7
        # 仍应输出评分（不因部分数据缺失而完全失败）
        assert 0 <= result.moat_score <= 100

    def test_moat_empty_data_returns_insufficient(self):
        """空数据时应返回 insufficient_data"""
        from stock_researcher.value_investing_moat import MoatAnalyzer
        analyzer = MoatAnalyzer(years=5)
        result = analyzer.analyze("TEST", financials={"income": [], "balance": []})
        assert result.insufficient_data

    def test_health_degrades_gracefully(self):
        from stock_researcher.value_investing_financial_health import FinancialHealthChecker
        checker = FinancialHealthChecker(years=5)
        result = checker.check("TEST", financials={"income": [], "balance": [], "cashflow": [], "indicators": []})
        assert result.insufficient_data

    def test_dcf_degrades_gracefully(self):
        from stock_researcher.value_investing_dcf_valuation import DCFValuation
        valuator = DCFValuation(forecast_years=5)
        result = valuator.valuate("TEST", financials={"cashflow": MOCK_CASHFLOW[:2], "income": [], "balance": []})
        assert result.insufficient_data
