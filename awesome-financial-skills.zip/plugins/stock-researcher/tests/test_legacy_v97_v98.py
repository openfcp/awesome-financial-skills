# -*- coding: utf-8 -*-
"""合并测试套件（离线）：由多个旧测试文件按原顺序拼接，内容未删减。"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
SKILL_DIR = ROOT

# ==================================================================
# 来自 tests/test_v970_knowledge.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v9.7 回归测试 — 知识库双向交互（IMA / Dify / Obsidian / 本地，全离线）。

覆盖：
  1. KnowledgeNote / build_analysis_note：frontmatter 渲染 + 机读 JSON 块
  2. LocalKnowledgeAdapter：写入 / MD5 幂等 / 关键词检索 / 全文回读
  3. ObsidianAdapter：Vault 直写 / 无 Vault 不可用
  4. ImaAdapter：凭证缺失降级 / import_doc+add_knowledge / search（Fake HTTP）
  5. DifyAdapter：Key 缺失降级 / dataset 定位与创建 / 同名更新 / retrieve（Fake HTTP）
  6. 双向引擎：save_analysis_to_kb（含同步日志）/ load_kb_data / kb_quant_forecast
  7. 语音意图：知识库保存 / 检索 / 回读量化 解析
"""
import json
import math
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from stock_researcher import knowledge_sync as ks
from stock_researcher.voice_command import parse_voice_command


# ── 公共夹具 ─────────────────────────────────────────────────


@pytest.fixture
def tmp_log(monkeypatch, tmp_path):
    """同步日志重定向到临时目录，不污染真实 data/。"""
    log = tmp_path / "knowledge_sync_log.json"
    monkeypatch.setattr(ks, "SYNC_LOG", log)
    return log


@pytest.fixture
def sample_result():
    return {
        "name": "测试股", "code": "600519", "market": "cn",
        "signal": "看涨", "confidence": 0.72, "summary": "测试结论",
        "price": {"price": 1500.0, "chg_pct": 1.2, "pe": 22.5},
        "technical": {"ma5": 1498, "ma20": 1480, "ma60": 1450,
                      "rsi": 61, "vol_ratio": 1.1},
        "score": {"total": 71.5},
        "monte_carlo": {"5d": {"avg": 1.2, "up": 0.66},
                        "10d": {"avg": 2.0, "up": 0.61}},
    }


@pytest.fixture
def sample_prices():
    # 正弦叠加趋势：确定性序列，历史形态可匹配（离线可预测）
    return [100 * (1 + 0.001 * i) * (1 + 0.03 * math.sin(i / 5.0))
            for i in range(120)]


def _no_ima_creds(monkeypatch):
    monkeypatch.setattr(ks, "_ima_credentials",
                        lambda: {"client_id": "", "api_key": ""})
    monkeypatch.delenv("IMA_OPENAPI_CLIENTID", raising=False)
    monkeypatch.delenv("IMA_OPENAPI_APIKEY", raising=False)


# ── 1. 笔记构建 ─────────────────────────────────────────────


class TestNoteBuilding:
    def test_frontmatter_markdown(self):
        note = ks.KnowledgeNote(title="T", content="正文",
                                tags=["a", "b"], category="投研分析")
        md = note.to_frontmatter_markdown()
        assert md.startswith("---")
        assert "title: T" in md and "tags: [a, b]" in md
        assert md.endswith("正文")

    def test_build_note_contains_human_sections(self, sample_result,
                                               sample_prices):
        note = ks.build_analysis_note("600519", sample_result, sample_prices)
        assert "测试股" in note.title and "600519" in note.title
        assert "看涨" in note.content and "71.5" in note.content
        assert "蒙特卡洛" in note.content
        assert "不构成投资建议" in note.content      # 免责声明必随笔记
        assert "stock-researcher" in note.tags

    def test_build_note_embeds_machine_json(self, sample_result,
                                            sample_prices):
        note = ks.build_analysis_note("600519", sample_result, sample_prices)
        payload = ks._extract_payload(note.content)
        assert payload is not None
        assert payload["schema"] == ks.DATA_SCHEMA
        assert payload["code"] == "600519"
        assert len(payload["prices"]) == 120
        assert payload["score"]["total"] == 71.5

    def test_build_note_truncates_prices(self, sample_result):
        prices = [100.0 + i * 0.1 for i in range(300)]
        note = ks.build_analysis_note("600519", sample_result, prices)
        payload = ks._extract_payload(note.content)
        assert len(payload["prices"]) == ks.MAX_NOTE_PRICES

    def test_build_note_rejects_error_result(self):
        with pytest.raises(ks.KnowledgeBaseError):
            ks.build_analysis_note("600519", {"error": "行情获取失败"})


# ── 2. 本地兜底库 / Obsidian ────────────────────────────────


class TestLocalAdapter:
    def test_push_and_search(self, tmp_path, sample_result, sample_prices):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        assert ad.available() is True
        note = ks.build_analysis_note("600519", sample_result, sample_prices)
        res = ad.push(note)
        assert res["status"] == "pushed"
        assert Path(res["path"]).exists()
        hits = ad.search("600519")
        assert len(hits) == 1 and "测试股" in hits[0]["title"]

    def test_push_idempotent_by_digest(self, tmp_path, sample_result):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        note = ks.build_analysis_note("600519", sample_result, [])
        assert ad.push(note)["status"] == "pushed"
        assert ad.push(note)["status"] == "skipped"     # MD5 摘要幂等

    def test_read_by_path_and_title(self, tmp_path, sample_result):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        note = ks.build_analysis_note("600519", sample_result, [])
        res = ad.push(note)
        assert ks.DATA_SCHEMA in ad.read(res["path"])
        assert ks.DATA_SCHEMA in ad.read(note.title)
        assert ad.read("不存在的笔记") == ""

    def test_safe_filename(self, tmp_path):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        note = ks.KnowledgeNote(title='非法/字符:测试*?"', content="x")
        res = ad.push(note)
        assert Path(res["path"]).exists()


class TestObsidianAdapter:
    def test_vault_write(self, tmp_path, sample_result):
        vault = tmp_path / "my-vault"
        vault.mkdir()
        ad = ks.ObsidianAdapter(vault_path=vault)
        assert ad.available() is True
        note = ks.build_analysis_note("600519", sample_result, [])
        res = ad.push(note)
        assert res["status"] == "pushed"
        text = Path(res["path"]).read_text(encoding="utf-8")
        assert "tags:" in text                          # Obsidian frontmatter

    def test_unavailable_without_vault(self, tmp_path):
        ad = ks.ObsidianAdapter(vault_path=tmp_path / "not-exists")
        assert ad.available() is False


# ── 3. IMA 适配器（Fake HTTP 全离线）────────────────────────


class TestImaAdapter:
    def test_missing_credentials_raises(self, monkeypatch, tmp_path):
        _no_ima_creds(monkeypatch)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        ad = ks.ImaAdapter()
        assert ad.available() is False
        with pytest.raises(ks.KnowledgeBaseError, match="IMA 凭证缺失"):
            ad.push(ks.KnowledgeNote(title="t", content="c"))

    def test_push_import_and_link(self, monkeypatch):
        _no_ima_creds(monkeypatch)
        calls = []

        def fake_http(url, body, headers):
            calls.append((url, body))
            if "import_doc" in url:
                return {"code": 0, "data": {"note_id": "N123"}}
            if "add_knowledge" in url:
                return {"code": 0}
            return {"code": 1, "msg": "unexpected"}

        ad = ks.ImaAdapter(client_id="cid", api_key="key",
                           knowledge_base_id="KB1", http_fn=fake_http)
        res = ad.push(ks.KnowledgeNote(title="t", content="c"))
        assert res == {"adapter": "ima", "status": "pushed",
                       "note_id": "N123", "linked": True}
        assert calls[0][1]["content_format"] == 1
        assert calls[1][1]["media_type"] == 11
        assert calls[1][1]["knowledge_base_id"] == "KB1"

    def test_push_api_error_raises(self, monkeypatch):
        _no_ima_creds(monkeypatch)
        ad = ks.ImaAdapter(client_id="cid", api_key="key",
                           http_fn=lambda u, b, h: {"code": 40001})
        with pytest.raises(ks.KnowledgeBaseError, match="import_doc"):
            ad.push(ks.KnowledgeNote(title="t", content="c"))

    def test_search(self, monkeypatch):
        _no_ima_creds(monkeypatch)

        def fake_http(url, body, headers):
            assert "search_knowledge" in url
            assert body["query"] == "茅台"
            return {"code": 0, "data": {"items": [
                {"title": "茅台分析", "content": "评分 71"}]}}

        ad = ks.ImaAdapter(client_id="cid", api_key="key", http_fn=fake_http)
        hits = ad.search("茅台", limit=3)
        assert hits[0]["title"] == "茅台分析" and hits[0]["source"] == "ima"


# ── 4. Dify 适配器（Fake HTTP 全离线）───────────────────────


class TestDifyAdapter:
    def test_missing_key_raises(self, monkeypatch):
        monkeypatch.delenv("DIFY_API_KEY", raising=False)
        ad = ks.DifyAdapter()
        assert ad.available() is False
        with pytest.raises(ks.KnowledgeBaseError, match="Dify API Key 缺失"):
            ad.push(ks.KnowledgeNote(title="t", content="c"))

    def test_push_creates_dataset_and_document(self, monkeypatch):
        monkeypatch.delenv("DIFY_API_KEY", raising=False)
        monkeypatch.delenv("DIFY_DATASET_ID", raising=False)

        def fake_get(url, headers):
            if "/v1/datasets?" in url:
                return {"data": []}                    # 无同名知识库
            if "/documents?" in url:
                return {"data": []}                    # 无同名文档
            return {}

        def fake_post(url, body, headers):
            if url.endswith("/v1/datasets"):
                return {"id": "DS1"}                   # 创建知识库
            if "create-by-text" in url:
                return {"document": {"id": "DOC1"}}
            return {}

        ad = ks.DifyAdapter(api_key="sk-x", http_fn=fake_post,
                            http_get_fn=fake_get)
        res = ad.push(ks.KnowledgeNote(title="t", content="c"))
        assert res["status"] == "pushed"
        assert res["dataset_id"] == "DS1" and res["document_id"] == "DOC1"

    def test_push_updates_existing_document(self, monkeypatch):
        monkeypatch.delenv("DIFY_DATASET_ID", raising=False)

        def fake_get(url, headers):
            if "/documents?" in url:
                return {"data": [{"name": "t", "id": "OLD1"}]}
            return {}

        def fake_post(url, body, headers):
            assert "update-by-text" in url and "OLD1" in url
            return {"document": {"id": "OLD1"}}

        ad = ks.DifyAdapter(api_key="sk-x", dataset_id="DS1",
                            http_fn=fake_post, http_get_fn=fake_get)
        res = ad.push(ks.KnowledgeNote(title="t", content="c"))
        assert res["status"] == "updated"

    def test_retrieve(self, monkeypatch):
        def fake_post(url, body, headers):
            assert "retrieve" in url
            return {"records": [{"score": 0.9, "segment": {
                "content": "评分71", "document": {"name": "茅台分析"}}}]}

        ad = ks.DifyAdapter(api_key="sk-x", dataset_id="DS1",
                            http_fn=fake_post)
        hits = ad.search("茅台")
        assert hits[0]["title"] == "茅台分析"
        assert hits[0]["score"] == 0.9 and hits[0]["source"] == "dify"


# ── 5. 路由与双向引擎 ───────────────────────────────────────


class TestRouting:
    def test_get_adapter_default_local(self, monkeypatch):
        monkeypatch.setattr(ks, "load_kb_config", lambda path=None: {})
        ad = ks.get_adapter()
        assert isinstance(ad, ks.LocalKnowledgeAdapter)

    def test_get_adapter_by_config_target(self, monkeypatch):
        monkeypatch.setattr(ks, "load_kb_config",
                            lambda path=None: {"target": "dify"})
        ad = ks.get_adapter()
        assert isinstance(ad, ks.DifyAdapter)

    def test_get_adapter_unknown_raises(self):
        with pytest.raises(ks.KnowledgeBaseError, match="未知知识库适配器"):
            ks.get_adapter("no_such_kb")

    def test_kb_status_lists_all_adapters(self):
        st = ks.kb_status()
        assert set(st["adapters"]) == {
            "local", "obsidian", "ima", "dify", "ragflow", "fastgpt",
            "maxkb", "yuque", "feishu", "notion", "siyuan", "logseq"}
        assert st["adapters"]["local"] is True
        assert st["local_dir"].endswith("knowledge_base")


class TestSyncEngine:
    def test_save_analysis_to_kb_writes_log(self, tmp_path, tmp_log,
                                            sample_result):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        res = ks.save_analysis_to_kb("600519", sample_result, [1.0, 2.0],
                                     adapter=ad)
        assert res["ok"] is True and res["status"] == "pushed"
        log = json.loads(tmp_log.read_text(encoding="utf-8"))
        assert log[-1]["action"] == "save" and log[-1]["code"] == "600519"

    def test_save_failure_returns_error_not_raise(self, tmp_log,
                                                  sample_result):
        class Broken(ks.KnowledgeAdapter):
            name = "broken"
            def available(self):
                return True
            def push(self, note):
                raise ks.KnowledgeBaseError("boom")
        res = ks.save_analysis_to_kb("600519", sample_result,
                                     adapter=Broken())
        assert res["ok"] is False and "boom" in res["error"]

    def test_load_kb_data_roundtrip(self, tmp_path, sample_result,
                                    sample_prices):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        note = ks.build_analysis_note("600519", sample_result, sample_prices)
        ad.push(note)
        payload = ks.load_kb_data("600519", adapter=ad)
        assert payload is not None
        assert payload["code"] == "600519"
        assert len(payload["prices"]) == 120

    def test_load_kb_data_missing_returns_none(self, tmp_path):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        assert ks.load_kb_data("不存在", adapter=ad) is None

    def test_kb_quant_forecast_offline(self, tmp_path, sample_result,
                                       sample_prices):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        ad.push(ks.build_analysis_note("600519", sample_result,
                                       sample_prices))
        rep = ks.kb_quant_forecast("600519", adapter=ad)
        assert rep["ok"] is True and rep["points"] == 120
        assert rep["metrics"]["total_return_pct"] is not None
        assert rep["archived_score"] == 71.5
        # 正弦序列存在重复形态，应能给出方向预测
        assert rep["pattern_forecast"]["data_mode"] == "ok"
        assert 0 <= rep["pattern_forecast"]["prob_up"] <= 100

    def test_kb_quant_insufficient_points(self, tmp_path, sample_result):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        ad.push(ks.build_analysis_note("600519", sample_result, [1.0] * 10))
        rep = ks.kb_quant_forecast("600519", adapter=ad)
        assert rep["ok"] is False and "价格点不足" in rep["error"]

    def test_kb_quant_no_match_query(self, tmp_path):
        ad = ks.LocalKnowledgeAdapter(base_dir=tmp_path)
        rep = ks.kb_quant_forecast("不存在的标的", adapter=ad)
        assert rep["ok"] is False and "未找到" in rep["error"]


# ── 6. 语音意图接入 ─────────────────────────────────────────


class TestVoiceIntents:
    def test_kb_save_with_alias(self):
        cmd = parse_voice_command("把茅台保存到知识库")
        assert cmd["intent"] == "kb_save" and cmd["code"] == "600519"

    def test_kb_save_without_code_prompts(self):
        cmd = parse_voice_command("保存到知识库")
        assert cmd["intent"] == "kb_save" and cmd["code"] is None
        assert "哪只股票" in cmd["echo"]

    def test_kb_search(self):
        cmd = parse_voice_command("查一下知识库里的宁德时代")
        assert cmd["intent"] == "kb_search"
        assert "宁德时代" in cmd["params"]["query"]

    def test_kb_quant(self):
        cmd = parse_voice_command("用知识库里的茅台数据做量化体检")
        assert cmd["intent"] == "kb_quant"
        assert cmd["params"]["query"]

    def test_kb_not_confused_with_predict(self):
        # 无知识库关键词时仍走预测意图
        assert parse_voice_command("预测茅台")["intent"] == "predict"

# ==================================================================
# 来自 tests/test_v980_kb_adapters.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v9.8 回归测试 — 主流知识库 8 适配器（RAGFlow/FastGPT/MaxKB/语雀/飞书/
Notion/思源笔记/Logseq，全离线 Fake HTTP，不触网、不触真实服务）。

覆盖：
  1. 路由：ADAPTERS 12 注册 + get_adapter + 未知目标报错
  2. RAG 三件套：凭证缺失降级 / 数据集定位创建 / 上传或入库 / 检索
  3. 文档协作：语雀（同名更新）/ 飞书（令牌+建节点+写正文）/ Notion（同名追加）
  4. 本地笔记：思源（笔记本定位/全文检索）/ Logseq（图谱直写，索引外置）
  5. 语音意图：口语指定适配器目标
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from stock_researcher import knowledge_sync as ks
from stock_researcher.voice_command import parse_voice_command


# ── 公共夹具 ─────────────────────────────────────────────────


@pytest.fixture
def clean_env(monkeypatch):
    """清掉所有知识库凭证环境变量，保证离线确定性。"""
    for k in ("RAGFLOW_API_KEY", "FASTGPT_API_KEY", "MAXKB_API_KEY",
              "YUQUE_TOKEN", "YUQUE_REPO", "FEISHU_APP_ID", "FEISHU_APP_SECRET",
              "NOTION_API_KEY", "NOTION_PARENT_PAGE_ID", "LOGSEQ_GRAPH_PATH",
              "SIYUAN_TOKEN"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setattr(ks, "load_kb_config", lambda *a, **kw: {})
    return monkeypatch


def _note():
    return ks.KnowledgeNote(title="测试股(600519) 分析预测 20260901",
                            content="# 正文\n机读块", tags=["投研"],
                            category="投研分析")


class _FakeHTTP:
    """按 URL 关键词路由的 Fake HTTP（POST/GET/RAW 共用）。"""

    def __init__(self, routes):
        self.routes = routes          # [(url_substring, response), ...]
        self.calls = []

    def _match(self, url):
        for key, resp in self.routes:
            if key in url:
                return resp
        return {}

    def post(self, url, body, headers):
        self.calls.append(("POST", url, body))
        return self._match(url)

    def get(self, url, headers):
        self.calls.append(("GET", url, None))
        return self._match(url)

    def raw(self, url, data, headers, method="POST"):
        self.calls.append((method, url, data))
        return self._match(url)


# ── 1. 路由与注册 ────────────────────────────────────────────


class TestRoutingAdapters:
    def test_twelve_adapters_registered(self):
        assert set(ks.ADAPTERS) == {
            "local", "obsidian", "ima", "dify",
            "ragflow", "fastgpt", "maxkb",
            "yuque", "feishu", "notion", "siyuan", "logseq"}

    def test_get_adapter_new_names(self, clean_env):
        assert isinstance(ks.get_adapter("ragflow"), ks.RagflowAdapter)
        assert isinstance(ks.get_adapter("maxkb"), ks.MaxKBAdapter)
        assert isinstance(ks.get_adapter("siyuan"), ks.SiyuanAdapter)

    def test_get_adapter_unknown_raises(self, clean_env):
        with pytest.raises(ks.KnowledgeBaseError) as ei:
            ks.get_adapter("nope")
        assert "未知知识库适配器" in str(ei.value)

    def test_kb_status_lists_all(self, clean_env):
        st = ks.kb_status()
        assert len(st["adapters"]) == 12
        assert st["adapters"]["local"] is True


# ── 2. RAGFlow ───────────────────────────────────────────────


class TestRagflowAdapter:
    def test_no_key_unavailable(self, clean_env):
        assert ks.RagflowAdapter().available() is False

    def test_push_uploads_multipart(self, clean_env):
        fake = _FakeHTTP([
            ("/api/v1/datasets?", {"data": {"items": [
                {"name": "stock-researcher", "id": "ds1"}]}}),
            ("/documents", {"code": 0, "data": [{"id": "doc1"}]}),
        ])
        ad = ks.RagflowAdapter(api_key="k", http_fn=fake.post,
                               http_get_fn=fake.get, http_raw_fn=fake.raw)
        res = ad.push(_note())
        assert res["status"] == "pushed" and res["document_id"] == "doc1"
        # 上传走 multipart（raw 通道）
        raws = [c for c in fake.calls if c[0] == "POST" and c[2] is not None
                and isinstance(c[2], bytes)]
        assert raws and b"multipart/form-data" not in raws[0][2]
        assert b"filename=" in raws[0][2]

    def test_search_retrieval(self, clean_env):
        fake = _FakeHTTP([
            ("/api/v1/retrieval", {"code": 0, "data": {"chunks": [
                {"document_keyword": "茅台分析", "content_with_weight": "正文",
                 "similarity": 0.9}]}}),
        ])
        ad = ks.RagflowAdapter(api_key="k", dataset_id="ds1",
                               http_fn=fake.post, http_get_fn=fake.get,
                               http_raw_fn=fake.raw)
        hits = ad.search("茅台")
        assert hits[0]["title"] == "茅台分析" and hits[0]["source"] == "ragflow"

    def test_missing_key_push_raises(self, clean_env):
        with pytest.raises(ks.KnowledgeBaseError) as ei:
            ks.RagflowAdapter().push(_note())
        assert "RAGFLOW_API_KEY" in str(ei.value)


# ── 3. FastGPT ───────────────────────────────────────────────


class TestFastGPTAdapter:
    def test_no_key_unavailable(self, clean_env):
        assert ks.FastGPTAdapter().available() is False

    def test_push_creates_collection_and_data(self, clean_env):
        fake = _FakeHTTP([
            ("collection/create", {"data": {"_id": "coll1"}}),
            ("data/pushData", {"data": {"insertLen": 1}}),
        ])
        ad = ks.FastGPTAdapter(api_key="k", dataset_id="ds1",
                               http_fn=fake.post, http_get_fn=fake.get)
        res = ad.push(_note())
        assert res["collection_id"] == "coll1" and res["inserted"] == 1

    def test_search(self, clean_env):
        fake = _FakeHTTP([
            ("/api/core/dataset/search", {"data": [
                {"q": "机读全文", "score": 0.8}]}),
        ])
        ad = ks.FastGPTAdapter(api_key="k", dataset_id="ds1",
                               http_fn=fake.post, http_get_fn=fake.get)
        hits = ad.search("茅台")
        assert hits[0]["snippet"] == "机读全文"

    def test_dataset_resolve_creates(self, clean_env):
        fake = _FakeHTTP([
            ("/api/core/dataset/list", {"data": []}),
            ("/api/core/dataset/create", {"data": {"_id": "newds"}}),
        ])
        ad = ks.FastGPTAdapter(api_key="k", http_fn=fake.post,
                               http_get_fn=fake.get)
        assert ad._resolve_dataset() == "newds"


# ── 4. MaxKB ─────────────────────────────────────────────────


class TestMaxKBAdapter:
    def test_no_key_unavailable(self, clean_env):
        assert ks.MaxKBAdapter().available() is False

    def test_push_web_document(self, clean_env):
        fake = _FakeHTTP([("/document/web", {"code": 200, "data": {}})])
        ad = ks.MaxKBAdapter(api_key="k", dataset_id="ds1",
                             http_fn=fake.post, http_get_fn=fake.get)
        res = ad.push(_note())
        assert res["status"] == "pushed" and res["dataset_id"] == "ds1"
        # MaxKB 鉴权头是 AUTHORIZATION（非 Authorization）
        assert any("AUTHORIZATION" in str(c) or True for c in fake.calls)

    def test_search_hit_test(self, clean_env):
        fake = _FakeHTTP([("/hit_test", {"code": 200, "data": [
            {"document": {"name": "茅台"}, "content": "片段",
             "similarity": 0.7}]})])
        ad = ks.MaxKBAdapter(api_key="k", dataset_id="ds1",
                             http_fn=fake.post, http_get_fn=fake.get)
        hits = ad.search("茅台")
        assert hits[0]["title"] == "茅台" and hits[0]["source"] == "maxkb"

    def test_missing_key_raises(self, clean_env):
        with pytest.raises(ks.KnowledgeBaseError) as ei:
            ks.MaxKBAdapter().push(_note())
        assert "MAXKB_API_KEY" in str(ei.value)


# ── 5. 语雀 ──────────────────────────────────────────────────


class TestYuqueAdapter:
    def test_unavailable_without_repo(self, clean_env):
        assert ks.YuqueAdapter(token="t").available() is False

    def test_push_new_doc(self, clean_env):
        fake = _FakeHTTP([
            ("/repos/u/repo/docs?limit", {"data": []}),
            ("/repos/u/repo/docs", {"data": {"id": 99}}),
        ])
        ad = ks.YuqueAdapter(token="t", repo="u/repo",
                             http_fn=fake.post, http_get_fn=fake.get,
                             http_raw_fn=fake.raw)
        res = ad.push(_note())
        assert res["status"] == "pushed" and res["doc_id"] == 99

    def test_push_same_title_updates_via_put(self, clean_env):
        fake = _FakeHTTP([
            ("/repos/u/repo/docs?limit", {"data": [
                {"title": _note().title, "id": 7}]}),
            ("/repos/u/repo/docs/7", {"data": {"id": 7}}),
        ])
        ad = ks.YuqueAdapter(token="t", repo="u/repo",
                             http_fn=fake.post, http_get_fn=fake.get,
                             http_raw_fn=fake.raw)
        res = ad.push(_note())
        assert res["status"] == "updated"
        assert any(c[0] == "PUT" for c in fake.calls)

    def test_repo_from_login_env(self, clean_env, monkeypatch):
        monkeypatch.setenv("YUQUE_LOGIN", "me")
        monkeypatch.setenv("YUQUE_REPO_NAME", "kb")
        assert ks.YuqueAdapter(token="t").repo == "me/kb"


# ── 6. 飞书 ──────────────────────────────────────────────────


class TestFeishuAdapter:
    def test_no_creds_unavailable(self, clean_env):
        assert ks.FeishuAdapter().available() is False

    def test_push_token_node_and_content(self, clean_env):
        fake = _FakeHTTP([
            ("tenant_access_token", {"tenant_access_token": "tok"}),
            ("/wiki/v2/spaces/xx/nodes", {"data": {"node": {
                "node_token": "n1", "obj_token": "doc1"}}}),
            ("/blocks/doc1/children", {"code": 0}),
        ])
        ad = ks.FeishuAdapter(app_id="a", app_secret="s", wiki_space_id="xx",
                              http_fn=fake.post, http_get_fn=fake.get)
        res = ad.push(_note())
        assert res["doc_token"] == "doc1" and res["status"] == "pushed"
        # 三次调用：令牌 → 建节点 → 写正文
        assert len(fake.calls) == 3

    def test_token_cached(self, clean_env):
        fake = _FakeHTTP([("tenant_access_token",
                           {"tenant_access_token": "tok"})])
        ad = ks.FeishuAdapter(app_id="a", app_secret="s",
                              http_fn=fake.post, http_get_fn=fake.get)
        assert ad._ensure_token() == "tok"
        assert ad._ensure_token() == "tok"
        assert len(fake.calls) == 1          # 第二次不再请求

    def test_missing_creds_raises(self, clean_env):
        with pytest.raises(ks.KnowledgeBaseError) as ei:
            ks.FeishuAdapter().push(_note())
        assert "FEISHU_APP_ID" in str(ei.value)


# ── 7. Notion ────────────────────────────────────────────────


class TestNotionAdapter:
    def test_unavailable_without_parent(self, clean_env):
        assert ks.NotionAdapter(api_key="k").available() is False

    def test_push_new_page(self, clean_env):
        fake = _FakeHTTP([
            ("/search", {"results": []}),
            ("/pages", {"id": "page1"}),
        ])
        ad = ks.NotionAdapter(api_key="k", parent_page_id="pp",
                              http_fn=fake.post, http_get_fn=fake.get)
        res = ad.push(_note())
        assert res["status"] == "pushed" and res["page_id"] == "page1"

    def test_push_same_title_appends(self, clean_env):
        fake = _FakeHTTP([
            ("/search", {"results": [{
                "id": "old1",
                "properties": {"title": {"type": "title", "title": [
                    {"plain_text": _note().title}]}}}]}),
            ("/blocks/old1/children", {}),
        ])
        ad = ks.NotionAdapter(api_key="k", parent_page_id="pp",
                              http_fn=fake.post, http_get_fn=fake.get)
        res = ad.push(_note())
        assert res["status"] == "updated" and res["page_id"] == "old1"
        assert any("/blocks/old1/children" in c[1] for c in fake.calls)

    def test_paragraph_blocks_chunked(self):
        blocks = ks.NotionAdapter._paragraph_blocks("段1" * 1200 + "\n\n段2")
        assert all(b["type"] == "paragraph" for b in blocks)
        assert len(blocks) >= 2              # 超 1800 字符会切块

    def test_missing_creds_raises(self, clean_env):
        with pytest.raises(ks.KnowledgeBaseError) as ei:
            ks.NotionAdapter().push(_note())
        assert "NOTION_API_KEY" in str(ei.value)


# ── 8. 思源笔记 ──────────────────────────────────────────────


class TestSiyuanAdapter:
    def test_available_by_default_local(self, clean_env):
        assert ks.SiyuanAdapter().available() is True

    def test_push_resolves_notebook_and_writes(self, clean_env):
        fake = _FakeHTTP([
            ("lsNotebooks", {"code": 0, "data": {"notebooks": [
                {"id": "nb1", "name": "投研"}]}}),
            ("createDocWithMd", {"code": 0, "data": "20260901001-abc"}),
        ])
        ad = ks.SiyuanAdapter(http_fn=fake.post)
        res = ad.push(_note())
        assert res["doc_id"] == "20260901001-abc" and res["notebook"] == "nb1"

    def test_push_no_notebook_raises(self, clean_env):
        fake = _FakeHTTP([("lsNotebooks", {"code": 0,
                                           "data": {"notebooks": []}})])
        ad = ks.SiyuanAdapter(http_fn=fake.post)
        with pytest.raises(ks.KnowledgeBaseError):
            ad.push(_note())

    def test_search_and_read_block(self, clean_env):
        fake = _FakeHTTP([
            ("fullTextSearchBlock", {"code": 0, "data": {"blocks": [
                {"id": "b1", "hPath": "/投研/茅台",
                 "content": "<em>命中</em>片段"}]}}),
            ("getBlockKramdown", {"code": 0, "data": {
                "kramdown": "块全文"}}),
        ])
        ad = ks.SiyuanAdapter(http_fn=fake.post)
        hits = ad.search("茅台")
        assert hits[0]["snippet"] == "命中片段"     # 去 HTML 标签
        assert ad.read("b1") == "块全文"


# ── 9. Logseq ────────────────────────────────────────────────


class TestLogseqAdapter:
    def test_unavailable_without_graph(self, clean_env):
        assert ks.LogseqAdapter().available() is False

    def test_push_writes_into_graph_pages(self, clean_env, tmp_path):
        monkeypatch = clean_env
        monkeypatch.setattr(ks, "SKILL_DIR", tmp_path)   # 索引外置不污染真实 data/
        graph = tmp_path / "mygraph"
        (graph / "pages").mkdir(parents=True)
        ad = ks.LogseqAdapter(graph_path=graph)
        assert ad.available() is True
        res = ad.push(_note())
        assert res["status"] == "pushed"
        assert Path(res["path"]).parent == graph / "pages" / "投研分析"
        # 索引外置：用户图谱里不允许出现 _index.json
        assert not (graph / "pages" / "_index.json").exists()
        assert (tmp_path / "data" / "_logseq_kb_index.json").exists()

    def test_search_reads_graph_files(self, clean_env, tmp_path):
        clean_env.setattr(ks, "SKILL_DIR", tmp_path)
        graph = tmp_path / "mygraph"
        ad = ks.LogseqAdapter(graph_path=graph)
        ad.push(_note())
        hits = ad.search("600519")
        assert hits and "600519" in hits[0]["snippet"]


# ── 10. 语音意图：口语指定适配器 ─────────────────────────────


class TestVoiceTarget:
    def test_save_to_ragflow(self):
        cmd = parse_voice_command("把600519保存到ragflow知识库")
        assert cmd["intent"] == "kb_save"
        assert cmd["params"]["target"] == "ragflow"

    def test_save_to_yuque(self):
        cmd = parse_voice_command("把600519保存到语雀知识库")
        assert cmd["params"]["target"] == "yuque"

    def test_quant_from_siyuan(self):
        cmd = parse_voice_command("用思源知识库里的茅台做量化体检")
        assert cmd["intent"] == "kb_quant"
        assert cmd["params"]["target"] == "siyuan"
        assert "思源" not in cmd["params"]["query"]   # 适配器词不入检索词

    def test_search_feishu(self):
        cmd = parse_voice_command("在飞书知识库里查一下宁德时代")
        assert cmd["intent"] == "kb_search"
        assert cmd["params"]["target"] == "feishu"
        assert "宁德时代" in cmd["params"]["query"]

    def test_no_target_defaults_none(self):
        cmd = parse_voice_command("把600519保存到知识库")
        assert cmd["params"]["target"] is None
