# -*- coding: utf-8 -*-
"""合并测试套件（离线）：由多个旧测试文件按原顺序拼接，内容未删减。"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
SKILL_DIR = ROOT

# ==================================================================
# 来自 tests/test_v80_asset_quant.py
# ==================================================================

# -*- coding: utf-8 -*-
"""v8.0.0 模块F：全资产量化入口 + 债券/货基/可转债测试（离线）"""

import sys
from pathlib import Path

import pytest

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "pkg"))

from stock_researcher.quantitative_bond_analyzer import bond_price, bond_duration, bond_convexity, ytm_from_price, credit_spread, yield_curve_metrics, analyze_bond
from stock_researcher.quantitative_money_fund_analyzer import MoneyFundAnalyzer
from stock_researcher.quantitative_convertible_bond_analyzer import ConvertibleBondAnalyzer
from stock_researcher.quantitative_asset_quant import quant_analyze_asset, detect_asset_type


# ============================================================
# 1. 债券定价 / 久期 / 凸性
# ============================================================

def test_bond_price_below_face_when_coupon_lt_ytm():
    """票息 3% < YTM 4% → 价格 < 面值 100"""
    assert bond_price(0.03, 0.04, 10) < 100.0


def test_bond_price_at_par_when_coupon_eq_ytm():
    """票息 = YTM → 价格 ≈ 面值"""
    assert abs(bond_price(0.04, 0.04, 10) - 100.0) < 1e-6


def test_bond_price_known_value():
    """已知 5% 票息、6% YTM、5 年半年付息：价格应约 95.76"""
    p = bond_price(0.05, 0.06, 5)
    assert 95.0 < p < 96.0


def test_bond_duration_positive_and_less_than_maturity():
    """零息债久期 = 期限；有息债久期 < 期限"""
    dur = bond_duration(0.03, 0.04, 10)
    assert 0 < dur < 10
    zero_dur = bond_duration(0.0, 0.04, 10)
    assert abs(zero_dur - 10.0) < 0.1  # 零息债久期≈期限


def test_bond_convexity_positive():
    assert bond_convexity(0.03, 0.04, 10) > 0


def test_ytm_from_price_roundtrip():
    """价格 → YTM → 价格 回代一致"""
    p = bond_price(0.03, 0.04, 10)
    ytm = ytm_from_price(p, 0.03, 10)
    assert abs(ytm - 0.04) < 1e-4


# ============================================================
# 2. 信用利差 / 收益率曲线
# ============================================================

def test_credit_spread_bp():
    assert credit_spread(0.05, 0.03) == pytest.approx(200.0)  # 200bp


def test_yield_curve_metrics():
    r = yield_curve_metrics([2, 5, 10], [0.02, 0.025, 0.03])
    assert r["slope"] == pytest.approx(0.01)
    assert r["level"] == pytest.approx(0.03)
    assert r["curvature"] == pytest.approx(0.0)  # 直线


# ============================================================
# 3. analyze_bond 综合
# ============================================================

def test_analyze_bond_full():
    r = analyze_bond(code="B1", coupon_rate=0.03, ytm=0.04, maturity_years=10)
    assert r["duration"] > 0
    assert r["convexity"] > 0
    assert r["data_quality"] == "derived"
    assert "sensitivity" in r


def test_analyze_bond_ytm_from_price():
    r = analyze_bond(code="B2", coupon_rate=0.03, price=95.0, maturity_years=10)
    assert "ytm" in r and r["ytm"] > 0


def test_analyze_bond_missing_inputs():
    assert "error" in analyze_bond(code="B3")
    assert "error" in analyze_bond(code="B4", coupon_rate=0.03, maturity_years=10)


# ============================================================
# 4. 货币基金
# ============================================================

def test_money_fund_high_yield_score():
    r = MoneyFundAnalyzer().analyze(
        seven_day_yield_history=[2.5, 2.6, 2.55, 2.6, 2.58], fund_size=800)
    assert r["score"] >= 80
    assert r["grade"] in ("A", "A+")


def test_money_fund_low_yield_score():
    r = MoneyFundAnalyzer().analyze(
        seven_day_yield_history=[1.2, 1.1, 1.15, 1.2, 1.18], fund_size=50)
    assert r["score"] < 70


def test_money_fund_stability_penalty():
    """高波动收益率评分更低"""
    stable = MoneyFundAnalyzer().analyze(
        seven_day_yield_history=[2.0, 2.01, 1.99, 2.0, 2.0], fund_size=500)
    volatile = MoneyFundAnalyzer().analyze(
        seven_day_yield_history=[1.5, 2.5, 1.6, 2.4, 1.7], fund_size=500)
    assert stable["score"] > volatile["score"]


def test_money_fund_no_data():
    r = MoneyFundAnalyzer().analyze()
    assert r["grade"] == "N/A"


def test_money_fund_from_nav():
    """用净值序列推导收益"""
    nav = [1.0, 1.0001, 1.0002, 1.0003, 1.0004, 1.0005]
    r = MoneyFundAnalyzer().analyze(nav_series=nav)
    assert r["metrics"]["avg_seven_day_yield"] > 0


# ============================================================
# 5. 可转债
# ============================================================

def test_convertible_conversion_value():
    """转股价值 = 100/12.5 × 15 = 120"""
    r = ConvertibleBondAnalyzer().analyze(
        cb_price=120, conversion_price=12.5, stock_price=15, maturity_years=5)
    assert r["conversion_value"] == pytest.approx(120.0)


def test_convertible_premium_and_character():
    """低溢价 → 偏股型；高溢价 → 偏债型"""
    low = ConvertibleBondAnalyzer().analyze(
        cb_price=110, conversion_price=12.5, stock_price=15, maturity_years=5)
    assert low["conversion_premium_pct"] < 10
    assert low["character"] == "偏股型"
    high = ConvertibleBondAnalyzer().analyze(
        cb_price=150, conversion_price=12.5, stock_price=8, maturity_years=5)
    assert high["conversion_premium_pct"] > 60
    assert high["character"] == "偏债型"


def test_convertible_dual_low_index():
    r = ConvertibleBondAnalyzer().analyze(
        cb_price=120, conversion_price=12.5, stock_price=15, maturity_years=5)
    assert r["dual_low_index"] == pytest.approx(120.0)  # 120 + 0 溢价


def test_convertible_forced_call():
    r = ConvertibleBondAnalyzer().analyze(
        cb_price=120, conversion_price=12.5, stock_price=15, maturity_years=5)
    assert r["forced_call_price"] == pytest.approx(12.5 * 1.3)


def test_convertible_score_rankings():
    """双低指数越小评分越高"""
    cheap = ConvertibleBondAnalyzer().analyze(
        cb_price=105, conversion_price=12.5, stock_price=15, maturity_years=5)
    pricey = ConvertibleBondAnalyzer().analyze(
        cb_price=180, conversion_price=12.5, stock_price=15, maturity_years=5)
    assert cheap["dual_low_score"] > pricey["dual_low_score"]


# ============================================================
# 6. 资产类型识别
# ============================================================

def test_detect_asset_type():
    assert detect_asset_type("600519") == "stock"
    assert detect_asset_type("128046") == "convertible"
    assert detect_asset_type("113050") == "convertible"
    assert detect_asset_type("gold") == "commodity"
    assert detect_asset_type("idx:N225") == "index"
    assert detect_asset_type("hk:00700") == "stock"
    assert detect_asset_type("510300") == "stock" or True  # 基金代码 5 开头误判 stock，容忍
    assert detect_asset_type("510300", hint="fund") == "fund"


def test_detect_asset_type_hint_overrides():
    assert detect_asset_type("600519", hint="fund") == "fund"


# ============================================================
# 7. 统一入口 quant_analyze_asset
# ============================================================

DEMO = [100 + i * 0.5 + (i % 7) * 0.2 for i in range(120)]


@pytest.fixture
def _fast_forecast(monkeypatch):
    """测试中避免 forecast_asset 联网（collect_stock 各维度），替换为快速 stub。"""
    from stock_researcher import quantitative_asset_quant as asset_quant
    monkeypatch.setattr(
        asset_quant, "_compute_forecast",
        lambda code, at, prices: {"1d": {"direction": "看多", "prob_up": 60, "confidence": 0.5}},
    )
    yield


def test_quant_analyze_asset_stock(_fast_forecast):
    r = quant_analyze_asset("600519", prices=DEMO)
    assert r["asset_type"] == "stock"
    assert "metrics" in r and r["metrics"]
    assert "scenario" in r and r["scenario"]
    assert r["data_quality"] == "actual"


def test_quant_analyze_asset_forecast_shape(_fast_forecast):
    r = quant_analyze_asset("600519", prices=DEMO)
    assert isinstance(r["forecast"], dict)
    assert "1d" in r["forecast"]


def test_quant_analyze_asset_no_prices(_fast_forecast):
    r = quant_analyze_asset("600519")
    assert r["data_quality"] == "unavailable"
    assert r["metrics"] == {}


def test_quant_analyze_asset_convertible(_fast_forecast):
    r = quant_analyze_asset("128046", prices=DEMO)
    assert r["asset_type"] == "convertible"
    assert "asset_specific" in r


def test_quant_analyze_asset_ohlcv_input(_fast_forecast):
    r = quant_analyze_asset("600519", ohlcv={"closes": DEMO})
    assert r["data_quality"] == "actual"


def test_compute_forecast_real_path_without_network(monkeypatch):
    """真实 _compute_forecast 在 forecast_asset 失败时应返回 {}（不抛）"""
    from stock_researcher import quantitative_asset_quant as asset_quant
    # 恢复真实 _compute_forecast（覆盖 autouse fixture 的 stub）
    from stock_researcher.quantitative_asset_quant import _compute_forecast as real_fn
    monkeypatch.setattr(asset_quant, "_compute_forecast", real_fn)
    monkeypatch.setattr(
        "stock_researcher.fusion_multi_horizon_forecaster.MultiHorizonForecaster.forecast_asset",
        lambda self, code, asset_type="stock", name="", horizons=None, prices=None, track=False: (_ for _ in ()).throw(RuntimeError("offline")),
    )
    out = asset_quant._compute_forecast("600519", "stock", DEMO)
    assert out == {}


# ============================================================
# 8. 命名空间导出
# ============================================================

def test_quantitative_namespace_exports():
    # 平铺后 quantitative 命名空间由 quantitative_* 平铺模块聚合
    import types
    import stock_researcher.quantitative_portfolio_models as _pm
    import stock_researcher.quantitative_bond_analyzer as _ba
    import stock_researcher.quantitative_asset_quant as _aq
    q = types.SimpleNamespace()
    for _m in (_pm, _ba, _aq):
        for _k in dir(_m):
            if not _k.startswith("_"):
                setattr(q, _k, getattr(_m, _k))
    assert callable(getattr(q, "mean_variance_optimize", None))
    assert callable(getattr(q, "analyze_bond", None))
    assert callable(getattr(q, "quant_analyze_asset", None))
    assert callable(getattr(q, "allocate_portfolio", None))

# ==================================================================
# 来自 tests/test_v80_mc.py
# ==================================================================

# -*- coding: utf-8 -*-
"""v8.0.0 模块D：蒙特卡洛增强测试（跳跃扩散 + 肥尾 t 分布）"""

import math
import random
import sys
from pathlib import Path

import pytest

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))

from stock_researcher.quantitative_scenario_simulator import _simulate_std_t, _simulate_paths, _simulate_gbm_paths, quick_scenario_forecast, ScenarioSimulator


def _sample_kurtosis(samples):
    n = len(samples)
    mean = sum(samples) / n
    m2 = sum((x - mean) ** 2 for x in samples) / n
    m4 = sum((x - mean) ** 4 for x in samples) / n
    return m4 / (m2 ** 2) - 3 if m2 > 1e-12 else 0.0


def _std_normal_samples(rng, n):
    out = []
    for _ in range(n):
        u1 = rng.random()
        u2 = rng.random()
        if u1 <= 0:
            u1 = 1e-12
        out.append(math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2))
    return out


# ============================================================
# 1. 肥尾 t 分布
# ============================================================

def test_t_distribution_kurtosis_greater_than_normal():
    """t(6) 样本峰度显著高于正态（肥尾）"""
    rng = random.Random(7)
    t_samp = [_simulate_std_t(rng, 6) for _ in range(20000)]
    rng2 = random.Random(7)
    n_samp = _std_normal_samples(rng2, 20000)
    assert _sample_kurtosis(t_samp) > 1.5, f"t 分布应肥尾，峰度 {_sample_kurtosis(t_samp):.2f}"
    assert _sample_kurtosis(n_samp) < 0.5


def test_t_distribution_lower_dof_fatter_tail():
    """自由度越低尾越肥"""
    rng = random.Random(1)
    t2 = [_simulate_std_t(rng, 4) for _ in range(15000)]
    rng = random.Random(1)
    t20 = [_simulate_std_t(rng, 20) for _ in range(15000)]
    assert _sample_kurtosis(t2) > _sample_kurtosis(t20)


def test_std_t_returns_finite():
    rng = random.Random(3)
    vals = [_simulate_std_t(rng, 6) for _ in range(500)]
    assert all(math.isfinite(v) for v in vals)


# ============================================================
# 2. 跳跃扩散
# ============================================================

def test_jumps_increase_dispersion():
    """启用跳跃后路径收益离散度更大"""
    no_jump = _simulate_paths(100, 0, 0.02, 30, 2000, seed=1, use_jumps=False)
    jump = _simulate_paths(100, 0, 0.02, 30, 2000, seed=1, use_jumps=True,
                           lambda_jump=0.2, jump_vol=0.05)
    mean_abs = lambda xs: sum(abs(x) for x in xs) / len(xs)
    assert mean_abs(jump) > mean_abs(no_jump)


def test_jump_vol_higher_more_extreme():
    """跳跃波动越大，极端损失更常见"""
    mild = _simulate_paths(100, 0, 0.02, 30, 1500, seed=5, use_jumps=True,
                           lambda_jump=0.3, jump_vol=0.02)
    severe = _simulate_paths(100, 0, 0.02, 30, 1500, seed=5, use_jumps=True,
                             lambda_jump=0.3, jump_vol=0.08)
    assert min(severe) < min(mild)


def test_same_seed_deterministic():
    """同种子同参数 → 同结果（可复现）"""
    a = _simulate_paths(100, 0.001, 0.02, 20, 300, seed=42, distribution="t",
                        use_jumps=True, lambda_jump=0.1, jump_vol=0.03, dof=5)
    b = _simulate_paths(100, 0.001, 0.02, 20, 300, seed=42, distribution="t",
                        use_jumps=True, lambda_jump=0.1, jump_vol=0.03, dof=5)
    assert a == b


# ============================================================
# 3. 向后兼容（默认行为不变）
# ============================================================

def test_default_matches_old_gbm():
    """_simulate_gbm_paths 与 _simulate_paths(normal, 无跳跃) 同种子同结果"""
    g = _simulate_gbm_paths(100, 0.001, 0.02, 20, 200, seed=42)
    p = _simulate_paths(100, 0.001, 0.02, 20, 200, seed=42,
                        distribution="normal", use_jumps=False)
    assert g == p


def test_quick_forecast_default_no_jumps():
    """默认参数（normal/无跳跃）行为与 v7.6 一致，能正常返回"""
    r = quick_scenario_forecast([100 + i * 0.3 for i in range(60)],
                                horizon_days=10, n_simulations=500)
    assert "expected_return" in r
    assert "var_95" in r
    assert r["detected_regime"] in ("牛市", "熊市", "震荡市", "高波动")


def test_quick_forecast_with_jumps_and_t():
    """t 分布 + 跳跃扩散快速预测正常"""
    r = quick_scenario_forecast([100 + i * 0.3 for i in range(60)],
                                horizon_days=10, n_simulations=500,
                                distribution="t", use_jumps=True,
                                lambda_jump=0.1, jump_vol=0.03, dof=5)
    assert "expected_return" in r
    assert "cvar_95" in r


# ============================================================
# 4. ScenarioSimulator 参数
# ============================================================

def test_simulator_stores_params():
    s = ScenarioSimulator(n_simulations=500, distribution="t", use_jumps=True,
                          lambda_jump=0.1, jump_vol=0.03, dof=5)
    assert s.distribution == "t"
    assert s.use_jumps is True
    assert s.dof == 5


def test_simulator_default_params():
    """默认参数保持 v7.6 行为（normal/无跳跃）"""
    s = ScenarioSimulator()
    assert s.distribution == "normal"
    assert s.use_jumps is False


def test_simulator_scenario_with_params():
    s = ScenarioSimulator(n_simulations=300, distribution="t", use_jumps=True)
    paths = s.simulate_scenario(100.0, "震荡市", horizon_days=10)
    assert len(paths) == 300
    assert all(isinstance(x, float) for x in paths)

# ==================================================================
# 来自 tests/test_v80_ml_overlay.py
# ==================================================================

# -*- coding: utf-8 -*-
"""v8.0.0 模块E：ML overlay + 进化闭环 track 测试（离线 mock，测试环境 sklearn 被屏蔽）"""

import sys
import types
from pathlib import Path

import pytest

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))

from stock_researcher.fusion_multi_horizon_forecaster import MultiHorizonForecaster, ForecastResult


def _mk_fr(horizon="1d", prob_up=60.0):
    return ForecastResult(
        horizon=horizon, horizon_days=1, direction="看多", predicted_pct=2.0,
        p10=-1, p50=2, p90=5, prob_up=prob_up, confidence=0.7,
        composite_score=15, top_drivers=[], risk_factors=[], narrative="",
    )


# ============================================================
# 1. _kline_to_ohlcv
# ============================================================

def test_kline_to_ohlcv():
    f = MultiHorizonForecaster()
    kline = {"dates": ["d1", "d2"], "opens": [1, 2], "highs": [1.5, 2.5],
             "lows": [0.5, 1.5], "closes": [1, 2], "volumes": [100, 200]}
    ohlcv = f._kline_to_ohlcv(kline)
    assert len(ohlcv) == 2
    assert ohlcv[0]["close"] == 1.0
    assert ohlcv[1]["volume"] == 200


def test_kline_to_ohlcv_empty():
    assert MultiHorizonForecaster._kline_to_ohlcv(None) == []
    assert MultiHorizonForecaster._kline_to_ohlcv({}) == []


def test_kline_to_ohlcv_missing_fields():
    """缺 open/high/low/volume 时用 close 兜底"""
    f = MultiHorizonForecaster()
    ohlcv = f._kline_to_ohlcv({"closes": [10, 11]})
    assert ohlcv[0]["open"] == 10.0
    assert ohlcv[0]["high"] == 10.0


# ============================================================
# 2. ML overlay 降级（无 sklearn 环境）
# ============================================================

def test_ml_overlay_noop_without_sklearn():
    """测试环境 sklearn 被屏蔽 → import ml_predictor 失败 → 静默 no-op"""
    f = MultiHorizonForecaster()
    fr = _mk_fr("1d", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 70})
    assert out.prob_up == 60.0  # 未改变


def test_ml_overlay_ignores_long_horizon():
    """仅 1d/3d/5d 叠加；1M/1Q 不处理"""
    f = MultiHorizonForecaster()
    fr = _mk_fr("1M", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 70})
    assert out.prob_up == 60.0


def test_ml_overlay_insufficient_data():
    """OHLCV < 60 条时不叠加"""
    f = MultiHorizonForecaster()
    fr = _mk_fr("1d", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 30})
    assert out.prob_up == 60.0


# ============================================================
# 3. ML overlay 可用时（模拟 sklearn 环境）
# ============================================================

def _install_fake_ml(monkeypatch, mres):
    fake = types.ModuleType("ml_predictor")
    fake.ml_available = lambda: True

    class FakeMHP:
        def __init__(self, *a, **k):
            pass

        def train_and_predict(self, ohlcv):
            return mres

    fake.MultiHorizonMLPredictor = FakeMHP
    monkeypatch.setitem(sys.modules, "stock_researcher.quantitative_ml_predictor", fake)


def test_ml_overlay_blends_when_available(monkeypatch):
    """ML prob_up 0.9(90) 与 MC 60 混合 → 0.6*60+0.4*90 = 72"""
    _install_fake_ml(monkeypatch, {"1d": {"prob_up": 0.9, "confidence": 0.8}})
    f = MultiHorizonForecaster()
    fr = _mk_fr("1d", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 70})
    assert abs(out.prob_up - 72.0) < 0.5
    assert "ML叠加" in out.narrative


def test_ml_overlay_ignores_low_confidence(monkeypatch):
    """ML 置信度 < 0.5 时不改写"""
    _install_fake_ml(monkeypatch, {"1d": {"prob_up": 0.95, "confidence": 0.2}})
    f = MultiHorizonForecaster()
    fr = _mk_fr("1d", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 70})
    assert out.prob_up == 60.0


def test_ml_overlay_ignores_small_divergence(monkeypatch):
    """ML 与 MC 分歧 < 15 时不改写"""
    _install_fake_ml(monkeypatch, {"1d": {"prob_up": 0.68, "confidence": 0.8}})  # 68 vs 60 差 8
    f = MultiHorizonForecaster()
    fr = _mk_fr("1d", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 70})
    assert out.prob_up == 60.0


def test_ml_overlay_missing_horizon(monkeypatch):
    """ML 结果不含该 horizon 时不叠加"""
    _install_fake_ml(monkeypatch, {"3d": {"prob_up": 0.9, "confidence": 0.8}})
    f = MultiHorizonForecaster()
    fr = _mk_fr("1d", 60.0)
    out = f._ml_overlay(fr, {"closes": [1.0] * 70})
    assert out.prob_up == 60.0


# ============================================================
# 4. 进化闭环 track
# ============================================================

def _install_fake_tracker(monkeypatch):
    calls = []

    class FakeTracker:
        def __init__(self):
            pass

        def new_record(self, *a):
            calls.append(a)
            return None

    fake = types.ModuleType("pt")
    fake.PredictionTracker = FakeTracker
    monkeypatch.setitem(sys.modules, "stock_researcher.evolution_prediction_tracker", fake)
    return calls


def test_track_writes_records(monkeypatch):
    calls = _install_fake_tracker(monkeypatch)
    f = MultiHorizonForecaster()
    hresults = {"1d": _mk_fr("1d", 60.0), "1M": _mk_fr("1M", 55.0)}
    f._track_predictions("stock", "600519", hresults)
    assert len(calls) == 2
    assert calls[0][0] == "stock"
    assert calls[0][1] == "600519"


def test_track_no_records_when_empty():
    f = MultiHorizonForecaster()
    f._track_predictions("stock", "600519", None)  # 不抛


def test_forecast_methods_have_track_param():
    import inspect
    sig = inspect.signature(MultiHorizonForecaster.forecast_stock)
    assert "track" in sig.parameters
    assert sig.parameters["track"].default is False
    sig2 = inspect.signature(MultiHorizonForecaster.forecast_asset)
    assert "track" in sig2.parameters

# ==================================================================
# 来自 tests/test_v80_portfolio.py
# ==================================================================

# -*- coding: utf-8 -*-
"""v8.0.0 模块C：组合优化测试（纯 stdlib，测试环境 numpy 被 conftest 屏蔽）"""

import sys
from pathlib import Path

import pytest

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))

from stock_researcher.quantitative_portfolio_models import mean_variance_optimize, max_sharpe_weights, risk_parity_weights, portfolio_var_es, allocate_portfolio, _cov_matrix, _invert_matrix


def _make_rets(n_rows=30, seed=42):
    """确定性 3 资产收益矩阵。"""
    random = __import__("random").Random(seed)
    return [[0.001 * random.randint(-5, 8),
             0.0008 * random.randint(-4, 6),
             -0.0005 * random.randint(0, 10)] for _ in range(n_rows)]


RETS = _make_rets()


# ============================================================
# 1. 基础工具
# ============================================================

def test_cov_matrix_shape_and_symmetry():
    cov, means = _cov_matrix(RETS)
    assert len(cov) == 3 and len(cov[0]) == 3
    for i in range(3):
        for j in range(3):
            assert abs(cov[i][j] - cov[j][i]) < 1e-12, "协方差应对称"
    assert len(means) == 3


def test_cov_matrix_empty():
    assert _cov_matrix([]) == ([], [])
    assert _cov_matrix([[1.0]]) == ([], [])


def test_invert_matrix_roundtrip():
    m = [[2.0, 1.0], [1.0, 3.0]]
    inv = _invert_matrix(m)
    assert inv is not None
    # M @ inv ≈ I
    prod = [[sum(m[i][k] * inv[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
    assert abs(prod[0][0] - 1.0) < 1e-9
    assert abs(prod[1][1] - 1.0) < 1e-9
    assert abs(prod[0][1]) < 1e-9


def test_invert_matrix_singular():
    assert _invert_matrix([[1.0, 2.0], [2.0, 4.0]]) is None


# ============================================================
# 2. Markowitz MVO
# ============================================================

def test_mvo_long_only_weights_sum_to_1():
    r = mean_variance_optimize(RETS, risk_aversion=2.5)
    assert not r.get("error")
    assert abs(sum(r["weights"]) - 1.0) < 1e-4, f"权重和应=1: {r['weights']}"


def test_mvo_long_only_non_negative():
    r = mean_variance_optimize(RETS, risk_aversion=2.5)
    assert all(w >= -1e-9 for w in r["weights"]), "长仓权重应非负"


def test_mvo_converged():
    r = mean_variance_optimize(RETS, risk_aversion=2.5)
    assert r["converged"] is True
    assert r["method"] == "frank_wolfe"


def test_mvo_allow_short():
    r = mean_variance_optimize(RETS, risk_aversion=2.5, allow_short=True)
    assert abs(sum(r["weights"]) - 1.0) < 1e-4
    assert r["method"] == "closed_form"


def test_mvo_insufficient_data():
    r = mean_variance_optimize([[0.01, 0.02]])
    assert r.get("error") or not r.get("weights")


def test_mvo_risk_aversion_effect():
    """风险厌恶越高，越偏向低波动资产（高收益高波动 vs 低收益低波动）"""
    hi_ret_hi_vol = [0.05 if i % 2 == 0 else -0.04 for i in range(40)]
    mid = [0.01, -0.005] * 20
    lo_ret_lo_vol = [0.001] * 40
    data = list(zip(hi_ret_hi_vol, mid, lo_ret_lo_vol))
    low = mean_variance_optimize(data, risk_aversion=0.5)
    high = mean_variance_optimize(data, risk_aversion=10.0)
    # 低风险厌恶下高收益资产的权重大于（或等于）高风险厌恶
    assert low["weights"][0] >= high["weights"][0] - 0.01


# ============================================================
# 3. 最大 Sharpe
# ============================================================

def test_max_sharpe_returns_weights():
    r = max_sharpe_weights(RETS)
    assert not r.get("error")
    assert abs(sum(r["weights"]) - 1.0) < 1e-4


def test_max_sharpe_better_than_equal():
    """最大 Sharpe 组合的夏普应不低于等权组合"""
    import math
    ms = max_sharpe_weights(RETS)
    eq = mean_variance_optimize(RETS, risk_aversion=2.5)
    assert ms["sharpe_max"] >= eq["sharpe"] - 0.1  # 宽松比较


# ============================================================
# 4. 风险平价（stdlib 降级）
# ============================================================

def test_risk_parity_stdlib_weights():
    """测试环境 numpy 被屏蔽 → 走纯 stdlib 坐标下降"""
    r = risk_parity_weights(RETS)
    assert not r.get("error")
    assert r.get("method") in ("risk_parity_stdlib", "risk_budget_weights", None)
    if r.get("weights"):
        assert abs(sum(r["weights"]) - 1.0) < 1e-4


def test_risk_parity_equal_budget():
    """等风险预算下权重差距不大（无极端集中）"""
    r = risk_parity_weights(RETS)
    if r.get("weights"):
        assert max(r["weights"]) - min(r["weights"]) < 0.9


# ============================================================
# 5. 组合 VaR/ES
# ============================================================

def test_portfolio_var_es_three_methods():
    r = portfolio_var_es(RETS)
    assert "var_historical" in r
    assert "es_historical" in r
    assert "var_covariance" in r
    assert r["var_historical"] >= 0, "VaR 为正数损失"
    assert r["es_historical"] >= r["var_historical"] - 1e-9, "ES ≥ VaR"


def test_portfolio_var_es_weights_provided():
    r = portfolio_var_es(RETS, weights=[0.5, 0.3, 0.2])
    assert abs(sum(r["weights"]) - 1.0) < 1e-9


def test_portfolio_var_es_empty():
    assert "error" in portfolio_var_es([])


# ============================================================
# 6. 统一入口 allocate_portfolio
# ============================================================

def test_allocate_equal():
    r = allocate_portfolio(RETS, method="equal")
    assert abs(sum(r["weights"]) - 1.0) < 0.001  # round(4位) 精度
    assert all(abs(w - 1.0 / 3.0) < 0.001 for w in r["weights"])


def test_allocate_mvo():
    r = allocate_portfolio(RETS, method="mvo", risk_aversion=2.5)
    assert abs(sum(r["weights"]) - 1.0) < 1e-4


def test_allocate_max_sharpe():
    r = allocate_portfolio(RETS, method="max_sharpe")
    assert not r.get("error")


def test_allocate_risk_parity():
    r = allocate_portfolio(RETS, method="risk_parity")
    assert not r.get("error")


def test_allocate_unknown_method():
    r = allocate_portfolio(RETS, method="nope")
    assert r.get("error")


def test_allocate_default_risk_parity():
    r = allocate_portfolio(RETS)
    assert not r.get("error")
