# -*- coding: utf-8 -*-
"""v13.0 Word 导出（export_docx）测试。

关注三件真会炸的事：OOXML 部件与引用是否闭合、中文字形有没有显式 eastAsia、
同一份报告两次渲染是否字节一致。全部临时文件写到仓库外的系统临时目录。
"""
import io
import os
import shutil
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher import export_docx as ex
from stock_researcher.report_ir import (
    Bullets, Callout, CodeBlock, Heading, MetricGrid, Paragraph,
    ReportDocument, Section, Table,
)
from stock_researcher.research_contracts import (
    AssetAnalysis, DataQualityReport, Evidence, Factor, ForecastDistribution,
    ResearchReport, Scenario,
)

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"

REQUIRED_PARTS = ["[Content_Types].xml", "_rels/.rels", "word/document.xml",
                  "word/styles.xml", "word/_rels/document.xml.rels",
                  "docProps/core.xml", "docProps/app.xml"]


def make_report():
    """用 research_contracts 的数据类拼一份真报告（覆盖有预测/证据的分支）。"""
    return ResearchReport(
        schema_version="12.0", run_id="unit-docx", generated_at="2026-09-25T10:00:00",
        symbol="600519", asset_type="stock", name="贵州茅台",
        question="现在值得关注吗？", as_of="2026-09-25", data_cutoff="2026-09-25",
        executive_summary="基本面稳健，估值处于历史中位附近 & 需留意批价。",
        direction="bullish", confidence=0.62, score=63.5,
        asset_analysis=AssetAnalysis(
            symbol="600519", asset_type="stock", name="贵州茅台", price=1423.0,
            score=63.5, direction="bullish", confidence=0.62, quality="actual",
            factors=[Factor("动量", "technical", 42.0, 0.8, 0.6,
                            "20 日相对强弱转正", ["EV01"], "actual"),
                     Factor("估值", "value", 18.0, 0.6, 0.5,
                            "PE 分位 35% < 中位", ["EV02"], "derived")],
            metrics={"收盘价": "1423.00", "周涨跌": "+1.2%"},
            evidence_ids=["EV01", "EV02"], risks=["批价走弱 < 预期>"],
            conflicts=["动量与估值方向不一致"], warnings=["样本期偏短"]),
        forecasts=[
            ForecastDistribution("5日", 5, "neutral", 0.58, 0.20, 0.22, 1.2,
                                 confidence=0.6, sample_size=320,
                                 effective_sample_size=180.5, quality="actual",
                                 quantiles={"p05": -3.1, "p95": 5.6}, skill_score=0.021),
            ForecastDistribution("30日", 30, "bullish", 0.66, 0.15, 0.19, 4.4,
                                 confidence=0.45, sample_size=90, quality="derived",
                                 quantiles={"p05": -6.0, "p95": 15.2}, abstain=True),
        ],
        scenarios=[Scenario("基准", 0.5, 8.0, (1450.0, 1620.0), ["销量稳"], ["中报"]),
                   Scenario("下行", 0.2, -12.0, (1180.0, 1290.0), ["批价跌"])],
        data_quality=DataQualityReport("actual", 0.78, 0.92, "realtime",
                                       ["unit_test"], ["龙虎榜"], ["样本期偏短"],
                                       {"行情": "actual", "新闻": "derived"}),
        evidence=[Evidence("EV01", "quote", "收盘价", "1423.00", "unit_test",
                           "2026-09-25", quality="actual"),
                  Evidence("EV02", "valuation", "PE 分位", "35%", "unit_test",
                           "2026-09-25", quality="derived")],
        conclusions=["短期中性偏多", "仓位控制在前"],
        risks=["回撤 > 15% 的概率不低"], counterpoints=["估值已计入复苏 🚀"],
        methodology=["历史条件样本估计"], warnings=["样本量偏少"],
        disclaimer="本报告仅供研究参考，不构成投资建议。")


def make_doc():
    return ReportDocument(
        title="贵州茅台 研究简报", subtitle="综合方向 bullish｜置信度 62%",
        meta=[("标的", "600519（stock）"), ("数据截止", "2026-09-25")],
        sections=[
            Section("一、结论摘要", [
                Paragraph("基本面稳健，估值中位。", "lead"),
                Heading("核心结论", 3),
                Bullets(["ROE 维持 18% 以上", "渠道库存去化完成"]),
            ]),
            Section("二、多周期概率预测", [
                Table(header=["周期", "方向", "上涨概率"],
                      rows=[["5日", "neutral", "58%"], ["30日", "bullish", "66%"]],
                      align=["left", "center", "right"], caption="预测表"),
                Callout("概率来自历史条件样本估计。"),
            ]),
            Section("三、因子与证据", [
                MetricGrid([("完整度", "92%"), ("质量分", "0.71")]),
                CodeBlock("score = 0.4*mom + 0.6*value", "python"),
                Callout("样本量偏少 🚀 & <tag>", kind="warning"),
            ]),
        ],
        disclaimer="本报告仅供研究参考，不构成投资建议。")


def unzip(blob):
    return zipfile.ZipFile(io.BytesIO(blob))


def scratch_dir():
    """系统临时目录，且断言它真的在包外（包树里不许落任何中间产物）。"""
    root = os.path.realpath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    td = os.path.realpath(tempfile.mkdtemp(prefix="qoder_docx_"))
    if td == root or td.startswith(root + os.sep):
        shutil.rmtree(td, ignore_errors=True)
        raise RuntimeError("临时目录落在包内：%s" % root)
    return td


def texts_of(xml_bytes):
    """document.xml 里所有 w:t 文本拼起来（含表格单元格）。"""
    return "".join(t.text or "" for t in ET.fromstring(xml_bytes).iter(W + "t"))


class TestEngineResolution(unittest.TestCase):
    def test_stdlib_is_always_first(self):
        self.assertEqual(ex.engines()[0], "stdlib")
        self.assertEqual(ex.resolve_engine("auto"), "stdlib")
        self.assertEqual(ex.resolve_engine("stdlib"), "stdlib")
        self.assertEqual(ex.resolve_engine("STDlib "), "stdlib")
        self.assertEqual(ex.resolve_engine(""), "stdlib")
        self.assertEqual(ex.resolve_engine(None), "stdlib")

    def test_enhanced_engine_listed_only_when_importable(self):
        has = ex._has_python_docx()
        self.assertEqual("python-docx" in ex.engines(), has)
        if has:
            self.assertEqual(ex.resolve_engine("python-docx"), "python-docx")
            self.assertEqual(ex.resolve_engine("python_docx"), "python-docx")
        else:
            with self.assertRaises(ex.ExportError):
                ex.resolve_engine("python-docx")

    def test_unknown_engine_raises_value_error(self):
        for bad in ("pages", "wtf-9"):
            with self.assertRaises(ValueError):
                ex.resolve_engine(bad)

    def test_no_third_party_import_at_module_level(self):
        """顶层绝不 import 第三方库（沙箱里 pip 包不一定存在）——按 AST 只查顶层。"""
        import ast
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "stock_researcher", "export_docx.py")
        with open(path, encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        allowed = {"__future__", "io", "logging", "os", "re", "xml", "zipfile",
                   "typing", "collections", "stock_researcher"}
        top = []
        for node in tree.body:
            if isinstance(node, ast.Import):
                top.extend(a.name for a in node.names)
            elif isinstance(node, ast.ImportFrom):
                top.append(node.module or "")
        for mod in top:
            self.assertTrue(mod.split(".")[0] in allowed,
                            "%s 只能在函数里延迟导入" % mod)
        self.assertFalse([m for m in top if m.split(".")[0] in ("docx", "pptx", "lxml")])


class TestStdlibPackage(unittest.TestCase):
    def setUp(self):
        self.doc = make_doc()
        self.blob = ex.render(self.doc, engine="stdlib")
        self.z = unzip(self.blob)

    def test_unzips_with_every_required_part(self):
        names = set(self.z.namelist())
        for part in REQUIRED_PARTS:
            self.assertIn(part, names)
        self.assertIn("word/footer1.xml", names)

    def test_every_xml_part_parses(self):
        for name in self.z.namelist():
            if name.endswith(".xml") or name.endswith(".rels"):
                ET.fromstring(self.z.read(name))

    def test_relationship_targets_and_content_types_close(self):
        names = set(self.z.namelist())
        rels = {r.get("Type").rsplit("/", 1)[-1]: r.get("Target")
                for r in ET.fromstring(self.z.read("_rels/.rels"))}
        self.assertEqual(rels["officeDocument"], "word/document.xml")
        self.assertIn("core-properties", rels)
        self.assertIn("extended-properties", rels)
        doc_rels = {r.get("Id"): r.get("Target") for r in ET.fromstring(
            self.z.read("word/_rels/document.xml.rels"))}
        for rid in [f.get(R + "id") for f in ET.fromstring(
                self.z.read("word/document.xml")).iter(W + "footerReference")]:
            self.assertIn(rid, doc_rels)
            self.assertIn("word/" + doc_rels[rid], names)
        root = ET.fromstring(self.z.read("[Content_Types].xml"))
        overrides = {o.get("PartName") for o in root}
        for part in ("word/document.xml", "word/styles.xml", "word/footer1.xml",
                     "docProps/core.xml", "docProps/app.xml"):
            self.assertIn("/" + part, overrides)

    def test_body_holds_section_titles_and_table_cells(self):
        text = texts_of(self.z.read("word/document.xml"))
        for chunk in ("一、结论摘要", "二、多周期概率预测", "上涨概率", "58%", "66%"):
            self.assertIn(chunk, text)

    def test_cjk_survives_the_round_trip(self):
        xml = self.z.read("word/document.xml").decode("utf-8")
        self.assertIn("贵州茅台 研究简报", xml)          # 中西文同 run 不拆散
        self.assertIn("综合方向 bullish｜置信度", xml)
        self.assertIn("本报告仅供研究参考", self.z.read("word/footer1.xml").decode("utf-8"))

    def test_east_asian_fonts_are_explicit(self):
        styles = self.z.read("word/styles.xml").decode("utf-8")
        doc = self.z.read("word/document.xml").decode("utf-8")
        self.assertIn('w:eastAsia="%s"' % ex.BODY_EA_FONT, styles)   # docDefaults 兜底
        self.assertIn('w:eastAsia="%s"' % ex.HEAD_EA_FONT, doc)      # 标题另设
        self.assertIn('w:ascii="%s"' % ex.MONO_FONT, doc)            # 代码块等宽

    def test_headings_map_to_numbered_styles_with_outline_level(self):
        styles = ET.fromstring(self.z.read("word/styles.xml"))
        by_id = {s.get(W + "styleId"): s for s in styles.findall(W + "style")}
        for sid in ("Heading1", "Heading2", "Heading3"):
            self.assertIn(sid, by_id)
            self.assertIsNotNone(by_id[sid].find(W + "pPr/" + W + "outlineLvl"))
        used = {e.get(W + "val") for e in
                ET.fromstring(self.z.read("word/document.xml")).iter(W + "pStyle")}
        self.assertIn("Heading1", used)
        self.assertIn("Heading3", used)                    # Heading(level=3) 也落位
        self.assertIn("Title", used)

    def test_page_is_a4_with_footer_and_table_within_content_width(self):
        body = ET.fromstring(self.z.read("word/document.xml")).find(W + "body")
        sect = body.find(W + "sectPr")
        size = sect.find(W + "pgSz")
        self.assertEqual((int(size.get(W + "w")), int(size.get(W + "h"))), (11906, 16838))
        mar = sect.find(W + "pgMar")
        self.assertEqual(int(mar.get(W + "left")), ex.MARGIN)
        self.assertIsNotNone(sect.find(W + "footerReference"))
        for grid in body.iter(W + "tblGrid"):
            total = sum(int(c.get(W + "w")) for c in grid)
            self.assertLessEqual(total, int(size.get(W + "w")) - 2 * ex.MARGIN)
            self.assertEqual(total, ex.CONTENT_W)          # 列宽和=版心宽，不溢出页面

    def test_tables_are_real_wtbl_with_shaded_bold_header(self):
        body = ET.fromstring(self.z.read("word/document.xml")).find(W + "body")
        tbl = next(body.iter(W + "tbl"))
        self.assertEqual(tbl.find(W + "tblPr/" + W + "tblW").get(W + "type"), "pct")
        self.assertEqual(tbl.find(W + "tblPr/" + W + "tblW").get(W + "w"), "5000")
        self.assertIsNotNone(tbl.find(W + "tblPr/" + W + "tblBorders"))
        self.assertEqual(tbl.find(W + "tblPr/" + W + "tblLayout").get(W + "type"), "fixed")
        grid = tbl.find(W + "tblGrid")
        rows = tbl.findall(W + "tr")
        head, data = rows[0], rows[1]
        self.assertEqual(len(head.findall(W + "tc")), len(grid))   # 格数=列数，否则 Word 判坏
        self.assertEqual(len(data.findall(W + "tc")), len(grid))
        self.assertIsNotNone(head.find(W + "trPr/" + W + "tblHeader"))  # 跨页重复表头
        for tc in head.findall(W + "tc"):
            self.assertEqual(tc.find(W + "tcPr/" + W + "shd").get(W + "fill"), ex.HEADER_FILL)
            self.assertIsNotNone(tc.find(".//" + W + "b"))          # 表头加粗
        got = [tc.find(W + "p/" + W + "pPr/" + W + "jc").get(W + "val")
               for tc in data.findall(W + "tc")]                    # 每列按 Table.align 落位
        self.assertEqual(got, ["left", "center", "right"])

    def test_long_table_cells_wrap_and_stay_inside_the_page(self):
        long_text = "很长的一格" * 40
        doc = ReportDocument(title="长表", sections=[Section("二、多周期概率预测", [
            Table(header=["周期", "说明", "概率"],
                  rows=[["%d日" % i, long_text, "58%"] for i in range(1, 41)])])],
            disclaimer="免责")
        xml = unzip(ex.render(doc)).read("word/document.xml")
        body = ET.fromstring(xml)
        tbls = list(body.iter(W + "tbl"))
        self.assertEqual(len(tbls), 1)
        widths = [int(c.get(W + "w")) for c in tbls[0].find(W + "tblGrid")]
        self.assertEqual(sum(widths), ex.CONTENT_W)                 # 不超出版心
        self.assertEqual(len(tbls[0].findall(W + "tr")), 41)        # 40 行一行不丢
        self.assertEqual(texts_of(xml).count(long_text), 40)        # 格内换行不截断

    def test_warning_callout_is_visually_distinct(self):
        xml = self.z.read("word/document.xml").decode("utf-8")
        text = texts_of(self.z.read("word/document.xml"))
        self.assertIn(ex.WARN_FILL, xml)                            # warning 用警示底色
        self.assertIn(ex.NOTE_FILL, xml)                            # note 用另一种底色
        self.assertNotEqual(ex.WARN_FILL, ex.NOTE_FILL)
        self.assertIn("注意：样本量偏少", text)                        # 且带"注意"前缀
        self.assertTrue(ex._box("提示", "note").startswith("<w:tbl>"))

    def test_deterministic_bytes(self):
        self.assertEqual(self.blob, ex.render(make_doc(), engine="stdlib"))
        for info in unzip(self.blob).infolist():
            self.assertEqual(info.date_time, ex.ZIP_DATE)
        core = self.z.read("docProps/core.xml")
        self.assertNotIn(b"dcterms:created", core)
        self.assertNotIn(b"dcterms:modified", core)

    def test_markup_and_emoji_do_not_corrupt_xml(self):
        doc = ReportDocument(title='A & B <C> 🚀', subtitle='1 < 2 & 3 > 2 "quo"',
                             meta=[("标的", "600519<>")],
                             sections=[Section("风险 & 提示", [
                                 Bullets(["<script>alert(1)</script> 🐛"]),
                                 Table(header=["项 & 值", "说明"],
                                       rows=[["<b>", "带 & 的格 🚀"]]),
                             ])], disclaimer="&amp; 原样 & 转义")
        z = unzip(ex.render(doc, engine="stdlib"))
        for name in z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))                  # 转义不彻底在这里炸
        joined = texts_of(z.read("word/document.xml"))
        for chunk in ("A & B <C>", "<b>", "带 & 的格", '"quo"'):
            self.assertIn(chunk, joined)
        self.assertNotIn("🚀", joined)                        # BMP 外换成占位方块
        self.assertIn("\u25a1", joined)
        for ch in joined:
            self.assertLess(ord(ch), 0x10000)
        self.assertIn(b"&amp;", z.read("word/document.xml"))

    def test_control_chars_are_stripped(self):
        doc = ReportDocument(title="控制\x00符\x07测试",
                             sections=[Section("A \x0b B", [Paragraph("x\x1f y")])],
                             disclaimer="d")
        z = unzip(ex.render(doc, engine="stdlib"))
        for ch in texts_of(z.read("word/document.xml")):
            self.assertGreaterEqual(ord(ch), 0x20)
            self.assertNotEqual(ord(ch), 0x7f)

    def test_unknown_block_degrades_to_paragraph(self):
        class Odd:
            text = "怪块"
        doc = ReportDocument(title="t", sections=[Section("s", [Odd()])], disclaimer="d")
        self.assertIn("怪块", texts_of(unzip(ex.render(doc)).read("word/document.xml")))


class TestFixtureReport(unittest.TestCase):
    """用 research_contracts 数据类拼的真报告：IR → docx 全链路。"""

    def setUp(self):
        self.blob = ex.render(make_report(), engine="stdlib")
        self.z = unzip(self.blob)
        self.xml = self.z.read("word/document.xml")
        self.text = texts_of(self.xml)

    def test_all_seven_ir_sections_render(self):
        for title in ("一、结论摘要", "二、多周期概率预测", "三、因子与证据", "四、情景分析",
                      "五、风险、反方证据与数据质量", "六、证据链", "七、方法与限制"):
            self.assertIn(title, self.text)

    def test_forecast_and_factor_table_cells(self):
        self.assertIn("上涨概率", self.text)        # 9 列表头
        self.assertIn("90%区间", self.text)
        self.assertIn("5日", self.text)
        self.assertIn("弃权", self.text)            # abstain=True 标记
        self.assertIn("动量", self.text)            # 因子表
        self.assertIn("1423.00", self.text)         # 证据值
        self.assertIn("EV01", self.text)

    def test_metric_grid_and_bullets_and_code_present(self):
        self.assertIn("收盘价", self.text)          # MetricGrid 的键列
        self.assertIn("20 日相对强弱转正", self.text)
        self.assertIn("本报告仅供研究参考", self.text)
        self.assertIn("\u25a1", self.text)          # 表情被安全替换

    def test_dict_input_is_coerced_via_build_document(self):
        payload = make_report().to_dict()
        self.assertEqual(ex.render(payload, engine="stdlib"), self.blob)

    def test_to_dict_object_input(self):
        class Only:
            def to_dict(self):
                return {"symbol": "RB2610", "name": "螺纹钢", "asset_type": "futures",
                        "disclaimer": "杠杆品种。"}
        self.assertIn("螺纹钢 研究简报",
                      texts_of(unzip(ex.render(Only())).read("word/document.xml")))

    def test_garbage_input_raises_export_error(self):
        for bad in (3.14, None, object()):
            with self.assertRaises(ex.ExportError):
                ex.render(bad)


class TestMinimalReport(unittest.TestCase):
    def test_empty_document_is_a_valid_file(self):
        blob = ex.render(ReportDocument(title="空报告"), engine="stdlib")
        z = unzip(blob)
        self.assertEqual(blob[:2], b"PK")
        for part in REQUIRED_PARTS:
            self.assertIn(part, z.namelist())
        for name in z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        self.assertIn("空报告", texts_of(z.read("word/document.xml")))

    def test_report_without_forecasts_or_evidence(self):
        report = ResearchReport(schema_version="12.0", run_id="empty",
                                generated_at="2026-09-25", symbol="000001",
                                asset_type="stock", name="平安银行",
                                disclaimer="样本不足，本报告不构成投资建议。")
        z = unzip(ex.render(report, engine="stdlib"))
        text = texts_of(z.read("word/document.xml"))
        for part in z.namelist():
            if part.endswith((".xml", ".rels")):
                ET.fromstring(z.read(part))
        for chunk in ("二、多周期概率预测", "数据不足，未生成概率预测。", "六、证据链",
                      "无可用证据。", "免责声明", "不构成投资建议"):
            self.assertIn(chunk, text)
        self.assertIn("样本不足", z.read("word/footer1.xml").decode("utf-8"))


class TestRenderToFile(unittest.TestCase):
    def test_writes_caller_path_and_returns_abspath(self):
        td = scratch_dir()
        self.addCleanup(shutil.rmtree, td, ignore_errors=True)
        target = os.path.join(td, "嵌套", "sub", ex.DEFAULT_FILENAME)
        written = ex.render_to_file(make_doc(), target, engine="stdlib")
        self.assertEqual(written, os.path.abspath(target))
        with open(target, "rb") as fh:
            self.assertEqual(fh.read(), ex.render(make_doc(), engine="stdlib"))
        self.assertFalse(glob_files(td, "__pycache__"))

    def test_overwrites_existing_file(self):
        td = scratch_dir()
        self.addCleanup(shutil.rmtree, td, ignore_errors=True)
        target = os.path.join(td, "again.docx")
        with open(target, "wb") as fh:
            fh.write(b"stale")
        ex.render_to_file(make_doc(), target, engine="stdlib")
        with open(target, "rb") as fh:
            self.assertEqual(fh.read(), ex.render(make_doc(), engine="stdlib"))


def glob_files(root, name):
    hits = []
    for base, _dirs, files in os.walk(root):
        hits.extend(f for f in files if f == name)
    return hits


class TestNoStdoutNoise(unittest.TestCase):
    def test_render_writes_nothing_to_stdout(self):
        import contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            ex.render(make_doc())
            ex.render(make_report(), engine="stdlib")
        self.assertEqual(buf.getvalue(), "")


@unittest.skipUnless(ex._has_python_docx(), "python-docx 未安装")
class TestEnhancedEngine(unittest.TestCase):
    def test_parses_and_is_deterministic(self):
        blob = ex.render(make_doc(), engine="python-docx")
        self.assertEqual(blob, ex.render(make_doc(), engine="python-docx"))
        z = unzip(blob)
        for name in z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        for part in ("word/document.xml", "word/styles.xml", "[Content_Types].xml"):
            self.assertIn(part, z.namelist())
        self.assertNotIn(b"dcterms:created", z.read("docProps/core.xml"))

    def test_content_and_fonts_match_stdlib(self):
        text = texts_of(unzip(ex.render(make_doc(), engine="python-docx"))
                        .read("word/document.xml"))
        for chunk in ("一、结论摘要", "二、多周期概率预测", "上涨概率", "58%",
                      "注意：样本量偏少", "表：预测表", "完整度"):
            self.assertIn(chunk, text)
        styles = unzip(ex.render(make_doc(), engine="python-docx")).read("word/styles.xml")
        self.assertIn('w:eastAsia="%s"' % ex.BODY_EA_FONT, styles.decode("utf-8"))

    def test_page_setup_and_table_header_repeat(self):
        import docx
        doc = docx.Document(io.BytesIO(ex.render(make_doc(), engine="python-docx")))
        sect = doc.sections[0]
        self.assertAlmostEqual(sect.page_width.mm, 210, delta=1)
        self.assertAlmostEqual(sect.left_margin.mm, 25.4, delta=1)
        self.assertIn("不构成投资建议", doc.paragraphs[-1].text + sect.footer.paragraphs[0].text)
        table = doc.tables[0]
        self.assertEqual(table.cell(0, 0).text, "周期")
        self.assertEqual(table.cell(1, 2).text, "58%")


@unittest.skipUnless(ex._has_python_docx(), "python-docx 未安装")
class TestStdlibOutputIsReadableByWordLibs(unittest.TestCase):
    def test_python_docx_opens_stdlib_package(self):
        """能被 python-docx 正常解析 ≈ 能被 Word 解析（同一套 schema 校验）。"""
        import docx
        doc = docx.Document(io.BytesIO(ex.render(make_doc(), engine="stdlib")))
        self.assertAlmostEqual(doc.sections[0].page_width.mm, 210, delta=1)
        styles = [p.style.name for p in doc.paragraphs]
        self.assertIn("Title", styles)
        self.assertIn("Heading 1", styles)
        joined = "\n".join(p.text for p in doc.paragraphs)
        for chunk in ("贵州茅台 研究简报", "二、多周期概率预测", "三、因子与证据"):
            self.assertIn(chunk, joined)
        tables = doc.tables
        self.assertGreaterEqual(len(tables), 3)              # 预测表 + 指标表 + callout 框
        self.assertEqual(tables[0].cell(0, 0).text, "周期")
        self.assertEqual(tables[0].cell(1, 2).text, "58%")
        self.assertEqual(tables[0].cell(2, 2).text, "66%")
        self.assertEqual(doc.sections[0].footer.paragraphs[0].text,
                         "本报告仅供研究参考，不构成投资建议。")


if __name__ == "__main__":
    unittest.main()
