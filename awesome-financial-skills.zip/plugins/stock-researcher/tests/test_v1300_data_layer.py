# -*- coding: utf-8 -*-
"""v13.0 数据层真实性回归测试。

锁住四处修复：
1. `_is_unavailable`：适配器返回"取不到"的元数据壳时不能算查询成功，
   否则期货/北向日间无数据也会被报成 success=True、confidence=0.8。
2. KLINE 路由：此前 ("cn", KLINE) 没注册，SinaFinanceAdapter._kline_cn
   与 research_data 的 K 线回退分支永远走不到。
3. `AkshareAdapter._pick_code`：akshare spot 接口返回全市场大表，
   不裁行会让上层把整张表当成一只票。
4. `_run_with_timeout`：akshare 自身无超时，网络抖动会把降级链拖成分钟级假死。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import unittest
import urllib.request
from pathlib import Path
from unittest import mock

from stock_researcher import data_multi_source as dms
from stock_researcher.data_multi_source import (
    DataCategory, DataSource, MultiSourceRouter, SOURCE_ROUTING,
    SINGLE_SOURCE_CONFIDENCE, _is_unavailable, _run_with_timeout,
)

ROOT = Path(__file__).resolve().parents[1]


def _spawn_works() -> bool:
    try:
        subprocess.run([sys.executable, "-c", "pass"], timeout=30,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except OSError:
        return False


_SPAWN_OK = _spawn_works()


class _FakeHTTP:
    """替身 _HttpClient：只按 URL 前缀返回预置响应，绝不联网。"""

    def __init__(self, payload: bytes = b"", error: Exception = None):
        self.payload = payload
        self.error = error
        self.calls = []

    def get(self, url, headers=None, timeout=10.0):
        self.calls.append(url)
        if self.error:
            raise self.error
        return (self.payload, {}) if self.payload else (None, {})


class _StubAdapter:
    def __init__(self, result, *, explode=False, unavailable=False):
        self.result = result
        self.explode = explode
        self.available = True
        self.calls = 0

    def query(self, market, category, **params):
        self.calls += 1
        if self.explode:
            raise RuntimeError("源炸了")
        return self.result


class TestUnavailableMarker(unittest.TestCase):
    """"取不到数据"必须与"查到 0"区分开。"""

    def test_dict_shapes_that_mean_unavailable(self):
        for payload in (
            {"code": "AU2502", "available": False},
            {"code": "AU2502", "quality": "unavailable"},
            {"code": "AU2502", "quality": "MISSING"},
            {"note": "no data", "quality": "none"},
        ):
            self.assertTrue(_is_unavailable(payload), payload)

    def test_real_payloads_are_not_unavailable(self):
        for payload in (
            {"price": 0.0},                       # 真取到 0 价，不是"没数据"
            {"price": 1800.0, "quality": "actual"},
            {"available": True, "price": 1.0},
            [{"date": "2026-10-26", "close": 10.0}],
            None,
            "sina",
        ):
            self.assertFalse(_is_unavailable(payload), payload)

    def test_router_degrades_past_unavailable_shell(self):
        router = MultiSourceRouter()
        shell = _StubAdapter({"code": "AU2502", "exchange": "SHFE",
                              "available": False})
        winner = _StubAdapter({"price": 5000.0, "source": "xueqiu"})
        router._adapters = {DataSource.SINA: shell, DataSource.XUEQIU: winner}
        routing = {("cn", DataCategory.KLINE): [DataSource.SINA, DataSource.XUEQIU]}
        with mock.patch.object(dms, "SOURCE_ROUTING", routing):
            result = router.query("cn", DataCategory.KLINE, code="AU2502")
        self.assertTrue(result.success)
        self.assertEqual(result.source, DataSource.XUEQIU.value)
        self.assertEqual(result.tried_sources, [f"{DataSource.SINA.value}(unavailable)"])
        self.assertEqual(result.confidence, SINGLE_SOURCE_CONFIDENCE)
        self.assertEqual(shell.calls, 1)
        self.assertEqual(winner.calls, 1)

    def test_router_fails_loudly_when_every_source_is_unavailable(self):
        router = MultiSourceRouter()
        router._adapters = {
            DataSource.SINA: _StubAdapter({"available": False}),
            DataSource.XUEQIU: _StubAdapter(None),
        }
        routing = {("cn", DataCategory.KLINE): [DataSource.SINA, DataSource.XUEQIU]}
        with mock.patch.object(dms, "SOURCE_ROUTING", routing):
            result = router.query("cn", DataCategory.KLINE, code="AU2502")
        self.assertFalse(result.success)
        self.assertEqual(result.freshness, "unavailable")
        self.assertIn(f"{DataSource.XUEQIU.value}(no_data)", result.tried_sources)
        self.assertIn(f"{DataSource.SINA.value}(unavailable)", result.tried_sources)

    def test_exploded_source_does_not_stop_the_chain(self):
        router = MultiSourceRouter()
        router._adapters = {
            DataSource.SINA: _StubAdapter(None, explode=True),
            DataSource.XUEQIU: _StubAdapter({"price": 4000.0}),
        }
        routing = {("cn", DataCategory.KLINE): [DataSource.SINA, DataSource.XUEQIU]}
        with mock.patch.object(dms, "SOURCE_ROUTING", routing):
            result = router.query("cn", DataCategory.KLINE, code="AU2502")
        self.assertTrue(result.success)
        self.assertEqual(result.source, DataSource.XUEQIU.value)
        self.assertTrue(result.tried_sources[0].startswith(
            f"{DataSource.SINA.value}(err:"))

    def test_unrouted_category_returns_clear_error(self):
        router = MultiSourceRouter()
        with mock.patch.object(dms, "SOURCE_ROUTING", {}):
            result = router.query("cn", DataCategory.KLINE, code="600519")
        self.assertFalse(result.success)
        self.assertIn("未配置", result.error)


class TestKlineRouting(unittest.TestCase):
    """KLINE 必须真的在路由表里，且新浪分支可达。"""

    def test_cn_kline_route_exists(self):
        route = SOURCE_ROUTING.get(("cn", DataCategory.KLINE))
        self.assertIsNotNone(route, "cn/KLINE 未注册路由（旧 bug 复现）")
        self.assertIn(DataSource.SINA, route)

    def test_every_route_points_at_a_registered_source(self):
        for key, sources in SOURCE_ROUTING.items():
            self.assertIsInstance(key, tuple, key)
            market, category = key
            self.assertIn(market, ("cn", "hk", "us", "global", "jp", "kr"))
            self.assertIsInstance(category, DataCategory, key)
            self.assertTrue(sources, f"{key} 路由为空列表")
            for source in sources:
                self.assertIsInstance(source, DataSource, key)

    def test_sina_kline_reachable_offline(self):
        adapter = dms.SinaFinanceAdapter()
        payload = json.dumps([{"day": "2026-10-23", "open": "10", "high": "11",
                               "low": "9", "close": "10.5", "volume": "100"}]
                             ).encode("gbk")
        adapter._http = _FakeHTTP(payload)
        result = adapter.query("cn", DataCategory.KLINE, code="600519")
        self.assertIsInstance(result, list)
        self.assertEqual(result[0]["close"], "10.5")
        self.assertIn("datalen=200", adapter._http.calls[0])
        self.assertIn("sh600519", adapter._http.calls[0])

    def test_sina_kline_silent_on_bad_body(self):
        adapter = dms.SinaFinanceAdapter()
        adapter._http = _FakeHTTP(b"not json at all")
        self.assertIsNone(adapter.query("cn", DataCategory.KLINE, code="600519"))
        adapter._http = _FakeHTTP()          # 空响应
        self.assertIsNone(adapter.query("cn", DataCategory.KLINE, code="600519"))

    def test_sina_quote_needs_a_code(self):
        adapter = dms.SinaFinanceAdapter()
        adapter._http = _FakeHTTP(b"x")
        self.assertIsNone(adapter.query("cn", DataCategory.KLINE, code=""))
        self.assertIsNone(adapter.query("us", DataCategory.KLINE, code="AAPL"))


class TestAksharePickCode(unittest.TestCase):
    """全市场大表必须按代码裁成一行。

    conftest 把 pandas 屏蔽掉了（保证零依赖交付），所以真表断言放到
    子进程里跑——被屏蔽的进程内只能验证"没有 pandas 时不假装成功"。
    """

    CHILD = r"""
import json, sys
sys.path.insert(0, sys.argv[1])
import pandas as pd
from stock_researcher.data_multi_source import AkshareAdapter

table = pd.DataFrame([
    {"代码": "600519", "名称": "贵州茅台", "最新价": 1800.0},
    {"代码": "000001", "名称": "平安银行", "最新价": 11.0},
    {"代码": "300750", "名称": "宁德时代", "最新价": float("nan")},
])
pick = AkshareAdapter._pick_code
out = {
    "hit": pick(table, "600519"),
    "miss": pick(table, "999999"),
    "nocol": pick(pd.DataFrame([{"最新价": 1.0}]), "600519"),
    "empty_rows": len(pick(table, "")),
    "pad": pick(pd.DataFrame([{"代码": "000001", "最新价": 11.0}]), "1"),
    "symbol_col": pick(pd.DataFrame([{"symbol": "AAPL", "最新价": 9.0}]), "aapl"),
    "none_table": pick(None, "600519"),
    "nan_row": pick(table, "300750"),
}
print(json.dumps(out, ensure_ascii=False, default=float))
"""

    def setUp(self):
        import subprocess
        if not _SPAWN_OK:
            self.skipTest("当前环境禁止启动子进程")
        proc = subprocess.run(
            [sys.executable, "-c", self.CHILD, str(ROOT)],
            capture_output=True, text=True, timeout=120,
        )
        if proc.returncode != 0:
            if "No module named" in proc.stderr and "pandas" in proc.stderr:
                self.skipTest("本解释器没有 pandas")
            self.fail(f"子进程校验失败：{proc.stderr[-400:]}")
        self.out = json.loads(proc.stdout.strip().splitlines()[-1])

    def test_matching_code_returns_one_row_as_dict(self):
        self.assertIsInstance(self.out["hit"], dict)
        self.assertEqual(self.out["hit"]["最新价"], 1800.0)
        self.assertEqual(self.out["hit"]["名称"], "贵州茅台")

    def test_nan_cells_are_normalised_to_none(self):
        self.assertEqual(self.out["nan_row"], {"代码": "300750", "名称": "宁德时代",
                                               "最新价": None})

    def test_unknown_code_returns_none_not_first_row(self):
        # 旧写法把整张表原样返回，归一化层会取第一行冒充查询结果。
        self.assertIsNone(self.out["miss"])

    def test_table_without_code_column_returns_none(self):
        self.assertIsNone(self.out["nocol"])

    def test_empty_code_keeps_full_table(self):
        self.assertEqual(self.out["empty_rows"], 3)

    def test_padding_and_column_aliases(self):
        self.assertEqual(self.out["pad"]["最新价"], 11.0)
        self.assertEqual(self.out["symbol_col"]["最新价"], 9.0)

    def test_non_table_input_is_safe(self):
        self.assertIsNone(self.out["none_table"])

    def test_works_without_pandas_by_refusing_to_guess(self):
        # 进程内 pandas 被屏蔽时，绝不能退化成"返回整张表"或"返回第一行"。
        self.assertIsNone(dms.AkshareAdapter._pick_code(object(), "600519"))
        self.assertEqual(dms.AkshareAdapter._pick_code(None, ""), None)


class TestRunsWithWallClockBudget(unittest.TestCase):
    """第三方阻塞调用必须有墙钟上限。"""

    def test_fast_call_returns_value(self):
        ok, value = _run_with_timeout(lambda: 42, 2.0)
        self.assertTrue(ok)
        self.assertEqual(value, 42)

    def test_slow_call_returns_immediately_on_timeout(self):
        started = time.monotonic()
        ok, value = _run_with_timeout(lambda: time.sleep(3.0), 0.2)
        elapsed = time.monotonic() - started
        self.assertFalse(ok)
        self.assertIsNone(value)
        self.assertLess(elapsed, 1.5, f"超时没起作用，白等了 {elapsed:.1f}s")

    def test_exception_is_reraised_not_swallowed(self):
        def boom():
            raise ValueError("源报错")
        with self.assertRaises(ValueError):
            _run_with_timeout(boom, 1.0)

    def test_akshare_timeout_is_env_overridable_and_positive(self):
        self.assertGreater(dms.AKSHARE_TIMEOUT, 0.0)
        self.assertLessEqual(dms.AKSHARE_TIMEOUT, 60.0)


class TestSourceLabelling(unittest.TestCase):
    """QueryResult.source 必须是真正给出数据的那个源。"""

    def test_source_field_names_the_winning_adapter(self):
        router = MultiSourceRouter()
        router._adapters = {
            DataSource.SINA: _StubAdapter(None),
            DataSource.GTIMG: _StubAdapter({"price": 1.0}),
        }
        routing = {("cn", DataCategory.REALTIME_QUOTE):
                   [DataSource.SINA, DataSource.GTIMG]}
        with mock.patch.object(dms, "SOURCE_ROUTING", routing):
            result = router.query("cn", DataCategory.REALTIME_QUOTE, code="600519")
        self.assertTrue(result.success)
        self.assertEqual(result.source, DataSource.GTIMG.value)
        self.assertNotEqual(result.source, DataSource.SINA.value)
        self.assertEqual(result.source_count, 1)

    def test_router_exposes_every_routed_source_as_an_adapter_slot(self):
        router = MultiSourceRouter()
        routed = {s for sources in SOURCE_ROUTING.values() for s in sources}
        for source in routed:
            self.assertIn(source, router._adapters, f"{source} 有路由但没适配器槽位")


class TestNoProcessGlobalSideEffects(unittest.TestCase):
    """数据层默认路径不得改全局 opener、不得起子进程。"""

    @staticmethod
    def _no_switches():
        keep = ("STOCK_RESEARCHER_DIRECT_CONNECT",
                "STOCK_RESEARCHER_ENABLE_EXTERNAL_MCP")
        cleaned = {k: v for k, v in os.environ.items() if k not in keep}
        return mock.patch.dict(os.environ, cleaned, clear=True)

    def test_direct_connect_helper_is_off_without_the_env_var(self):
        opener_before = urllib.request._opener
        with self._no_switches():
            self.assertFalse(dms._enable_direct_connection_if_set())
        self.assertIs(urllib.request._opener, opener_before)

    def test_failed_fetch_leaves_the_global_opener_alone(self):
        opener_before = urllib.request._opener
        adapter = dms.EastmoneyApiAdapter()
        with self._no_switches(), mock.patch(
                "urllib.request.urlopen", side_effect=OSError("offline")):
            self.assertIsNone(adapter._fetch(
                "https://push2.eastmoney.com/api/qt/stock/get?secid=1.600519"))
        self.assertIs(urllib.request._opener, opener_before)

    def test_external_mcp_adapter_never_forks_without_authorization(self):
        with mock.patch("subprocess.Popen") as popen, self._no_switches():
            adapter = dms.ExternalMCPAdapter(command="python some_mcp.py")
            self.assertFalse(adapter.connect())
            self.assertFalse(popen.called)
            self.assertFalse(adapter.available)
            self.assertIsNone(adapter.query("cn", DataCategory.REALTIME_QUOTE,
                                            code="600519"))
            adapter.disconnect()

    def test_external_mcp_adapter_without_command_never_forks(self):
        with mock.patch("subprocess.Popen") as popen:
            adapter = dms.ExternalMCPAdapter()
            # allow=True 也不能在没有命令的情况下凭空起一个进程
            self.assertFalse(adapter.connect(allow=True))
            self.assertFalse(popen.called)

    def test_unauthorized_router_registration_returns_false(self):
        router = MultiSourceRouter()
        with mock.patch("subprocess.Popen") as popen, self._no_switches():
            self.assertFalse(router.register_external_mcp("python some_mcp.py"))
        self.assertFalse(popen.called)


if __name__ == "__main__":
    unittest.main()
