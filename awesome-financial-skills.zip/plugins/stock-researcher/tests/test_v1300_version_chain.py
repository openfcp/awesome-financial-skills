# -*- coding: utf-8 -*-
"""v13.0 版本链与交付合规闸门。

两件事必须一次说清：
  1. 版本链所有落点（常量/包/mcp/清单/配置/文档）必须是同一个版本号；
  2. 上架包的形式合规：SKILL.md frontmatter 能被"朴素解析器"读出来且不超 6KB，
     依赖清单拆成核心零依赖 + 可选清单，v13 剔除清单里的模块不在交付包里。
"""
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys_path = str(ROOT)
if sys_path not in __import__("sys").path:
    __import__("sys").path.insert(0, sys_path)

from stock_researcher.constants import VERSION, RESEARCH_CAPABILITY_VERSION

EXPECTED = "14.0.0"
FRONTMATTER_LIMIT = 6144


def _read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


class TestVersionChain(unittest.TestCase):
    """版本链一处都不能漏。"""

    def test_release_version_is_v1300(self):
        self.assertEqual(VERSION, EXPECTED)
        self.assertEqual(RESEARCH_CAPABILITY_VERSION, EXPECTED)

    def test_package_and_constants_agree(self):
        import stock_researcher
        self.assertEqual(stock_researcher.__version__, VERSION)

    def test_mcp_server_reports_same_version(self):
        text = _read("mcp_server.py")
        self.assertIn(f'VERSION = "{VERSION}"', text)
        self.assertIn('constants.get("RESEARCH_CAPABILITY_VERSION", VERSION)', text)

    def test_plugin_manifest_matches(self):
        # 专家包里清单在包根，技能包里清单不在 skill 副本内；两处口径必须一致。
        candidates = [ROOT / ".codebuddy-plugin" / "plugin.json",
                      ROOT.parent.parent / ".codebuddy-plugin" / "plugin.json"]
        found = next((c for c in candidates if c.is_file()), None)
        self.assertIsNotNone(found, "找不到 plugin.json")
        plugin = json.loads(found.read_text(encoding="utf-8"))
        self.assertEqual(plugin["version"], VERSION)

    def test_skill_frontmatter_matches(self):
        fm = _read("SKILL.md").split("---", 2)[1]
        self.assertIn(f"version: {VERSION}", fm)
        self.assertIn(f"research_capability_version: {RESEARCH_CAPABILITY_VERSION}", fm)

    def test_meta_and_settings_match(self):
        meta = json.loads(_read("_meta.json"))
        self.assertEqual(meta["version"], VERSION)
        self.assertEqual(meta["researchCapabilityVersion"], VERSION)
        self.assertEqual(meta["maintenance"]["changelog"][0]["version"], VERSION)
        settings = json.loads(_read("config/settings.json"))
        self.assertEqual(settings["version"], VERSION)
        self.assertEqual(settings["research_capability_version"], VERSION)
        self.assertEqual(settings["_version_info"]["version"], VERSION)

    def test_mcp_tool_count_matches_settings(self):
        settings = json.loads(_read("config/settings.json"))
        meta = json.loads(_read("_meta.json"))
        tools = len(re.findall(r"^@server\.tool\(\)", _read("mcp_server.py"), re.M))
        self.assertEqual(tools, settings["mcp_tools"])
        self.assertEqual(tools, meta["totalMcpTools"])

    def test_self_check_version_tags_agree(self):
        for rel in ("stock_researcher/ai_analysis_engine.py",
                    "stock_researcher/prediction_v1100.py",
                    "stock_researcher/data_multi_source.py"):
            self.assertIn('"version": "v14.0"', _read(rel), rel)


class TestSkillHubFormCompliance(unittest.TestCase):
    """市场解析器用最朴素的 split('---') 读 frontmatter，坏了就解析不出正文。"""

    def setUp(self):
        self.src = _read("SKILL.md")

    def test_frontmatter_parses_with_naive_split(self):
        parts = self.src.split("---", 2)
        self.assertGreaterEqual(len(parts), 3, "frontmatter 解析失败")
        self.assertEqual(parts[0].strip(), "")
        self.assertIn("name: stock-researcher", parts[1])
        # 收尾分隔符必须真的在：否则正文会被吃进 frontmatter，市场解析正文就空了
        self.assertNotIn("# ", parts[1], "frontmatter 里混进了正文标题")
        self.assertTrue(parts[2].lstrip().startswith("#"),
                        "正文应从一级标题开始")

    def test_frontmatter_has_no_dash_triple(self):
        fm = self.src.split("---", 2)[1]
        self.assertNotIn("---", fm, "frontmatter 内不能再出现 ---（会截断解析）")

    def test_frontmatter_within_6kb(self):
        fm = self.src.split("---", 2)[1]
        self.assertLessEqual(len(fm.encode("utf-8")), FRONTMATTER_LIMIT)

    def test_required_frontmatter_fields(self):
        fm = self.src.split("---", 2)[1]
        for field in ("name:", "version:", "display_name:", "description_zh:",
                      "description_en:", "description:", "auto_trigger:", "license:"):
            self.assertIn(field, fm, field)

    def test_description_is_not_a_changelog(self):
        fm = self.src.split("---", 2)[1]
        lines = fm.splitlines()
        start = next(i for i, ln in enumerate(lines)
                     if ln.startswith("description:"))
        block = []
        for ln in lines[start + 1:]:
            if ln and not ln.startswith((" ", "\t")):
                break
            block.append(ln)
        desc = "\n".join(block)
        self.assertNotIn("v11.0", desc, "description 不该再塞版本变更日志")
        self.assertLess(len(desc.encode("utf-8")), 2000)

    def test_body_has_no_unrendered_placeholder(self):
        body = self.src.split("---", 2)[2]
        self.assertNotIn("约 X%", body)


class TestDependencySplit(unittest.TestCase):
    """核心零依赖，可选项另放一份清单。"""

    def test_core_requirements_has_no_package_pins(self):
        core = _read("requirements.txt")
        pins = [ln.strip() for ln in core.splitlines()
                if ln.strip() and not ln.strip().startswith("#")]
        self.assertEqual(pins, [], f"核心清单里出现了包依赖：{pins}")

    def test_optional_requirements_lists_engines(self):
        opt = _read("requirements-optional.txt")
        for pkg in ("mcp", "python-docx", "python-pptx", "reportlab"):
            self.assertIn(pkg, opt, pkg)

    def test_optional_file_ships(self):
        self.assertTrue((ROOT / "requirements-optional.txt").is_file())


class TestPublishedPackageExclusions(unittest.TestCase):
    """上架包不含语音/外部 MCP 模块；源码树里还在（构建脚本只在源码树）。"""

    EXCLUDED = ("stock_researcher/voice_interface.py",
                "stock_researcher/mcp_external_bridge.py",
                "run_voice.py")

    @staticmethod
    def _is_dev_tree() -> bool:
        # 只有源码树带构建脚本（clean.py / build_expert_package.py 不进交付包）
        return (ROOT / "clean.py").is_file() or (ROOT / "build_expert_package.py").is_file()

    def test_excluded_modules_follow_tree_kind(self):
        for rel in self.EXCLUDED:
            exists = (ROOT / rel).is_file()
            if self._is_dev_tree():
                self.assertTrue(exists, f"源码树应保留 {rel}")
            else:
                self.assertFalse(exists, f"上架包不该有 {rel}")

    def test_clean_py_exposes_single_exclusion_list(self):
        if not self._is_dev_tree():
            self.skipTest("上架包内没有构建脚本")
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "sr_clean", ROOT / "clean.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        for rel in self.EXCLUDED:
            self.assertIn(rel, mod.SECURITY_EXCLUDE)
        members = dict(mod._package_members(mod.SKILL_ONLY_EXCLUDE))
        for rel in self.EXCLUDED:
            self.assertNotIn(rel, members)

    def test_voice_parser_ships_everywhere(self):
        from stock_researcher.voice_command import parse_voice_command
        self.assertEqual(parse_voice_command("预测茅台")["code"], "600519")

    def test_voice_parser_in_package_members(self):
        if not self._is_dev_tree():
            self.skipTest("上架包内没有构建脚本")
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "sr_clean2", ROOT / "clean.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        members = dict(mod._package_members(mod.SKILL_ONLY_EXCLUDE))
        self.assertIn("stock_researcher/voice_command.py", members)


if __name__ == "__main__":
    unittest.main()
