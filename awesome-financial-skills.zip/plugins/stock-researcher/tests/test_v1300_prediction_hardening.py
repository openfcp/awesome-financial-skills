# -*- coding: utf-8 -*-
"""v13.0 预测层加固回归测试。

覆盖三处真 bug：
1. kNN 邻域分位数键名不匹配（local 用 qNN、对外用 pNN），
   修复前邻域分布永远取不到，条件预测静默退化成无条件历史分布。
2. prediction_v1100 用 `0.55 + 预期收益/100` 冒充概率，
   修复后概率必须是 Φ(μ/σ) 且封顶，区间宽度必须真的是 70% 分位。
3. 期货主力合约靠代码后缀猜测、到期日一律按每月 15 日，
   修复后主力由持仓量/成交量认定，中金所股指/国债按"第 N 个周五"。
"""
from __future__ import annotations

import math
import unittest
from datetime import date


def _trend_prices(n: int = 180, drift: float = 0.0008, vol: float = 0.02) -> list:
    """确定性伪随机游走（不依赖 random.seed 的平台差异）。"""
    prices = [100.0]
    x = 12345
    for _ in range(n):
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        shock = (x / 0x7FFFFFFF - 0.5) * 2 * vol
        prices.append(max(1.0, prices[-1] * (1 + drift + shock)))
    return prices


class TestKnnLocalQuantiles(unittest.TestCase):
    """邻域分位数必须真的参与混合。"""

    def _engine(self):
        from stock_researcher.research_analysis import EmpiricalForecastEngine
        return EmpiricalForecastEngine()

    def _global_quantiles(self, eng, prices, days: int = 21):
        """无条件历史分布——修复前所有分位数都只会等于它。"""
        vals = list(prices)
        _feats, targets, _times = eng._samples(vals, days)
        flat = [1.0] * len(targets)
        return {f"p{q:02d}": eng._weighted_quantile(targets, flat, q)
                for q in (5, 25, 50, 75, 95)}

    def test_local_quantiles_are_consumed_not_dropped(self):
        eng = self._engine()
        prices = _trend_prices()
        global_q = self._global_quantiles(eng, prices)
        # 把邻域统计替换成一个明显偏离全局的"假邻域"，看混合是否真的采纳。
        real = eng._local_stats
        fake = {
            "n_eff": 60.0, "weights": [1.0], "values": [0.0],
            "mean": 5.0, "median": 5.0,
            "q05": 4.0, "q25": 4.5, "q50": 5.0, "q75": 5.5, "q95": 6.0,
            "p_up": 1.0,
        }
        eng._local_stats = lambda *a, **k: dict(fake)
        try:
            forecast = eng.forecast_horizon(prices, "1M", 21)
        finally:
            eng._local_stats = real
        shrink = 60.0 / (60.0 + 12.0)
        for key in ("p05", "p25", "p75", "p95"):
            self.assertNotAlmostEqual(
                forecast.quantiles[key], round(global_q[key], 4), delta=0.05,
                msg=f"{key} 仍等于全局分位数：邻域分布被丢弃了（旧 bug 复现）")
        # 假邻域是一条很窄的分布，混合后整体区间必须明显收窄。
        self.assertLess(forecast.quantiles["p95"] - forecast.quantiles["p05"],
                        global_q["p95"] - global_q["p05"])
        self.assertAlmostEqual(
            forecast.quantiles["p50"],
            round(shrink * 5.0 + (1 - shrink) * global_q["p50"], 4), places=3)

    def test_zero_effective_sample_falls_back_to_global_distribution(self):
        eng = self._engine()
        prices = _trend_prices()
        global_q = self._global_quantiles(eng, prices)
        real = eng._local_stats
        empty = {"n_eff": 0.0, "weights": [], "values": [], "distances": [],
                 "mean": 99.0, "median": 99.0, "p_up": 1.0}
        eng._local_stats = lambda *a, **k: dict(empty)
        try:
            forecast = eng.forecast_horizon(prices, "1M", 21)
        finally:
            eng._local_stats = real
        # 邻域不可用时 shrink=0，中位数必须回到纯历史分布而不是 99。
        self.assertAlmostEqual(forecast.quantiles["p50"], round(global_q["p50"], 4), places=4)
        self.assertAlmostEqual(forecast.quantiles["p25"], round(global_q["p25"], 4), places=3)

    def test_blended_quantiles_stay_ordered(self):
        eng = self._engine()
        prices = _trend_prices(n=240, vol=0.03)
        for label, days in eng.horizons:
            q = eng.forecast_horizon(prices, label, days).quantiles
            seq = [q["p05"], q["p25"], q["p50"], q["p75"], q["p95"]]
            self.assertEqual(seq, sorted(seq), f"{label} 分位数出现交叉：{seq}")

    def test_local_stats_keys_are_quantile_prefixed(self):
        eng = self._engine()
        prices = _trend_prices()
        vals = list(prices)
        feats, targets, _times = eng._samples(vals, 21)
        current = eng._features(vals, len(vals) - 1)
        local = eng._local_stats(feats, targets, current)
        for key in ("q05", "q25", "q50", "q75", "q95"):
            self.assertIn(key, local)
            self.assertIsInstance(local[key], float)
        self.assertLessEqual(local["q05"], local["q95"])


class TestProbabilityIsDistributionBased(unittest.TestCase):
    """_classify_signal 必须来自分布假设，而不是把收益率当概率。"""

    def _classify(self):
        from stock_researcher.prediction_v1100 import _classify_signal
        return _classify_signal

    def test_probability_tracks_mu_over_sigma(self):
        classify = self._classify()
        # 同样的 +2% 预期收益，σ 越大方向把握越低——旧公式对 σ 完全无感。
        _, tight = classify(2.0, 1.0)
        _, loose = classify(2.0, 12.0)
        self.assertGreater(tight, loose)
        direction, _ = classify(2.0, 1.0)
        self.assertEqual(direction, "bullish")

    def test_probability_capped_and_neutral_is_coin_flip(self):
        classify = self._classify()
        from stock_researcher.prediction_v1100 import PROB_CAP
        direction, prob = classify(50.0, 0.5)
        self.assertEqual(direction, "bullish")
        self.assertLessEqual(prob, PROB_CAP)
        self.assertGreaterEqual(prob, 0.5)
        neutral_dir, neutral_prob = classify(0.0, 5.0)
        self.assertEqual(neutral_dir, "neutral")
        self.assertAlmostEqual(neutral_prob, 0.5, places=6)

    def test_zero_sigma_falls_back_instead_of_capping_out(self):
        classify = self._classify()
        direction, prob = classify(1.5, 0.0)
        self.assertEqual(direction, "bullish")
        self.assertLess(prob, classify(1.5, 1.0)[1] + 1e-9)

    def test_probability_is_not_the_old_return_percentage_offset(self):
        classify = self._classify()
        # 旧写法：probability = 0.55 + 预期收益/100，与波动率无关。
        for er, sigma in ((3.0, 3.0), (6.0, 2.0), (-4.0, 5.0)):
            direction, prob = classify(er, sigma)
            fabricated = round(min(0.85, 0.55 + abs(er) / 100), 3)
            self.assertNotAlmostEqual(prob, fabricated, delta=0.02,
                                      msg=f"μ={er}, σ={sigma} 仍复现旧的拍脑袋概率")
            self.assertGreaterEqual(prob, 0.5)
            self.assertLessEqual(prob, 0.85)

    def test_range_width_is_a_real_70_percent_interval(self):
        from stock_researcher.prediction_v1100 import predict_horizon, Z_70
        prices = [100 + i * 0.5 + (i % 5) * 1.3 for i in range(120)]
        pred = predict_horizon(prices, horizon="1M", vol_20d=30.0)
        expected_sigma = 30.0 * math.sqrt(21 / 252.0)
        self.assertAlmostEqual(pred.range_high, round(expected_sigma * Z_70, 2), places=2)
        # Φ 下 ±0.7σ 只有约 51% 覆盖，修复后必须逼近 70%。
        covered = 2 * (0.5 * (1 + math.erf(Z_70 / math.sqrt(2)))) - 1
        self.assertGreater(covered, 0.68)
        self.assertLess(covered, 0.72)

    def test_disclaimer_has_no_unfilled_placeholder(self):
        from stock_researcher.prediction_v1100 import MultiHorizonResult
        text = MultiHorizonResult(code="X").disclaimer
        self.assertNotIn("X%", text)
        self.assertIn("预测评分", text)


class TestCalibrationShrinkage(unittest.TestCase):
    """校准权重必须随样本量增长，而不是固定压 70%。"""

    def _calibrate(self):
        from stock_researcher.prediction_v1100 import calibrate_probability
        return calibrate_probability

    def test_three_samples_barely_move_the_probability(self):
        calibrate = self._calibrate()
        few = calibrate(0.7, history=[(0.7, False)] * 3)
        self.assertEqual(few.n_samples, 3)
        self.assertGreater(few.calibrated_probability, 0.6)

    def test_many_samples_dominate(self):
        calibrate = self._calibrate()
        many = calibrate(0.7, history=[(0.7, False)] * 60)
        self.assertEqual(many.n_samples, 60)
        self.assertLess(many.calibrated_probability, 0.35)
        self.assertLess(many.calibrated_probability,
                        self._calibrate()(0.7, history=[(0.7, False)] * 3)
                        .calibrated_probability)

    def test_apply_calibration_is_noop_without_history(self):
        from stock_researcher.prediction_v1100 import (
            HorizonPrediction, _apply_calibration)
        preds = {"1M": HorizonPrediction(horizon="1M", probability=0.72)}
        self.assertEqual(_apply_calibration(preds, history=[]), 0)
        self.assertEqual(preds["1M"].probability, 0.72)
        self.assertIsNone(preds["1M"].raw_probability)

    def test_apply_calibration_keeps_raw_and_marks_method(self):
        from stock_researcher.prediction_v1100 import (
            HorizonPrediction, _apply_calibration)
        preds = {
            "1M": HorizonPrediction(horizon="1M", probability=0.72),
            "3M": HorizonPrediction(horizon="3M", probability=0.72,
                                    quality="unavailable"),
        }
        history = [(0.72, False)] * 40
        changed = _apply_calibration(preds, history=history)
        self.assertEqual(changed, 1)  # unavailable 的那条不参与
        self.assertEqual(preds["1M"].raw_probability, 0.72)
        self.assertLess(preds["1M"].probability, 0.72)
        self.assertEqual(preds["1M"].method, "rule_based_calibrated")
        self.assertTrue(any("校准" in d for d in preds["1M"].drivers))

    def test_multi_horizon_default_stays_uncalibrated(self):
        from stock_researcher.prediction_v1100 import predict_multi_horizon
        prices = [100 + i * 0.6 + (i % 4) for i in range(120)]
        result = predict_multi_horizon("600519", prices=prices)
        for pred in result.horizons.values():
            self.assertIsNone(pred.raw_probability)
            self.assertNotEqual(pred.method, "rule_based_calibrated")

    def test_load_calibration_history_returns_list_offline(self):
        from stock_researcher.prediction_v1100 import load_calibration_history
        pairs = load_calibration_history()
        self.assertIsInstance(pairs, list)
        for pair in pairs:
            self.assertEqual(len(pair), 2)
            self.assertTrue(0.0 <= pair[0] <= 1.0)
            self.assertIsInstance(pair[1], bool)


class TestFuturesExpiryRules(unittest.TestCase):
    """到期日按交易所规则，不再一刀切 15 号。"""

    def test_index_futures_expire_on_third_friday(self):
        from stock_researcher.research_data import _contract_expiry
        for month in (1, 2, 3, 7, 12):
            d = _contract_expiry(2026, month, "IF26%02d" % month)
            self.assertEqual(d.weekday(), 4, f"{month} 月股指交割应为周五：{d}")
            self.assertTrue(15 <= d.day <= 21, f"第三个周五应落在 15-21 日：{d}")
            self.assertEqual((d.year, d.month), (2026, month))

    def test_bond_futures_expire_on_second_friday(self):
        from stock_researcher.research_data import _contract_expiry
        d = _contract_expiry(2026, 3, "T2603")
        self.assertEqual(d.weekday(), 4)
        self.assertTrue(8 <= d.day <= 14, f"第二个周五应落在 8-14 日：{d}")

    def test_commodity_futures_still_use_15th(self):
        from stock_researcher.research_data import _contract_expiry
        self.assertEqual(_contract_expiry(2026, 5, "RB2605"), date(2026, 5, 15))

    def test_impossible_expiry_returns_none_not_fake_date(self):
        from stock_researcher.research_data import _contract_expiry
        self.assertIsNone(_contract_expiry(1800, 13, "RB0101"))
        self.assertIsNone(_contract_expiry(2026, 0, "RB2600"))

    def test_days_to_expiry_differs_by_exchange(self):
        from stock_researcher.research_data import FuturesDataClient
        # 同月同代码前缀不同，股指与商品的剩余天数不应该永远相等。
        dif = (FuturesDataClient.days_to_expiry("IF2703")
               - FuturesDataClient.days_to_expiry("RB2703"))
        self.assertIsInstance(dif, int)
        self.assertNotEqual(dif, 0)

    def test_days_to_expiry_none_without_month_code(self):
        from stock_researcher.research_data import FuturesDataClient
        self.assertIsNone(FuturesDataClient.days_to_expiry("AU0"))


class TestMainContractByOpenInterest(unittest.TestCase):
    """主力合约由持仓量认定，命名后缀只作兜底。"""

    def _contract(self, code, oi=None, vol=None):
        from stock_researcher.research_contracts import FuturesContract
        return FuturesContract(contract=code, product=code[:2], exchange="SHFE",
                               price=100.0, open_interest=oi, volume=vol,
                               source="unit", quality="actual")

    def test_highest_open_interest_wins(self):
        from stock_researcher.research_data import FuturesDataClient
        items = [self._contract("RB2601", oi=1000),
                 self._contract("RB2605", oi=980000),
                 self._contract("RB2610", oi=45000)]
        basis = FuturesDataClient.mark_main_contract(items)
        self.assertEqual(basis, "open_interest")
        self.assertEqual([c.is_main for c in items], [False, True, False])

    def test_volume_used_when_open_interest_missing(self):
        from stock_researcher.research_data import FuturesDataClient
        items = [self._contract("RB2601", vol=10),
                 self._contract("RB2605", vol=900)]
        self.assertEqual(FuturesDataClient.mark_main_contract(items), "volume")
        self.assertEqual([c.is_main for c in items], [False, True])

    def test_no_oi_data_leaves_flags_untouched(self):
        from stock_researcher.research_data import FuturesDataClient
        items = [self._contract("RB2601"), self._contract("RB2605")]
        self.assertIsNone(FuturesDataClient.mark_main_contract(items))
        self.assertEqual([c.is_main for c in items], [False, False])

    def test_single_contract_is_not_remarked(self):
        from stock_researcher.research_data import FuturesDataClient
        item = self._contract("RB2601", oi=5)
        self.assertIsNone(FuturesDataClient.mark_main_contract([item]))
        self.assertFalse(item.is_main)

    def test_curve_warns_when_main_is_unconfirmed(self):
        from stock_researcher import research_data
        items = [self._contract("RB2601"), self._contract("RB2605")]
        original = research_data.FuturesDataClient.quote
        research_data.FuturesDataClient.quote = staticmethod(
            lambda contract: items.pop(0) if items else None)
        try:
            curve = research_data.FuturesDataClient.curve(["RB2601", "RB2605"])
        finally:
            research_data.FuturesDataClient.quote = original
        self.assertEqual(curve.quality, "actual")
        self.assertTrue(any("主力标识" in w for w in curve.warnings), curve.warnings)

    def test_curve_marks_main_when_oi_present(self):
        from stock_researcher import research_data
        items = [self._contract("RB2601", oi=100), self._contract("RB2605", oi=99999)]
        original = research_data.FuturesDataClient.quote
        research_data.FuturesDataClient.quote = staticmethod(
            lambda contract: items.pop(0) if items else None)
        try:
            curve = research_data.FuturesDataClient.curve(["RB2601", "RB2605"])
        finally:
            research_data.FuturesDataClient.quote = original
        self.assertEqual([c.is_main for c in curve.contracts], [False, True])
        self.assertEqual(curve.warnings, [])


class TestResearchBriefFuturesPlumbing(unittest.TestCase):
    """research_brief 必须把合约列表与现货价交给研究中枢。"""

    def _block(self, marker: str) -> str:
        from pathlib import Path
        root = Path(__file__).resolve().parents[1]
        source = (root / "mcp_server.py").read_text(encoding="utf-8")
        return source.split("async def " + marker, 1)[1].split("@server.tool()", 1)[0]

    def test_tool_forwards_contracts_and_spot(self):
        block = self._block("research_brief")
        self.assertIn("futures_contracts: str = \"\"", block)
        self.assertIn("futures_contracts=contracts or None", block)
        self.assertIn("spot_price=spot", block)

    def test_predict_tool_exposes_calibrate(self):
        block = self._block("predict_multi_horizon")
        self.assertIn("calibrate: bool = False", block)
        self.assertIn("calibrate=bool(calibrate)", block)


class TestEvidenceChainHonesty(unittest.TestCase):
    """概率与区间的口径描述不能自相矛盾。"""

    def test_forecast_reports_effective_sample_size(self):
        from stock_researcher.research_analysis import EmpiricalForecastEngine
        forecast = EmpiricalForecastEngine().forecast_horizon(
            _trend_prices(200), "1M", 21)
        self.assertGreater(forecast.effective_sample_size, 0.0)
        self.assertEqual(forecast.method, "empirical_knn_shrunk")
        self.assertIn(forecast.quality, ("validated", "derived", "estimated"))

    def test_abstain_when_history_missing(self):
        from stock_researcher.research_analysis import EmpiricalForecastEngine
        forecast = EmpiricalForecastEngine().forecast_horizon([100.0, 101.0], "1M", 21)
        self.assertTrue(forecast.abstain)
        self.assertEqual(forecast.quality, "insufficient")
        self.assertTrue(forecast.warnings)
        self.assertTrue(all(isinstance(w, str) for w in forecast.warnings))


if __name__ == "__main__":
    unittest.main()
