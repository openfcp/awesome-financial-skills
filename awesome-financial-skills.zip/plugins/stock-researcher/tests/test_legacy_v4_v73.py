# -*- coding: utf-8 -*-
"""合并测试套件（离线）：由多个旧测试文件按原顺序拼接，内容未删减。"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
SKILL_DIR = ROOT

# ==================================================================
# 来自 tests/test_v4_modules.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v4.0.0 新增模块测试"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))


def test_user_profile_allocation():
    """风险偏好→目标配置映射"""
    from stock_researcher.advisor_user_profile import UserProfile, RISK_ALLOCATION
    p = UserProfile(risk_preference="保守")
    t = p.target_allocation()
    assert t["bond"] == 60, f"保守债券应为60%, 实际{t['bond']}"
    assert t["stock"] == 10

    p2 = UserProfile(risk_preference="激进")
    t2 = p2.target_allocation()
    assert t2["stock"] == 75

    # 无效偏好回退到平衡
    p3 = UserProfile(risk_preference="invalid")
    t3 = p3.target_allocation()
    assert t3 == RISK_ALLOCATION["平衡"]
    print("  ✅ test_user_profile_allocation")


def test_weight_optimizer_math():
    """指数加权权重建议的数学正确性"""
    from stock_researcher.evolution_evolution_runner import WeightOptimizer
    import math

    report = {
        "hit_rate_pct": 65.0,
        "by_model": {"model_A": 70.0, "model_B": 60.0, "model_C": 50.0},
        "by_horizon": {"1d": 68.0, "5d": 62.0, "1Q": 55.0},
    }
    prop = WeightOptimizer.propose_weights(report)
    assert prop is not None
    assert "model_weights" in prop
    mw = prop["model_weights"]
    # 命中率最高的应有最大权重
    assert mw["model_A"] > mw["model_B"] > mw["model_C"], f"权重顺序不对: {mw}"

    # 权重应归一化到和为1
    total = sum(mw.values())
    assert abs(total - 1.0) < 0.01, f"权重未归一化: sum={total}"

    # 缺失数据无建议
    report_empty = {"hit_rate_pct": 0, "by_model": {}, "by_horizon": {}}
    prop2 = WeightOptimizer.propose_weights(report_empty)
    assert prop2 is None
    print("  ✅ test_weight_optimizer_math")


def test_prediction_tracker_hit_logic():
    """命中判定逻辑"""
    from stock_researcher.evolution_prediction_tracker import PredictionRecord

    # 看多 + 实际上涨 = 命中
    r1 = PredictionRecord("", "stock", "600519", "5d", "mh", "看多", 2.0, 0.8, "")
    r1.actual_pct = 3.0
    # 模拟 resolve 的判定
    want_up = r1.predicted_direction in ("看多", "分歧偏多")
    assert want_up and r1.actual_pct > 0

    # 看空 + 实际下跌 = 命中
    r2 = PredictionRecord("", "stock", "000001", "5d", "mh", "看空", -1.5, 0.7, "")
    r2.actual_pct = -2.0
    want_down = r2.predicted_direction in ("看空", "分歧偏空")
    assert want_down and r2.actual_pct < 0

    # 震荡 + 微量变化 = 命中
    r3 = PredictionRecord("", "stock", "000002", "1d", "mh", "震荡", 0.1, 0.5, "")
    r3.actual_pct = 0.2
    assert abs(r3.actual_pct) < 0.5 and abs(r3.predicted_pct) < 1
    print("  ✅ test_prediction_tracker_hit_logic")


def test_fusion_to_evolution_format():
    """evolution_runner._to_fusion_format 格式转换"""
    from stock_researcher.evolution_evolution_runner import EvolutionRunner
    proposal = {
        "model_weights": {"broker": 0.40, "technical": 0.20, "sentiment": 0.10},
        "baseline_hit_rate": 60.0,
    }
    result = EvolutionRunner._to_fusion_format(proposal)
    assert "1d" in result
    assert "1Q" in result
    # 每个周期的权重和应为 1.0
    for horizon, dim_weights in result.items():
        total = sum(dim_weights.values())
        assert abs(total - 1.0) < 0.02, f"{horizon} weights sum={total}"
    # broker 命中率高应有放大
    print("  ✅ test_fusion_to_evolution_format")

# ==================================================================
# 来自 tests/test_v72_bugfix.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.2 BUG 修复 + 数据质量回归测试

策略：直接 import 真实子模块（避免污染 sys.modules），用最小 stub 隔离。
覆盖 6 个修复点：
  1. AssetForecaster._get_technical_score 签名错误（修后能拿到真实 tech_score）
  2. _build_stock_narrative 字段名错误（composite_score → tech_score）
  3. StockResearcher.analyze_stock 的 analysis_start 起始日期逻辑（不再误用 strptime）
  4. StockResearcher.generate_report 参数完整转发 (start_date/end_date/strict)
  5. stock_researcher.__version__ = "7.2.0"
  6. data_quality 模块四级标记
"""
import sys
from pathlib import Path

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))

import unittest
from unittest.mock import patch, MagicMock
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any, Dict


# ============================================================
# 测试 1+2：AssetForecaster._get_technical_score / _build_stock_narrative
# （不需要 import 主包，直接 import asset_forecaster）
# ============================================================
class TestV72AssetForecasterTechScore(unittest.TestCase):
    """v7.2 BUG 修复：_get_technical_score 签名错误 + narrative 字段名"""

    def setUp(self):
        # 用 MagicMock 隔离 _get_technical_score 内部的依赖
        from stock_researcher.analysis_asset_forecaster import AssetForecaster
        self.AssetForecaster = AssetForecaster

    def test_technical_score_uses_correct_signature(self):
        """修后 _get_technical_score 调用 ta.analyze(code, prices)，能拿到真实 tech_score。"""
        from stock_researcher.analysis_asset_forecaster import AssetForecaster
        af = AssetForecaster()

        # Mock MarketData.fetch_history 返回模拟收盘价
        # Mock TechnicalAnalyzer.analyze 返回的实例 tech_score=42
        fake_tech_instance = SimpleNamespace(tech_score=42.0, tech_signal="买入")

        with patch("stock_researcher.data_market.MarketData") as MockMarket, \
             patch("stock_researcher.core_technical.TechnicalAnalyzer") as MockTA:
            MockMarket.return_value.fetch_history.return_value = {
                "closes": [100 + i * 0.05 for i in range(250)],
            }
            MockTA.return_value.analyze.return_value = fake_tech_instance

            score, factors = af._get_technical_score("600519", "cn")

        self.assertEqual(score, 42.0, "应返回 Fake 技术分 42.0")
        self.assertEqual(factors.get("tech_score"), 42.0)
        self.assertEqual(factors.get("tech_signal"), "买入")

    def test_technical_score_falls_back_when_data_short(self):
        """修复后：收盘价 < 30 天时，返回 0 + 原因（不再静默报错）。"""
        from stock_researcher.analysis_asset_forecaster import AssetForecaster
        af = AssetForecaster()
        with patch("stock_researcher.data_market.MarketData") as MockMarket:
            MockMarket.return_value.fetch_history.return_value = {"closes": [100] * 10}
            score, factors = af._get_technical_score("600519", "cn")
        self.assertEqual(score, 0.0)
        self.assertIn("数据不足", factors.get("reason", ""))

    def test_stock_narrative_no_longer_shows_zero_tech(self):
        """修复后 narrative 显示真实技术分 + 信号，不再永远是 0。"""
        af = self.AssetForecaster()
        fd = {"total_score": 35, "missing_sources": []}
        tech_factors = {"tech_score": 42.0, "tech_signal": "买入"}
        narrative = af._build_stock_narrative("600519", fd, tech_factors)
        self.assertIn("42", narrative, "narrative 应包含技术分 42")
        self.assertIn("买入", narrative, "narrative 应包含技术信号 买入")

    def test_stock_narrative_handles_missing_tech_fields(self):
        """_build_stock_narrative 容错：缺字段时不崩。"""
        af = self.AssetForecaster()
        fd = {"total_score": 0, "missing_sources": ["policy"]}
        narrative = af._build_stock_narrative("600519", fd, {})
        self.assertIn("0", narrative)
        self.assertIn("缺失维度：policy", narrative)


# ============================================================
# 测试 5：版本号
# ============================================================
class TestV72Version(unittest.TestCase):
    def test_version_is_current(self):
        # 直接读 __init__.py 内容，找到 __version__ 行
        init_path = ROOT / "stock_researcher" / "__init__.py"
        content = init_path.read_text(encoding="utf-8")
        # 找到 version 字符串
        import re
        m = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
        self.assertIsNotNone(m, "必须存在 __version__ 定义")
        from stock_researcher.constants import VERSION
        self.assertEqual(m.group(1), VERSION)

    def test_init_header_mentions_v72(self):
        init_path = ROOT / "stock_researcher" / "__init__.py"
        content = init_path.read_text(encoding="utf-8")
        self.assertIn("v7.4", content.lower() or content, "开头注释应提到 v7.4")
        self.assertIn("数据质量", content, "应提到 v7.2 数据质量")


# ============================================================
# 测试 6：data_quality 模块
# ============================================================
class TestV72DataQuality(unittest.TestCase):
    """数据质量四级标记模块"""

    def setUp(self):
        # 直接 import data_quality，绕开 stock_researcher 主包
        from stock_researcher import data_data_quality as dq
        self.dq = dq

    def test_dataclass_constants(self):
        self.assertEqual(self.dq.DataQuality.ACTUAL, "actual")
        self.assertEqual(self.dq.DataQuality.DERIVED, "derived")
        self.assertEqual(self.dq.DataQuality.ESTIMATED, "estimated")
        self.assertEqual(self.dq.DataQuality.UNAVAILABLE, "unavailable")

    def test_mark_field_structure(self):
        r = self.dq.mark_field(15.2, "actual", "腾讯财经", "实时")
        self.assertEqual(r["value"], 15.2)
        self.assertEqual(r["quality"], "actual")
        self.assertEqual(r["source"], "腾讯财经")
        self.assertEqual(r["note"], "实时")

    def test_is_estimated_unavailable(self):
        e = self.dq.mark_field(50, "estimated", "经验映射")
        u = self.dq.mark_field(0, "unavailable", "", "API 不返回")
        self.assertTrue(self.dq.is_estimated(e))
        self.assertFalse(self.dq.is_estimated(u))
        self.assertTrue(self.dq.is_unavailable(u))
        self.assertFalse(self.dq.is_unavailable(e))

    def test_unwrap_returns_value(self):
        r = self.dq.mark_field(7.5, "actual")
        self.assertEqual(self.dq.unwrap(r), 7.5)
        self.assertEqual(self.dq.unwrap(42), 42)
        self.assertEqual(self.dq.unwrap(None, default=0), 0)

    def test_build_quality_report(self):
        fields = {
            "pe": self.dq.mark_field(15, "actual"),
            "pb": self.dq.mark_field(3.2, "actual"),
            "cost": self.dq.mark_field(100, "derived"),
            "pctl": self.dq.mark_field(35, "estimated"),
            "exp": self.dq.mark_field(0, "unavailable"),
        }
        report = self.dq.build_quality_report(fields)
        self.assertEqual(report["actual_count"], 2)
        self.assertEqual(report["derived_count"], 1)
        self.assertEqual(report["estimated_count"], 1)
        self.assertEqual(report["unavailable_count"], 1)
        self.assertEqual(report["estimated_fields"], ["pctl"])
        self.assertEqual(report["unavailable_fields"], ["exp"])
        self.assertIn(report["overall_quality"], ("🟢 高", "🟡 中", "🔴 低"))

    def test_financial_statements_marks_derived_fields(self):
        """数据层验证：financial_statements.fetch_income_statement 应在派生字段打 _derived 标记。"""
        # 由于 fetch_income_statement 需要联网，我们直接检查代码中存在该标记逻辑
        from pathlib import Path
        f = (ROOT / "stock_researcher" / "data_financial_statements.py").read_text(
            encoding="utf-8")
        self.assertIn("_data_quality", f)
        self.assertIn("OPERATE_COST_derived", f)
        self.assertIn("OPERATE_PROFIT_derived", f)


# ============================================================
# 测试 3+4：analyzer.analyze_stock / generate_report
# （读取源码验证修复 + 子进程独立验证 generate_report 转发）
# ============================================================
class TestV72AnalyzerBugfix(unittest.TestCase):
    """v7.2 BUG 修复：源码静态检查 + 独立子进程跑 generate_report 验证参数转发"""

    def test_analyze_stock_no_datetime_strptime_bug(self):
        """修复前源码存在 `datetime.now().strptime(period, ...)` 错调用。
        修复后源码不应再出现这种反向解析。"""
        src = (ROOT / "stock_researcher" / "core_analyzer.py").read_text(
            encoding="utf-8")
        self.assertNotIn("datetime.now().strptime(period", src,
                          "修复：不能再用 datetime.now().strptime 反向解析 period")

    def test_analyzer_imports_timedelta(self):
        """修复后源码必须 import timedelta。"""
        src = (ROOT / "stock_researcher" / "core_analyzer.py").read_text(
            encoding="utf-8")
        self.assertIn("timedelta", src, "analyzer.py 需要 timedelta")

    def test_generate_report_signature_has_start_end_strict(self):
        """修复后 generate_report 签名必须包含 start_date/end_date/strict。"""
        import ast
        src = (ROOT / "stock_researcher" / "core_analyzer.py").read_text(
            encoding="utf-8")
        tree = ast.parse(src)
        # 找到 StockResearcher 类下的 generate_report 函数
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == "StockResearcher":
                for fn in node.body:
                    if isinstance(fn, ast.FunctionDef) and fn.name == "generate_report":
                        args = [a.arg for a in fn.args.args]
                        self.assertIn("start_date", args,
                                      "generate_report 签名缺 start_date")
                        self.assertIn("end_date", args,
                                      "generate_report 签名缺 end_date")
                        self.assertIn("strict", args,
                                      "generate_report 签名缺 strict")
                        return
                self.fail("未找到 generate_report 方法")

    def test_generate_report_calls_analyze_stock_with_all_args(self):
        """修复后 generate_report 内必须显式给 analyze_stock 传 start_date/end_date/strict。
        用 AST 检查内部调用，避免被 v71 测试 stub 污染。"""
        import ast
        src = (ROOT / "stock_researcher" / "core_analyzer.py").read_text(
            encoding="utf-8")
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == "StockResearcher":
                for fn in node.body:
                    if isinstance(fn, ast.FunctionDef) and fn.name == "generate_report":
                        for sub in ast.walk(fn):
                            if (isinstance(sub, ast.Call) and
                                isinstance(sub.func, ast.Attribute) and
                                sub.func.attr == "analyze_stock"):
                                # 检查 keyword arguments
                                kwargs = {kw.arg for kw in sub.keywords if kw.arg}
                                self.assertIn("start_date", kwargs,
                                              "修复：analyze_stock 调用必须传 start_date")
                                self.assertIn("end_date", kwargs,
                                              "修复：analyze_stock 调用必须传 end_date")
                                self.assertIn("strict", kwargs,
                                              "修复：analyze_stock 调用必须传 strict")
                                return
                self.fail("未找到 analyze_stock 调用")
        self.fail("未找到 StockResearcher.generate_report")

# ==================================================================
# 来自 tests/test_v73_quality.py
# ==================================================================

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v7.3 数据质量与运行逻辑回归测试

覆盖：
  1. 腾讯行情字段映射：涨跌额/涨跌幅/PE/市值/换手率不再错位
  2. 主力净流入不再被 PE 误读
  3. 港股市场字段按港股映射解析
  4. 基金/ETF 资产类型识别
  5. runtests.py 不再用 os.execvp（Windows stdout OSError）
  6. 版本元数据一致
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True

sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "pkg"))


class _FakeResp:
    def __init__(self, raw: bytes):
        self.raw = raw

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self) -> bytes:
        return self.raw


def _cn_tencent_raw() -> bytes:
    fields = [""] * 60
    fields[1] = "贵州茅台"
    fields[3] = "1350.60"
    fields[4] = "1361.76"
    fields[5] = "1330.03"
    fields[6] = "55128"
    fields[31] = "-11.16"
    fields[32] = "-0.82"
    fields[33] = "1355.72"
    fields[34] = "1325.77"
    fields[37] = "737346"
    fields[38] = "0.44"
    fields[39] = "20.41"
    fields[44] = "16000.00"
    fields[45] = "16883.60"
    return ('v_sh600519="' + "~".join(fields) + '";\n').encode("gbk")


def _hk_tencent_raw() -> bytes:
    fields = [""] * 60
    fields[1] = "腾讯控股"
    fields[3] = "500.00"
    fields[4] = "490.00"
    fields[5] = "495.00"
    fields[6] = "10000"
    fields[31] = "2.00"
    fields[32] = "0.41"
    fields[33] = "505.00"
    fields[34] = "488.00"
    fields[38] = "123456"
    fields[39] = "0.55"
    fields[47] = "45678"
    return ('v_r_hk00700="' + "~".join(fields) + '";\n').encode("gbk")


class TestTencentFieldMapping(unittest.TestCase):
    """腾讯行情字段映射修复回归。"""

    def test_market_data_cn_fields(self):
        from stock_researcher.data_market import MarketData
        md = MarketData()
        with patch("stock_researcher.data_market._retry_request",
                   return_value=_cn_tencent_raw()):
            result = md.fetch_realtime(["600519"])
        row = result["600519"]
        self.assertEqual(row["change"], -11.16)
        self.assertEqual(row["change_pct"], -0.82)
        self.assertEqual(row["pe"], 20.41)
        self.assertEqual(row["amount"], 737346)
        self.assertEqual(row["turnover"], 0.44)
        self.assertEqual(row["mkt_cap"], 16883.60)
        self.assertEqual(row["main_net_flow"], 0.0)
        self.assertEqual(row["source"], "tencent")

    def test_market_data_hk_fields(self):
        from stock_researcher.data_market import MarketData
        md = MarketData()
        with patch("stock_researcher.data_market._retry_request",
                   return_value=_hk_tencent_raw()):
            result = md.fetch_realtime(["hk:00700"])
        row = result["hk:00700"]
        self.assertEqual(row["amount"], 123456)
        self.assertEqual(row["mkt_cap"], 45678)
        self.assertEqual(row["change_pct"], 0.41)

    def test_market_all_stocks_crawler_change_pct(self):
        from stock_researcher import data_market_all_stocks_crawler as mod
        from stock_researcher.data_market_all_stocks_crawler import MarketAllStocksCrawler
        with tempfile.TemporaryDirectory() as d:
            crawler = MarketAllStocksCrawler(data_dir=d)
            with patch.object(mod, "HAS_CRAWL_UTILS", False), \
                 patch("urllib.request.urlopen",
                       return_value=_FakeResp(_cn_tencent_raw())):
                result = crawler.update_realtime_quotes(["600519"])
        self.assertEqual(result["600519"]["change_pct"], -0.82)
        self.assertEqual(result["600519"]["change"], -11.16)

    def test_report_generator_realtime_quote_fields(self):
        from stock_researcher import report_stock_report_generator as mod
        from stock_researcher.report_stock_report_generator import StockResearchReportGenerator
        with tempfile.TemporaryDirectory() as d:
            gen = StockResearchReportGenerator(data_dir=d, output_dir=d)
            with patch.object(mod, "HAS_CRAWL_UTILS", False), \
                 patch("urllib.request.urlopen",
                       return_value=_FakeResp(_cn_tencent_raw())):
                quote = gen._fetch_realtime_quote("600519")
        self.assertEqual(quote["change_pct"], -0.82)
        self.assertEqual(quote["turnover_rate"], 0.44)
        self.assertEqual(quote["market_cap"], 16883.60)
        self.assertEqual(quote["float_capital"], 16000.00)


class TestAssetTypeRecognition(unittest.TestCase):
    """基金/ETF 资产类型识别。"""

    def test_fund_and_etf_prefix(self):
        from stock_researcher.analysis_asset_forecaster import detect_asset_type
        self.assertEqual(detect_asset_type("fund:110022"), "fund")
        self.assertEqual(detect_asset_type("etf:510300"), "fund")

    def test_a_share_fund_codes(self):
        from stock_researcher.analysis_asset_forecaster import detect_asset_type
        self.assertEqual(detect_asset_type("110022"), "fund")
        self.assertEqual(detect_asset_type("510300"), "fund")
        self.assertEqual(detect_asset_type("600519"), "stock")


class TestRuntimeHarnessAndMetadata(unittest.TestCase):
    """运行逻辑与版本元数据一致性。"""

    def test_runtests_uses_pytest_main(self):
        src = (ROOT / "runtests.py").read_text(encoding="utf-8")
        self.assertNotIn("os.execvp", src, "runtests.py 不应再用 os.execvp")
        self.assertIn("pytest.main", src, "runtests.py 应改为同一进程内 pytest.main")

    def test_version_metadata_consistent(self):
        """v7.7 修复：版本号随项目升级同步（当前 7.7）。"""
        settings = json.loads((ROOT / "config" / "settings.json").read_text(encoding="utf-8"))
        meta = json.loads((ROOT / "_meta.json").read_text(encoding="utf-8"))
        # 修复 BUG-007：版本号应统一（v7.7+ 同步到最新）
        self.assertEqual(settings["version"], meta["version"])
        # 版本号格式应为语义化版本
        import re as _re
        self.assertRegex(meta["version"], r"^\d+\.\d+\.\d+$")
