# -*- coding: utf-8 -*-
"""v13.0 幻灯片导出（export_pptx）测试。

重点不是"看起来像 XML"，而是包内交叉引用是否闭合（sldId ↔ r:id ↔ .rels ↔
[Content_Types]），因为这部分出错时单测常一路绿灯、真打开 PowerPoint 才炸。
"""
import io
import os
import posixpath
import random
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher import export_pptx as ep
from stock_researcher.report_ir import (
    Bullets, Callout, CodeBlock, Heading, MetricGrid, Paragraph,
    ReportDocument, Section, Table,
)

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"
CT = "{http://schemas.openxmlformats.org/package/2006/content-types}"

HDR9 = ["周期", "方向", "上涨概率", "震荡概率", "下跌概率", "中位收益",
        "90%区间", "置信度", "质量"]
ALIGN9 = ["left", "center", "right", "right", "right", "right", "center",
          "right", "center"]

REQUIRED_PARTS = [
    "[Content_Types].xml", "_rels/.rels", "docProps/core.xml", "docProps/app.xml",
    "ppt/presentation.xml", "ppt/_rels/presentation.xml.rels",
    "ppt/slideMasters/slideMaster1.xml",
    "ppt/slideMasters/_rels/slideMaster1.xml.rels",
    "ppt/slideLayouts/slideLayout1.xml",
    "ppt/slideLayouts/_rels/slideLayout1.xml.rels",
    "ppt/theme/theme1.xml",
]


def wide_table(n_rows=30, narrow_drop=()):
    rows = [[f"{h}日", "bullish", "58%", "12%", "30%", "+0.8%",
             "-4.2% ~ +5.1%", "61%", "derived"] for h in range(1, n_rows + 1)]
    return Table(header=list(HDR9), rows=rows, align=list(ALIGN9),
                 narrow_drop=list(narrow_drop))


def make_doc():
    return ReportDocument(
        title="贵州茅台 研究简报",
        subtitle="综合方向 bullish｜置信度 62%｜评分 63.5/100",
        meta=[("标的", "600519（stock）"), ("生成时间", "2026-09-25T10:00:00"),
              ("数据截止", "2026-09-25")],
        sections=[
            Section("一、结论摘要", [
                Paragraph("公司基本面稳健，估值处于历史中位附近。", "lead"),
                Heading("核心结论", 3),
                Bullets(["ROE 维持 18% 以上", "渠道库存去化完成"], ordered=False),
            ]),
            Section("二、多周期概率预测", [
                wide_table(6, narrow_drop=[3, 4, 7]),
                Callout("概率来自历史条件样本估计，样本不足时弃权。"),
            ]),
            Section("三、因子与证据", [
                MetricGrid([("完整度", "92%"), ("质量分", "0.71")]),
                CodeBlock("score = 0.4*mom + 0.6*value", "python"),
            ]),
            Section("五、风险与数据质量", [
                Bullets(["杠杆风险", "流动性风险"], ordered=True),
                Callout("新闻源缺失 2 条 🚀", kind="warning"),
            ]),
        ],
        disclaimer="本报告仅供研究参考，不构成投资建议。")


def open_zip(blob):
    return zipfile.ZipFile(io.BytesIO(blob))


def slide_parts(z):
    return sorted([n for n in z.namelist()
                   if n.startswith("ppt/slides/slide") and n.endswith(".xml")],
                  key=lambda s: int(s[len("ppt/slides/slide"):-len(".xml")]))


def slide_texts(z):
    """所有幻灯片里的 <a:t> 文本（含表格单元格）。"""
    out = []
    for name in slide_parts(z):
        out.extend(t.text or "" for t in ET.fromstring(z.read(name)).iter(A + "t"))
    return out


def tables_of(z):
    """[(表头首格, [其余每行首格])]，用于验证分页后行不丢、表头重复。"""
    out = []
    for name in slide_parts(z):
        for tbl in ET.fromstring(z.read(name)).iter(A + "tbl"):
            firsts = []
            for tr in tbl.findall(A + "tr"):
                tcs = tr.findall(A + "tc")
                firsts.append("".join(t.text or "" for t in tcs[0].iter(A + "t"))
                              if tcs else "")
            out.append((firsts[0], firsts[1:]))
    return out


class TestEngineResolution(unittest.TestCase):
    def test_stdlib_always_listed(self):
        self.assertEqual(ep.engines()[0], "stdlib")
        self.assertEqual(ep.resolve_engine("auto"), "stdlib")
        self.assertEqual(ep.resolve_engine("stdlib"), "stdlib")
        self.assertEqual(ep.resolve_engine(None), "stdlib")

    def test_enhanced_engine_only_when_importable(self):
        has = ep._pptx_available()
        self.assertEqual("python-pptx" in ep.engines(), has)
        if has:
            self.assertEqual(ep.resolve_engine("python-pptx"), "python-pptx")
        else:
            with self.assertRaises(ep.ExportError):
                ep.resolve_engine("python-pptx")

    def test_unknown_engine_raises(self):
        with self.assertRaises(ep.ExportError):
            ep.resolve_engine("Keynote")


class TestStdlibPackage(unittest.TestCase):
    def setUp(self):
        self.doc = make_doc()
        self.blob = ep.render(self.doc, engine="stdlib")
        self.z = open_zip(self.blob)

    def test_required_parts_present(self):
        names = set(self.z.namelist())
        for part in REQUIRED_PARTS:
            self.assertIn(part, names)
        self.assertIn("ppt/slides/_rels/slide1.xml.rels", names)

    def test_every_xml_parses(self):
        for name in self.z.namelist():
            if name.endswith(".xml") or name.endswith(".rels"):
                ET.fromstring(self.z.read(name))  # 解析失败即测试失败

    def test_content_types_declares_every_part(self):
        root = ET.fromstring(self.z.read("[Content_Types].xml"))
        defaults = {d.get("Extension") for d in root.findall(CT + "Default")}
        overrides = {o.get("PartName") for o in root.findall(CT + "Override")}
        for name in self.z.namelist():
            ext = name.rsplit(".", 1)[-1]
            self.assertTrue(ext in defaults or "/" + name in overrides,
                            f"{name} 未在 [Content_Types].xml 声明")

    def test_slide_count_is_sections_plus_title_and_disclaimer(self):
        plan = ep._plan(self.doc)
        slides = slide_parts(self.z)
        self.assertEqual(len(slides), len(plan))
        # 允许分页，故 ≥ 章节数 + 标题页 + 免责页
        self.assertGreaterEqual(len(slides), len(self.doc.sections) + 2)

    def test_section_titles_and_table_cell_in_slides(self):
        texts = "".join(slide_texts(self.z))
        for section in self.doc.sections:
            self.assertIn(section.title, texts)
        self.assertIn("bullish", texts)
        self.assertIn("贵州茅台 研究简报", texts)
        self.assertIn("不构成投资建议", texts)

    def test_narrow_variant_used_on_slides(self):
        texts = "".join(slide_texts(self.z))
        self.assertIn("上涨概率", texts)      # narrow 保留列
        self.assertNotIn("震荡概率", texts)    # narrow_drop=[3,4,7] 丢弃列
        self.assertNotIn("置信度", texts.replace("置信度 62%", ""))

    def test_graphic_frames_use_the_table_namespace_uri(self):
        """uri 写成 …/main/table 时 LibreOffice 照样渲染，但 PowerPoint 与
        python-pptx 会把表格当未知图形丢掉——所以按命名空间精确核对。"""
        frames = []
        for name in slide_parts(self.z):
            frames.extend(ET.fromstring(self.z.read(name)).iter(A + "graphicData"))
        self.assertGreaterEqual(len(frames), 1)
        for gd in frames:
            self.assertEqual(gd.get("uri"), "http://schemas.openxmlformats.org/drawingml/2006/table")
            self.assertIsNotNone(gd.find(A + "tbl"), "graphicData 内缺 a:tbl")
        self.assertEqual(len(tables_of(self.z)), len(frames))

    def test_every_run_carries_east_asian_font(self):
        runs = cells = 0
        for name in slide_parts(self.z):
            xml = self.z.read(name).decode("utf-8")
            runs += xml.count("<a:r>")
            cells += xml.count('<a:ea typeface="微软雅黑"/>')
        self.assertGreater(runs, 0)
        self.assertEqual(runs, cells)

    def test_slide_size_is_16_9(self):
        prs = ET.fromstring(self.z.read("ppt/presentation.xml"))
        sz = prs.find(P + "sldSz")
        self.assertEqual((int(sz.get("cx")), int(sz.get("cy"))),
                         (ep.SLIDE_CX, ep.SLIDE_CY))
        self.assertEqual(ep.SLIDE_CX, 12192000)
        self.assertEqual(ep.SLIDE_CY, 6858000)

    def test_deterministic_bytes_and_fixed_timestamp(self):
        self.assertEqual(self.blob, ep.render(make_doc(), engine="stdlib"))
        for info in open_zip(self.blob).infolist():
            self.assertEqual(info.date_time, ep.ZIP_STAMP)
        self.assertNotIn(b"dcterms:created", self.z.read("docProps/core.xml"))

    def test_no_external_relationship_targets(self):
        for name in [n for n in self.z.namelist() if n.endswith(".rels")]:
            for rel in ET.fromstring(self.z.read(name)):
                self.assertNotEqual(rel.get("TargetMode"), "External")

    def test_render_to_file(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            target = os.path.join(td, ep.DEFAULT_FILENAME)
            written = ep.render_to_file(self.doc, target, engine="stdlib")
            self.assertEqual(written, target)
            with open(target, "rb") as fh:
                self.assertEqual(fh.read(), self.blob)


class TestCrossReferences(unittest.TestCase):
    """sldId/r:id/rel 目标必须互相闭合——这是本任务最可能翻车的地方。"""

    def setUp(self):
        self.z = open_zip(ep.render(make_doc(), engine="stdlib"))
        self.names = set(self.z.namelist())

    def _rels_of(self, part):
        base, tail = posixpath.split(part)          # ("ppt/slides", "slide1.xml")
        return posixpath.join(base, "_rels", tail + ".rels")

    def test_all_relationship_targets_exist(self):
        for rels_name in [n for n in self.names if n.endswith(".rels")]:
            owner = "" if rels_name == "_rels/.rels" else \
                posixpath.dirname(posixpath.dirname(rels_name))
            for rel in ET.fromstring(self.z.read(rels_name)):
                target = rel.get("Target")
                resolved = posixpath.normpath(
                    posixpath.join(owner or ".", target)).lstrip("/")
                self.assertIn(resolved, self.names,
                              f"{rels_name} 的 {rel.get('Id')} 指向不存在的 {resolved}")

    def test_relationship_ids_unique_per_part(self):
        for rels_name in [n for n in self.names if n.endswith(".rels")]:
            ids = [r.get("Id") for r in ET.fromstring(self.z.read(rels_name))]
            self.assertEqual(len(ids), len(set(ids)), f"{rels_name} r:id 重复")

    def test_presentation_ids_resolve(self):
        prs = ET.fromstring(self.z.read("ppt/presentation.xml"))
        rels = {r.get("Id"): r.get("Target") for r in
                ET.fromstring(self.z.read("ppt/_rels/presentation.xml.rels"))}
        master = prs.find(P + "sldMasterIdLst").find(P + "sldMasterId")
        self.assertIn(master.get(R + "id"), rels)
        self.assertEqual(rels[master.get(R + "id")], "slideMasters/slideMaster1.xml")
        sld_ids, rid_used = [], []
        for sld in prs.find(P + "sldIdLst").findall(P + "sldId"):
            rid = sld.get(R + "id")
            self.assertIn(rid, rels, f"sldId 引用了未定义的 {rid}")
            self.assertIn(posixpath.normpath("ppt/" + rels[rid]), self.names)
            sld_ids.append(int(sld.get("id")))
            rid_used.append(rid)
        self.assertEqual(len(sld_ids), len(set(sld_ids)), "sldId 数值重复")
        self.assertEqual(len(rid_used), len(set(rid_used)), "幻灯片 r:id 重复")
        self.assertEqual(len(sld_ids), len(slide_parts(self.z)),
                         "sldIdLst 数量与幻灯片部件数不一致")

    def test_master_layout_slide_chain(self):
        master_rels = {r.get("Id"): r.get("Target") for r in
                       ET.fromstring(self.z.read(
                           "ppt/slideMasters/_rels/slideMaster1.xml.rels"))}
        master = ET.fromstring(self.z.read("ppt/slideMasters/slideMaster1.xml"))
        layout_id = master.find(P + "sldLayoutIdLst").find(P + "sldLayoutId")
        self.assertIn(layout_id.get(R + "id"), master_rels)
        self.assertEqual(posixpath.normpath(
            posixpath.join("ppt/slideMasters", master_rels[layout_id.get(R + "id")])),
            "ppt/slideLayouts/slideLayout1.xml")
        layout_rels = {r.get("Id"): r.get("Target") for r in
                       ET.fromstring(self.z.read(
                           "ppt/slideLayouts/_rels/slideLayout1.xml.rels"))}
        self.assertEqual(posixpath.normpath(posixpath.join(
            "ppt/slideLayouts", layout_rels["rId1"])),
            "ppt/slideMasters/slideMaster1.xml")
        # 每张幻灯片都要挂到版式上
        for name in slide_parts(self.z):
            rels = {r.get("Id"): r.get("Target") for r in
                    ET.fromstring(self.z.read(self._rels_of(name)))}
            self.assertTrue(rels, f"{name} 没有 .rels")
            self.assertEqual(posixpath.normpath(posixpath.join(
                "ppt/slides", rels["rId1"])), "ppt/slideLayouts/slideLayout1.xml")

    def test_root_relationship_points_at_presentation(self):
        rels = {r.get("Type").rsplit("/", 1)[-1]: r.get("Target") for r in
                ET.fromstring(self.z.read("_rels/.rels"))}
        self.assertEqual(rels["officeDocument"], "ppt/presentation.xml")
        self.assertIn("core-properties", rels)
        self.assertIn("extended-properties", rels)


class TestNoContentLoss(unittest.TestCase):
    def test_wide_forecast_table_paginates_without_losing_rows(self):
        rows = [[f"{h}日", "bullish", "58%", "12%", "30%", "+0.8%",
                 "-4.2% ~ +5.1%", "61% 质量描述较长的一格", "derived"]
                for h in range(1, 41)]
        doc = ReportDocument(
            title="宽表分页", subtitle="", meta=[],
            sections=[Section("二、多周期概率预测", [Table(header=list(HDR9),
                                                          rows=rows,
                                                          align=list(ALIGN9))])],
            disclaimer="免责")
        z = open_zip(ep.render(doc, engine="stdlib"))
        tbls = tables_of(z)
        self.assertGreater(len(tbls), 1, "40 行 9 列表应分页")
        self.assertTrue(all(head == "周期" for head, _ in tbls),
                        "续页必须重复表头")
        kept = [cell for _, part in tbls for cell in part]
        self.assertEqual(kept, [r[0] for r in rows], "预测行丢失或顺序错乱")
        # 标题页 + 每个表页一页 + 免责页
        self.assertGreaterEqual(len(slide_parts(z)), 1 + len(tbls) + 1)

    def test_narrow_to_empty_falls_back_to_full_columns(self):
        """narrow_drop 把列裁光时回退全列，而不是把表整张丢掉。"""
        tbl = Table(header=list(HDR9),
                    rows=[["1d", "bearish", "30%", "25%", "45%", "-1.2%",
                          "-6% ~ +2%", "55%", "derived"]],
                    align=list(ALIGN9), narrow_drop=list(range(len(HDR9))))
        z = open_zip(ep.render(ReportDocument(title="回退",
                                             sections=[Section("二、预测", [tbl])],
                                             disclaimer="免责"), engine="stdlib"))
        texts = "".join(slide_texts(z))
        for head in HDR9:
            self.assertIn(head, texts)
        self.assertIn("bearish", texts)
        self.assertEqual(len(tables_of(z)), 1)

    def test_headerless_table_degrades_to_text_rows(self):
        tbl = Table(header=[], rows=[["只有数据行", "甲", "乙"], ["第二行", "丙", "丁"]])
        z = open_zip(ep.render(ReportDocument(title="无表头",
                                             sections=[Section("附", [tbl])],
                                             disclaimer="免责"), engine="stdlib"))
        texts = "".join(slide_texts(z))
        for fragment in ("只有数据行", "第二行", "丙"):
            self.assertIn(fragment, texts)

    def test_long_paragraph_splits_not_truncated(self):
        sentence = "本轮结论依赖样本量有限的历史相似条件，引用前请复核区间宽度。"
        doc = ReportDocument(title="长文本", sections=[
            Section("一、结论摘要", [Paragraph(sentence * 120)])], disclaimer="免责")
        z = open_zip(ep.render(doc, engine="stdlib"))
        joined = "".join(slide_texts(z))
        self.assertGreater(len(slide_parts(z)), 3, "长段落应分页")
        self.assertEqual(joined.count("本轮结论依赖样本量有限"), 120)

    def test_empty_report_still_valid_package(self):
        blob = ep.render(ReportDocument(title="空报告"), engine="stdlib")
        z = open_zip(blob)
        for part in REQUIRED_PARTS:
            self.assertIn(part, z.namelist())
        self.assertEqual(len(slide_parts(z)), 2)   # 标题页 + 免责页
        for name in z.namelist():
            ET.fromstring(z.read(name))


class TestSafety(unittest.TestCase):
    def test_markup_and_emoji_are_neutralised(self):
        doc = ReportDocument(
            title="A & B <C> 🚀 特殊符号",
            subtitle="1 < 2 & 3 > 2",
            meta=[("标的", "600519<>")],
            sections=[Section("风险 & 提示", [
                Bullets(["<script>alert(1)</script> 🐛"]),
                Table(header=["项 & 值", "说明"],
                      rows=[["<b>", "带 & 的单元格 🚀 "]], align=["left", "left"]),
            ])],
            disclaimer="&amp; 原样 & 转义")
        blob = ep.render(doc, engine="stdlib")
        z = open_zip(blob)
        texts = "".join(slide_texts(z))
        self.assertIn("A & B <C>", texts)           # 解码后回到原文
        self.assertIn("带 & 的单元格", texts)
        self.assertIn("<b>", texts)
        for ch in texts:
            self.assertLess(ord(ch), 0x10000, "非 BMP 码位未剥离")
        for name in z.namelist():
            if name.endswith(".xml"):
                ET.fromstring(z.read(name))         # 转义不彻底会在此炸
        self.assertIn(b"&amp;", z.read("ppt/slides/slide1.xml"))

    def test_control_chars_stripped(self):
        doc = ReportDocument(title="控制符 \x00\x07 测试",
                             sections=[Section("A \x0b B", [Paragraph("x\x1f y")])],
                             disclaimer="d")
        z = open_zip(ep.render(doc, engine="stdlib"))
        for ch in "".join(slide_texts(z)):
            self.assertGreaterEqual(ord(ch), 0x20)
            self.assertNotEqual(ord(ch), 0x7f)


class TestInputCoercion(unittest.TestCase):
    def test_accepts_dict_via_build_document(self):
        payload = {"symbol": "600519", "name": "测试公司", "asset_type": "stock",
                   "direction": "bullish", "confidence": 0.6, "score": 62.0,
                   "executive_summary": "数据充分。",
                   "forecasts": [{"horizon": "5日", "probability_up": 0.6,
                                  "median_return_pct": 0.8, "sample_size": 120}],
                   "scenarios": [{"name": "基准", "probability": 0.5,
                                  "return_pct": 2.0, "price_range": [10, 12]}],
                   "evidence": [{"evidence_id": "E1", "kind": "quote",
                                 "source": "unit", "value": "100.5"}],
                   "risks": ["回撤风险"], "disclaimer": "仅供研究。",
                   "data_quality": {"status": "actual", "completeness": 0.9}}
        blob = ep.render(payload, engine="stdlib")
        z = open_zip(blob)
        doc = ep._as_document(payload)
        self.assertEqual(len(slide_parts(z)), len(ep._plan(doc)))
        self.assertGreaterEqual(len(slide_parts(z)), len(doc.sections) + 2)
        self.assertIn("测试公司 研究简报", "".join(slide_texts(z)))

    def test_accepts_object_with_to_dict(self):
        class Fake:
            def to_dict(self):
                return {"symbol": "RB2610", "name": "螺纹钢", "asset_type": "futures",
                        "disclaimer": "杠杆品种。"}
        z = open_zip(ep.render(Fake(), engine="stdlib"))
        self.assertIn("螺纹钢 研究简报", "".join(slide_texts(z)))

    def test_garbage_input_raises_export_error(self):
        with self.assertRaises(ep.ExportError):
            ep.render(3.14, engine="stdlib")


@unittest.skipUnless(ep._pptx_available(), "python-pptx 未安装")
class TestPptxEnhancedEngine(unittest.TestCase):
    def test_engine_matches_plan_page_count(self):
        from pptx import Presentation
        doc = make_doc()
        plan = ep._plan(doc)
        blob = ep.render(doc, engine="python-pptx")
        prs = Presentation(io.BytesIO(blob))
        self.assertEqual(len(prs.slides._sldIdLst), len(plan))

    def test_stdlib_output_is_readable_by_python_pptx(self):
        from pptx import Presentation
        blob = ep.render(make_doc(), engine="stdlib")
        prs = Presentation(io.BytesIO(blob))
        self.assertEqual((prs.slide_width, prs.slide_height),
                         (ep.SLIDE_CX, ep.SLIDE_CY))
        texts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if shape.has_text_frame:
                    texts.append(shape.text_frame.text)
                if getattr(shape, "has_table", False):
                    for row in shape.table.rows:
                        for cell in row.cells:
                            texts.append(cell.text)
        joined = "\n".join(texts)
        self.assertIn("贵州茅台 研究简报", joined)
        self.assertIn("二、多周期概率预测", joined)
        self.assertIn("bullish", joined)

    def test_stdlib_tables_are_real_table_objects(self):
        """表格必须能被 python-pptx 当表读（shape.has_table + table.rows），
        否则 PowerPoint 里只剩一个空图形框架。"""
        from pptx import Presentation
        prs = Presentation(io.BytesIO(ep.render(make_doc(), engine="stdlib")))
        frames = [sh for slide in prs.slides for sh in slide.shapes if sh.has_table]
        self.assertEqual(len(frames), len(tables_of(open_zip(ep.render(make_doc(), "stdlib")))))
        self.assertGreaterEqual(len(frames), 1)
        cells = [c.text for sh in frames for row in sh.table.rows for c in row.cells]
        self.assertIn("上涨概率", cells)
        self.assertIn("bullish", cells)

    def test_enhanced_engine_tables_readable_too(self):
        from pptx import Presentation
        prs = Presentation(io.BytesIO(ep.render(make_doc(), engine="python-pptx")))
        cells = [c.text for s in prs.slides for sh in s.shapes if sh.has_table
                 for row in sh.table.rows for c in row.cells]
        self.assertIn("上涨概率", cells)
        self.assertIn("bullish", cells)


class TestRealReportPipeline(unittest.TestCase):
    """用真实研究链路（离线 CSV → ResearchHub）产出的报告驱动渲染。

    fixture 构造与 tests/test_v1200_research_hub.py 一致：随机游走价格写成
    CSV，TemporaryDirectory 落盘，analyze_dataset 出报告。
    """

    @classmethod
    def setUpClass(cls):
        from stock_researcher.research_hub import ResearchHub
        random.seed(21)
        closes, p = [100.0], 100.0
        for _ in range(239):
            p *= 1 + random.gauss(0.0008, 0.011)
            closes.append(round(p, 3))
        lines = ["date,open,high,low,close,volume"]
        for i, c in enumerate(closes):
            lines.append("2026-%02d-%02d,%s,%s,%s,%s,%d" % (
                i // 28 + 1, i % 28 + 1, c, round(c * 1.012, 3),
                round(c * 0.988, 3), c, 900000 + i))
        cls._tmp = tempfile.TemporaryDirectory()
        path = Path(cls._tmp.name) / "prices.csv"
        path.write_text("\n".join(lines), encoding="utf-8")
        cls.report = ResearchHub().analyze_dataset(path, symbol="600519")
        cls.doc = ep._as_document(cls.report)
        cls.blob = ep.render(cls.report, engine="stdlib")
        cls.z = open_zip(cls.blob)

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def test_every_section_title_reaches_a_slide(self):
        texts = "".join(slide_texts(self.z))
        self.assertGreaterEqual(len(self.doc.sections), 5)
        for section in self.doc.sections:
            self.assertIn(section.title, texts)
        self.assertIn(self.doc.title, texts)
        self.assertGreaterEqual(len(slide_parts(self.z)), len(self.doc.sections) + 2)

    def test_forecast_rows_are_not_dropped(self):
        """预测表每一行的周期标签都必须在某页幻灯片里——丢一行就是正确性事故。"""
        tables = [b for s in self.doc.sections for b in s.blocks if isinstance(b, Table)]
        self.assertTrue(tables, "真实报告应至少含一张预测表")
        heads = [t for t in tables if t.header and "周期" in t.header[0]] or tables
        kept = [first for _, rows in tables_of(self.z) for first in rows]
        for row in heads[0].rows:
            self.assertIn(row[0], kept)

    def test_real_report_package_is_well_formed(self):
        for name in self.z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(self.z.read(name))
        for part in REQUIRED_PARTS:
            self.assertIn(part, set(self.z.namelist()))
        self.assertEqual(self.blob, ep.render(self.report, engine="stdlib"))

    def test_disclaimer_and_caveats_close_the_deck(self):
        last = "ppt/slides/slide%d.xml" % len(slide_parts(self.z))
        texts = "".join(t.text or "" for t in
                        ET.fromstring(self.z.read(last)).iter(A + "t"))
        self.assertIn("免责声明", texts)
        self.assertIn("数据截止", texts)


if __name__ == "__main__":
    unittest.main()
