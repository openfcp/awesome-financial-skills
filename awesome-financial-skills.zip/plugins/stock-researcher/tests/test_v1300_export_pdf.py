# -*- coding: utf-8 -*-
"""v13.0 PDF 导出（export_pdf）测试。

两个引擎都要真出文件：stdlib 是自研写入器，校验必须打在字节上（xref 偏移、内容流
是否真在画东西），因为这类错误在"能打开"的 PDF 里也会静默变成空白页；reportlab
是可选增强，本机装了才跑，缺依赖时只允许降级、不允许谎报成功。
"""
import binascii
import os
import re
import sys
import tempfile
import unittest
import zlib
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from stock_researcher import export_pdf as ep
from stock_researcher.report_ir import (
    Bullets, Callout, CodeBlock, Heading, MetricGrid, Paragraph,
    ReportDocument, Section, Table,
)

HDR = ["周期", "方向", "上涨概率", "中位收益", "90%区间", "置信度"]
ROWS = [["20日", "震荡", "38%", "+0.8%", "-4.2% ~ +5.1%", "61%"],
        ["60日", "偏多", "52%", "+2.4%", "-6.0% ~ +11.2%", "47%"]]


def make_doc():
    """覆盖全部 IR 块类型，并塞进 XML 元字符、BMP 外字符和控制字符。"""
    return ReportDocument(
        title="贵州茅台 研究简报",
        subtitle="综合方向 bullish｜置信度 62%｜评分 63.5/100",
        meta=[("标的", "600519（stock）"), ("生成时间", "2026-09-25T10:00:00")],
        sections=[
            Section("一、结论摘要", [
                Paragraph("估值分位 68%，若 PE < 30 且渠道库存 & 批价同时改善则看多。", "lead"),
                Heading("核心结论", 3),
                Bullets(["ROE 维持 18% 以上", "现金流 A 级 \U0001f680"], ordered=False),
            ]),
            Section("二、多周期概率预测", [
                Table(header=list(HDR), rows=[list(r) for r in ROWS],
                      align=["left", "center", "right", "right", "center", "right"]),
                Callout("概率来自历史条件样本的非参数估计。"),
            ]),
            Section("三、因子与证据", [
                MetricGrid([("完整度", "92%"), ("质量分", "0.71")]),
                CodeBlock("score = 0.4*mom + 0.6*value", "python"),
            ]),
            Section("四、风险", [
                Bullets(["杠杆风险\x07", "流动性风险"], ordered=True),
                Callout("新闻源缺失 2 条。", kind="warning"),
            ]),
        ],
        disclaimer="本报告仅供研究参考，不构成投资建议。")


def flat(text: str) -> str:
    """去掉所有空白：换行/断词是版面细节，不该影响内容断言。"""
    return re.sub(r"\s+", "", text)


def streams_of(blob: bytes) -> list:
    out = []
    for raw in re.findall(rb"stream\r?\n(.*?)\r?\nendstream", blob, re.S):
        try:
            out.append(zlib.decompress(raw))
        except zlib.error:
            out.append(raw)
    return out


def drawn_text(blob: bytes) -> str:
    """把内容流里真正画出去的字符串取回来（CID 走 hex，Courier 走 literal）。"""
    pieces: list = []
    for stream in streams_of(blob):
        for hexstr in re.findall(rb"<([0-9A-Fa-f]{4,})>\s*Tj", stream):
            try:
                pieces.append(binascii.unhexlify(hexstr).decode("utf-16-be"))
            except (ValueError, UnicodeDecodeError):
                pass
        for lit in re.findall(rb"\(([^()<>]*)\)\s*Tj", stream):
            pieces.append(lit.decode("cp1252", "replace"))
    return "".join(pieces)


def synthetic_pdf(content: bytes, compress: bool = True) -> bytes:
    """拼一个结构完全合法的最小 PDF，用来让校验器只对单条规则失败。

    直接手写十六进制偏移的坏文件会让 _validate 先在 xref 上报错，测试就证明不了
    内容流那两条规则真的在工作；所以偏移一律现算，要弄坏哪一条就只改那一条。
    """
    packed = zlib.compress(content, 9) if compress else content
    objs = [b"<</Type /Catalog /Pages 2 0 R>>",
            b"<</Type /Pages /Kids [3 0 R] /Count 1>>",
            b"<</Type /Page /Parent 2 0 R /Contents 4 0 R>>",
            b"<</Length %d>>\nstream\n%s\nendstream" % (len(packed), packed)]
    out = bytearray(b"%PDF-1.4\n")
    offsets: list = []
    for i, body in enumerate(objs, start=1):
        offsets.append(len(out))
        out += b"%d 0 obj\n%s\nendobj\n" % (i, body)
    xref_at = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    out += (b"trailer\n<</Size %d /Root 1 0 R>>\nstartxref\n%d\n%%%%EOF\n"
            % (len(objs) + 1, xref_at))
    return bytes(out)


def has_pypdf() -> bool:
    try:
        import pypdf  # noqa: F401
        return True
    except Exception:
        return False


class TestEngineResolution(unittest.TestCase):
    def test_stdlib_is_default_and_listed_first(self):
        self.assertEqual(ep.engines()[0], "stdlib")
        for alias in ("auto", "", None, "std", "base"):
            self.assertEqual(ep.resolve_engine(alias), "stdlib", alias)

    def test_reportlab_only_when_importable(self):
        has = ep._has_reportlab()
        self.assertEqual("reportlab" in ep.engines(), has)
        for alias in ("reportlab", "rl", "lib"):
            if has:
                self.assertEqual(ep.resolve_engine(alias), "reportlab")
            else:
                with self.assertRaises(ep.ExportError, msg=alias):
                    ep.resolve_engine(alias)

    def test_unknown_engine_is_value_error(self):
        with self.assertRaises(ValueError):
            ep.resolve_engine("Keynote")


class TestStructure(unittest.TestCase):
    def setUp(self):
        self.doc = make_doc()
        self.blob = ep.render(self.doc, "stdlib")

    def test_header_and_eof(self):
        self.assertTrue(self.blob.startswith(b"%PDF-1."))
        self.assertIn(b"%%EOF", self.blob[-40:])

    def test_startxref_offset_points_at_xref(self):
        offset = int(self.blob.rsplit(b"startxref", 1)[1].split()[0])
        self.assertEqual(self.blob[offset:offset + 4], b"xref")

    def test_xref_offsets_point_at_matching_object_headers(self):
        """偏移错位是最隐蔽的一类坏 PDF：阅读器不报错，但页面全白。"""
        start = int(self.blob.rsplit(b"startxref", 1)[1].split()[0])
        entries = re.findall(rb"\n(\d{10}) (\d{5}) ([nf]) ", self.blob[start:])
        checked = 0
        for i, (off_raw, _gen, flag) in enumerate(entries):
            if flag != b"n":
                continue
            pos = int(off_raw)
            self.assertEqual(self.blob[pos:].split(None, 3)[:3],
                             [str(i).encode(), b"0", b"obj"],
                             "第 %d 号对象的 xref 偏移指错了位置" % i)
            checked += 1
        self.assertGreater(checked, 4)

    def test_object_headers_are_unique_and_numbered_from_one(self):
        ids = [int(m.group(1)) for m in
               re.finditer(rb"^(\d+) 0 obj$", self.blob, re.M)]
        self.assertEqual(len(ids), len(set(ids)), "同一对象号出现两次")
        self.assertEqual(sorted(ids)[:2], [1, 2])

    def test_cid_font_declared_without_font_file(self):
        text = self.blob.decode("latin-1")
        self.assertIn("/Type0", text)
        self.assertIn("/CIDFontType0", text)
        self.assertIn("/BaseFont /%s" % ep.CID_BASE, text)
        self.assertIn("/Encoding /%s" % ep.CID_ENCODING, text)
        self.assertNotIn(b"FontFile", self.blob)      # 零二进制：不嵌字体文件

    def test_each_page_has_its_own_contents(self):
        pages = re.findall(rb"/Type /Page[^s]", self.blob)
        contents = re.findall(rb"/Contents (\d+) 0 R", self.blob)
        self.assertEqual(len(pages), len(contents))
        self.assertEqual(len(set(contents)), len(contents), "多页共用同一条内容流")

    def test_bytes_are_reproducible(self):
        self.assertEqual(ep.render(self.doc, "stdlib"), self.blob)
        self.assertIn(b"D:20260101", self.blob)       # 固定日期，不写真实时钟

    def test_tm_always_has_six_operands(self):
        for stream in streams_of(self.blob):
            for seg in re.findall(rb"([0-9.\- ]+)Tm", stream):
                self.assertEqual(len(seg.split()), 6, seg)


class TestContent(unittest.TestCase):
    def setUp(self):
        self.text = flat(drawn_text(ep.render(make_doc(), "stdlib")))

    def test_title_section_and_table_cells_drawn(self):
        for needle in ("贵州茅台研究简报", "一、结论摘要", "核心结论",
                       "ROE维持18%以上", "上涨概率", "60日", "+2.4%",
                       "完整度", "免责声明", "不构成投资建议"):
            self.assertIn(needle, self.text, needle)

    def test_xml_metachars_survive_as_text(self):
        self.assertIn("PE<30", self.text)
        self.assertIn("库存&批价", self.text)

    def test_out_of_range_and_control_chars_never_reach_the_stream(self):
        self.assertNotIn("\U0001f680", self.text)     # 🚀 换成了 □
        self.assertNotIn("\x07", self.text)
        self.assertIn("\u25a1", self.text)


class TestInputCoercion(unittest.TestCase):
    def test_research_report_dict_renders(self):
        payload = {"symbol": "600519", "name": "贵州茅台",
                   "executive_summary": "估值处于中位。",
                   "conclusions": ["现金流 A 级"]}
        blob = ep.render(payload, "stdlib")
        ep._validate_stdlib(blob)
        self.assertIn("估值处于中位", flat(drawn_text(blob)))

    def test_unrelated_dict_is_rejected_not_rendered_as_blank_report(self):
        """任意 dict 会被 IR 宽容读成"全空"报告，于是传错对象时得到一份精美空白 PDF。"""
        with self.assertRaises(ep.ExportError):
            ep.render({"nothing": 1}, "stdlib")

    def test_none_is_rejected(self):
        with self.assertRaises(ep.ExportError):
            ep.render(None, "stdlib")

    def test_empty_document_still_makes_a_valid_pdf(self):
        blob = ep.render(ReportDocument(title="空报告"), "stdlib")
        ep._validate_stdlib(blob)
        self.assertIn("空报告", flat(drawn_text(blob)))


class TestValidation(unittest.TestCase):
    def test_good_synthetic_passes_both_layers(self):
        """正向对照：下面两条加严规则不能是"永远报错"。"""
        ep._validate_stdlib(synthetic_pdf(b"1 0 0 1 10 700 Tm <0041> Tj\n"))

    def test_rejects_content_stream_that_draws_nothing(self):
        """结构完全合法、内容流不画东西——阅读器只会显示一张空白页。"""
        with self.assertRaisesRegex(ep.ExportError, "绘制算子"):
            ep._validate_stdlib(synthetic_pdf(b"q Q\n"))

    def test_rejects_two_operand_tm(self):
        with self.assertRaisesRegex(ep.ExportError, "Tm"):
            ep._validate_stdlib(synthetic_pdf(b"1 1 Tm <0041> Tj\n"))

    def test_rejects_uncompressed_content_stream(self):
        with self.assertRaisesRegex(ep.ExportError, "解压失败"):
            ep._validate_stdlib(synthetic_pdf(b"1 0 0 1 5 5 Tm (x) Tj\n",
                                             compress=False))

    def test_rejects_xref_size_mismatch(self):
        blob = synthetic_pdf(b"1 0 0 1 5 5 Tm (x) Tj\n").replace(b"xref\n0 5\n",
                                                                 b"xref\n0 9\n")
        with self.assertRaisesRegex(ep.ExportError, "条目数"):
            ep._validate(blob)

    def test_reports_reject_non_pdf_bytes(self):
        with self.assertRaises(ep.ExportError):
            ep._validate(b"not a pdf at all")


class TestTextMetrics(unittest.TestCase):
    def test_long_token_is_hard_split(self):
        """一整串无空格的代码/链接必须能切开，否则会冲出右边界。"""
        long = "A" * 400
        lines = ep._wrap(long, 9.0, ep.CONTENT_W)
        self.assertGreater(len(lines), 1)
        for line in lines:
            self.assertLessEqual(ep._text_w(line, 9.0), ep.CONTENT_W + 1.0)

    def test_clean_strips_control_and_astral(self):
        self.assertEqual(ep._clean("a\x00b\tc"), "ab    c")
        self.assertEqual(ep._clean("\U0001f680"), "\u25a1")
        self.assertEqual(ep._clean(None), "")
        self.assertEqual(ep._clean("line\r\nnext"), "line\nnext")

    def test_rl_esc_escapes_markup(self):
        """reportlab 的 Paragraph 吃 XML：不转义的话 "<30%" 会让整份 PDF 直接失败。"""
        self.assertEqual(ep._rl_esc("a < b & c > d"), "a &lt; b &amp; c &gt; d")
        self.assertEqual(ep._rl_esc("<b>粗</b>"), "&lt;b&gt;粗&lt;/b&gt;")


class TestRenderToFile(unittest.TestCase):
    def test_writes_creates_parent_and_returns_absolute_path(self):
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "nested" / "deep" / "report.pdf"
            written = ep.render_to_file(make_doc(), target, "stdlib")
            self.assertEqual(Path(written).resolve(), target.resolve())
            self.assertTrue(target.exists())
            self.assertGreater(target.stat().st_size, 1000)
            self.assertEqual(target.read_bytes()[:5], b"%PDF-")


    def test_empty_blocks_do_not_break_layout(self):
        """空条目不能让版面炸，也不能悄悄吃掉整节。"""
        doc = ReportDocument(title="空块", sections=[
            Section("一", [Bullets([]), Table(header=[], rows=[]),
                           MetricGrid([]), Callout(""), CodeBlock("")])])
        blob = ep.render(doc, "stdlib")
        ep._validate_stdlib(blob)
        self.assertIn("空块", flat(drawn_text(blob)))
        self.assertIn("一", flat(drawn_text(blob)))


@unittest.skipUnless(has_pypdf(), "本机未安装 pypdf")
class TestThirdPartyParserAccepts(unittest.TestCase):
    """自研写入器最大的风险是"自己校验自己通过"，所以要拿第三方解析器再读一遍。"""

    def setUp(self):
        from pypdf import PdfReader
        import io

        self.blob = ep.render(make_doc(), "stdlib")
        self.reader = PdfReader(io.BytesIO(self.blob))

    def test_reader_opens_and_counts_pages(self):
        self.assertGreaterEqual(len(self.reader.pages), 1)

    def test_extracted_text_contains_chinese(self):
        joined = flat("".join((p.extract_text() or "") for p in self.reader.pages))
        self.assertIn("贵州茅台", joined)
        self.assertIn("不构成投资建议", joined)

    def test_document_title_is_in_metadata(self):
        meta = self.reader.metadata or {}
        self.assertIn("研究", str(meta.get("/Title", "")))


@unittest.skipUnless(ep._has_reportlab(), "本机未安装 reportlab")
class TestReportlabEngine(unittest.TestCase):
    def test_all_block_types_render(self):
        blob = ep.render(make_doc(), "reportlab")
        self.assertTrue(blob.startswith(b"%PDF-"))
        self.assertIn(b"%%EOF", blob[-40:])
        ep._validate(blob)

    def test_xml_metachars_do_not_break_the_story(self):
        """回归：Paragraph 走 mini-XML，正文里的 < > & 早先是直接塞进去的。"""
        doc = ReportDocument(
            title="含 <标签> & 符号",
            sections=[Section("一、结论",
                              [Paragraph("若 PE<30 且 ROE>15% 则 A>B")])],
            disclaimer="x & y")
        blob = ep.render(doc, "reportlab")
        self.assertTrue(blob.startswith(b"%PDF-"))

    def test_empty_lists_do_not_produce_flowables(self):
        doc = ReportDocument(title="空块", sections=[
            Section("一", [Bullets([]), Table(header=[], rows=[]), MetricGrid([])])])
        self.assertTrue(ep.render(doc, "reportlab").startswith(b"%PDF-"))

    def test_cid_font_is_registered(self):
        from reportlab.pdfbase import pdfmetrics

        ep.render(make_doc(), "reportlab")
        self.assertEqual(pdfmetrics.getFont(ep.CID_BASE).fontName, ep.CID_BASE)


if __name__ == "__main__":
    unittest.main()
