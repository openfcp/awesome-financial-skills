﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v14 Research Intelligence Hub CLI.

用法：
  python scripts/research_hub_cli.py doctor --offline
  python scripts/research_hub_cli.py live --symbols 600519,AU2502
  python scripts/research_hub_cli.py analyze --symbol 600519 --format markdown
  python scripts/research_hub_cli.py analyze --symbol 600519 --min-quality derived
  python scripts/research_hub_cli.py analyze --symbol 600519 --format pdf --out reports/moutai.pdf
  python scripts/research_hub_cli.py batch --symbols 600519,hk:00700,AAPL --format both --out reports/group
  python scripts/research_hub_cli.py diff --old old.json --new new.json --format markdown
  python scripts/research_hub_cli.py file --path data.csv --symbol 600519 --format both
  python scripts/research_hub_cli.py formats
  python scripts/research_hub_cli.py export --path brief.json --format pptx --out deck.pptx

退出码：0 成功；2 输入/文件问题；3 分析失败；4 部分标的失败或
（diff 模式下）`--fail-on-material` 检测到实质变化；5 数据质量未达标；6 导出失败。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from stock_researcher import research_export
from stock_researcher.research_batch import (
    GATE_CHOICES, BatchResearcher, compare_report_files, meets_quality,
)
from stock_researcher.research_contracts import DISCLAIMER, ResearchReport
from stock_researcher.research_data import DatasetLoader, LiveDataProvider
from stock_researcher.research_hub import ResearchHub

_BINARY_FORMATS = ("docx", "pptx", "pdf")
_FORMAT_CHOICES = ["markdown", "json", "text", "docx", "pptx", "pdf", "both"]


def _json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2, default=str)


def _render(report: ResearchReport, fmt: str) -> str:
    return research_export.render_text(report, fmt)


def cmd_doctor(args: argparse.Namespace) -> int:
    result = ResearchHub().doctor(offline=args.offline)
    print(_json(result))
    return 0 if result.get("status") == "ok" else 3


def cmd_formats(args: argparse.Namespace) -> int:
    print(_json(research_export.self_check()))
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    """将已保存的 JSON 简报重新导出成其他格式，不必重新跑分析。"""
    try:
        payload = json.loads(Path(args.path).read_text(encoding="utf-8"))
    except Exception as exc:
        print(_json({"status": "error", "error": "读取 JSON 简报失败：%s" % str(exc)[:200]}))
        return 2
    result = research_export.export(payload, args.format, args.out or None, args.engine)
    print(_json(result))
    return 0 if result.get("success") else 6


def _write_text(text: str, out: str, suffix: str) -> str:
    """把文本写到 out（补齐扩展名）；out 为空时打到 stdout，返回空串。"""
    if not out:
        print(text)
        return ""
    target = Path(out).expanduser()
    if target.suffix.lower() != suffix:
        target = target.with_suffix(suffix)
    if target.parent and not target.parent.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(text.encode("utf-8"))
    return str(target)


def cmd_batch(args: argparse.Namespace) -> int:
    """多标的批量研究；单标的失败只落成一行错误，不中断整批。"""
    provider = LiveDataProvider(use_network=not args.offline, cache_ttl=args.cache_ttl)
    try:
        result = BatchResearcher(hub=ResearchHub(provider=provider),
                                 max_workers=args.workers).run(
            args.symbols, min_quality=args.min_quality,
            question=args.question, asset_type=args.asset_type or None,
            market=args.market or None, history_days=args.days,
            include_news=not args.no_news, include_flow=not args.no_flow,
            include_fundamentals=not args.no_fundamentals,
        )
    except Exception as exc:
        print(_json({"status": "error", "error": str(exc)[:300]}))
        return 2

    written: List[str] = []
    payload = result.to_dict()
    payload["status"] = ("partial" if result.failed_rows
                         else "ok" if result.gate_passed else "quality_gate_failed")
    payload["quality_gate"] = {"min_quality": args.min_quality or "any",
                               "passed": result.gate_passed}
    try:
        if args.format in ("markdown", "both"):
            out = str(Path(args.out).with_suffix("")) + ".md" if args.out and args.format == "both" else args.out
            path = _write_text(result.to_markdown(), out, ".md")
            if path:
                written.append(path)
        if args.format in ("json", "both"):
            out = str(Path(args.out).with_suffix("")) + ".json" if args.out and args.format == "both" else args.out
            path = _write_text(_json(payload), out, ".json")
            if path:
                written.append(path)
    except Exception as exc:
        print(_json({"status": "error", "error": str(exc)[:300]}))
        return 6

    if written:
        print(_json({"status": "ok" if not result.failed_rows else "partial",
                     "summary": result.summary, "written": written,
                     "disclaimer": DISCLAIMER}))
    if not result.ok_rows:
        return 3
    if result.failed_rows:
        return 4
    return 0 if result.gate_passed else 5


def cmd_diff(args: argparse.Namespace) -> int:
    """对比两份已保存的 JSON 简报。"""
    try:
        diff = compare_report_files(args.old, args.new)
    except Exception as exc:
        print(_json({"status": "error", "error": str(exc)[:300]}))
        return 2
    if args.format == "json":
        payload = {"status": "ok", "material": diff.material}
        payload.update(diff.to_dict())
        text = _json(payload)
    else:
        text = diff.to_markdown()
    try:
        written = _write_text(text, args.out, ".json" if args.format == "json" else ".md")
    except Exception as exc:
        print(_json({"status": "error", "error": str(exc)[:300]}))
        return 6
    if written:
        print(_json({"status": "ok", "material": diff.material,
                     "verdict": diff.verdict, "written": [written],
                     "disclaimer": DISCLAIMER}))
    if args.fail_on_material and diff.material:
        return 4
    return 0


def cmd_live(args: argparse.Namespace) -> int:
    symbols = [s.strip() for s in args.symbols.split(",") if s.strip()]
    if not symbols:
        print(_json({"status": "error", "error": "至少提供一个标的"}))
        return 2
    provider = LiveDataProvider(use_network=True, cache_ttl=args.cache_ttl)
    hub = ResearchHub(provider=provider)
    snapshots = hub.refresh_quotes(symbols, interval=args.interval, iterations=args.iterations)
    print(_json({"status": "ok", "data": snapshots, "disclaimer": DISCLAIMER}))
    return 0


def _write_outputs(report: ResearchReport, args: argparse.Namespace) -> List[str]:
    """按 --format 落盘；文本格式在省略 --out 时直接打到 stdout。

    二进制格式必须有 --out：默认名落到当前目录会让用户在没要求的地方收到文件。
    """
    formats = ["markdown", "json"] if args.format == "both" else [args.format]
    written: List[str] = []
    for fmt in formats:
        if fmt in _BINARY_FORMATS and not args.out:
            raise ValueError("导出 %s 需要 --out 指定输出路径" % fmt)
        if not args.out:
            print(_render(report, fmt))
            continue
        result = research_export.export(report, fmt, args.out, args.engine)
        if not result.get("success"):
            raise ValueError("%s 导出失败：%s" % (fmt, result.get("error")))
        written.append(result["path"])
    return written


def cmd_analyze(args: argparse.Namespace) -> int:
    hub = ResearchHub(provider=LiveDataProvider(use_network=not args.offline,
                                                cache_ttl=args.cache_ttl))
    contracts = [x.strip() for x in (args.contracts or "").split(",") if x.strip()] or None
    try:
        report = hub.analyze(
            args.symbol, question=args.question, asset_type=args.asset_type or None,
            market=args.market or None, history_days=args.days,
            include_news=not args.no_news, include_flow=not args.no_flow,
            include_fundamentals=not args.no_fundamentals,
            futures_contracts=contracts, spot_price=args.spot,
        )
    except Exception as exc:
        print(_json({"status": "error", "error": str(exc)[:300]}))
        return 3
    try:
        written = _write_outputs(report, args)
    except Exception as exc:
        print(_json({"status": "error", "run_id": report.run_id,
                     "error": str(exc)[:300]}))
        return 6
    gate_ok = meets_quality(report.data_quality.status, args.min_quality)
    gate = {"min_quality": args.min_quality or "any", "passed": gate_ok}
    if written:
        print(_json({"status": "ok", "run_id": report.run_id,
                     "data_quality": report.data_quality.to_dict(),
                     "quality_gate": gate,
                     "written": written, "disclaimer": DISCLAIMER}))
    elif args.format == "both":
        print(_json({"run_id": report.run_id, "quality_gate": gate,
                     "note": "Markdown 与 JSON 已输出到 stdout"}))
    if not gate_ok or report.data_quality.status in ("insufficient",):
        return 5
    return 0

def cmd_file(args: argparse.Namespace) -> int:
    try:
        mapping = json.loads(args.mapping) if args.mapping else None
        benchmark = None
        if args.benchmark:
            bench_dataset = DatasetLoader.load(args.benchmark)
            benchmark = DatasetLoader.to_price_series(
                bench_dataset, symbol=args.benchmark_symbol or "BENCHMARK",
                asset_type="index", mapping=None)
        report = ResearchHub().analyze_dataset(
            args.path, symbol=args.symbol or "", asset_type=args.asset_type or "",
            mapping=mapping, question=args.question, benchmark=benchmark)
    except Exception as exc:
        print(_json({"status": "error", "error": str(exc)[:300]}))
        return 2
    try:
        written = _write_outputs(report, args)
    except Exception as exc:
        print(_json({"status": "error", "run_id": report.run_id,
                     "error": str(exc)[:300]}))
        return 6
    if written:
        print(_json({"status": "ok", "run_id": report.run_id,
                     "data_quality": report.data_quality.to_dict(),
                     "written": written, "disclaimer": DISCLAIMER}))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="stock-researcher v14 Research Intelligence Hub")
    sub = parser.add_subparsers(dest="command", required=True)

    doctor = sub.add_parser("doctor", help="离线能力自检")
    doctor.add_argument("--offline", action="store_true", default=True)
    doctor.set_defaults(func=cmd_doctor)

    live = sub.add_parser("live", help="有界实时刷新")
    live.add_argument("--symbols", required=True, help="逗号分隔，如 600519,AU2502,110022")
    live.add_argument("--iterations", type=int, default=1)
    live.add_argument("--interval", type=float, default=0.0)
    live.add_argument("--cache-ttl", type=float, default=15.0)
    live.set_defaults(func=cmd_live)

    analyze = sub.add_parser("analyze", help="在线获取并生成研究简报")
    analyze.add_argument("--symbol", required=True)
    analyze.add_argument("--question", default="")
    analyze.add_argument("--asset-type", default="", choices=["", "stock", "fund", "etf", "index", "futures"])
    analyze.add_argument("--market", default="", choices=["", "cn", "hk", "us", "global"])
    analyze.add_argument("--days", type=int, default=250)
    analyze.add_argument("--contracts", default="", help="期货期限结构合约，逗号分隔")
    analyze.add_argument("--spot", type=float, default=None)
    analyze.add_argument("--no-news", action="store_true")
    analyze.add_argument("--no-flow", action="store_true")
    analyze.add_argument("--no-fundamentals", action="store_true")
    analyze.add_argument("--offline", action="store_true", help="不请求网络（通常只用于验证输入）")
    analyze.add_argument("--cache-ttl", type=float, default=15.0)
    analyze.add_argument("--min-quality", default="", choices=[""] + list(GATE_CHOICES),
                         help="数据质量门槛；未达标时退出码为 5")
    analyze.add_argument("--format", choices=_FORMAT_CHOICES, default="markdown")
    analyze.add_argument("--out", default="", help="输出路径；both 时生成 .md/.json")
    analyze.add_argument("--engine", default="auto",
                        help="docx/pptx/pdf 渲染引擎：auto、stdlib 或 python-docx/python-pptx/reportlab")
    analyze.set_defaults(func=cmd_analyze)

    file_cmd = sub.add_parser("file", help="分析 CSV/JSON/XLSX/PDF/文本数据集")
    file_cmd.add_argument("--path", required=True)
    file_cmd.add_argument("--symbol", default="")
    file_cmd.add_argument("--asset-type", default="", choices=["", "stock", "fund", "etf", "index", "futures"])
    file_cmd.add_argument("--mapping", default="", help='JSON 字段映射，如 {"close":"收盘价"}')
    file_cmd.add_argument("--benchmark", default="")
    file_cmd.add_argument("--benchmark-symbol", default="")
    file_cmd.add_argument("--question", default="")
    file_cmd.add_argument("--format", choices=_FORMAT_CHOICES, default="json")
    file_cmd.add_argument("--out", default="")
    file_cmd.add_argument("--engine", default="auto")
    file_cmd.set_defaults(func=cmd_file)

    batch = sub.add_parser("batch", help="多标的批量研究，输出对比表")
    batch.add_argument("--symbols", required=True,
                       help="逗号/空格/分号分隔，如 600519,hk:00700,AAPL")
    batch.add_argument("--question", default="")
    batch.add_argument("--asset-type", default="", choices=["", "stock", "fund", "etf", "index", "futures"])
    batch.add_argument("--market", default="", choices=["", "cn", "hk", "us", "global"])
    batch.add_argument("--days", type=int, default=250)
    batch.add_argument("--min-quality", default="", choices=[""] + list(GATE_CHOICES))
    batch.add_argument("--workers", type=int, default=3, help="并行度（1-8）")
    batch.add_argument("--no-news", action="store_true")
    batch.add_argument("--no-flow", action="store_true")
    batch.add_argument("--no-fundamentals", action="store_true")
    batch.add_argument("--offline", action="store_true")
    batch.add_argument("--cache-ttl", type=float, default=15.0)
    batch.add_argument("--format", choices=["markdown", "json", "both"], default="markdown")
    batch.add_argument("--out", default="", help="输出路径；both 时生成 .md/.json")
    batch.set_defaults(func=cmd_batch)

    diff_cmd = sub.add_parser("diff", help="对比两份已保存的 JSON 简报")
    diff_cmd.add_argument("--old", required=True, help="旧简报 .json")
    diff_cmd.add_argument("--new", required=True, help="新简报 .json")
    diff_cmd.add_argument("--format", choices=["markdown", "json"], default="markdown")
    diff_cmd.add_argument("--out", default="", help="输出路径；省略时打到 stdout")
    diff_cmd.add_argument("--fail-on-material", action="store_true",
                          help="结论发生实质性变化时返回退出码 4")
    diff_cmd.set_defaults(func=cmd_diff)

    fmt = sub.add_parser("formats", help="导出能力自检：哪些格式在当前环境能出")
    fmt.set_defaults(func=cmd_formats)

    exp = sub.add_parser("export", help="把已保存的 JSON 简报转成其他格式")
    exp.add_argument("--path", required=True, help="analyze --format json 产出的 .json 文件")
    exp.add_argument("--format", required=True, choices=[c for c in _FORMAT_CHOICES if c != "both"])
    exp.add_argument("--out", default="", help="输出路径；省略时用默认文件名落在当前目录")
    exp.add_argument("--engine", default="auto")
    exp.set_defaults(func=cmd_export)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
