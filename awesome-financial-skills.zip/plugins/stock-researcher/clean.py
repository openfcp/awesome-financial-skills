# -*- coding: utf-8 -*-
"""clean.py — 交付前清理 + 技能包出包脚本。

上传系统拒绝二进制文件（.pyc/.pdf/.png 等），Skill 包仅支持两级目录结构
（根目录/二级目录/文件，二级目录内不得再有子目录）、解压后总大小 ≤ 3MB。

用法：
  python clean.py --dry-run    # 只列出问题项（推荐先跑）
  python clean.py --zip        # 出技能包 zip（源码树只读，产物与暂存都在包外）
  python clean.py --full       # 删二进制/__pycache__/.pytest_cache/运行时缓存目录
                               # + 三级及以上嵌套目录兜底删除
  python clean.py --binary     # 只删已知二进制文件

注意：
  - 清理后不要再执行任何 import 项目代码的命令（会重新生成 .pyc）；
    必要验证请加 PYTHONDONTWRITEBYTECODE=1
  - 测试请走 runtests.py（自带 PYTHONDONTWRITEBYTECODE=1）
  - --zip 绝不对源码树做任何删除
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent

# 上传限制：解压后总大小 ≤ 3MB
SIZE_LIMIT = 3 * 1024 * 1024
# 上传限制：整目录文件数 ≤ 200（平台按源目录计数，tests/ 也算在内）
FILE_COUNT_LIMIT = 200

# 运行时缓存目录（整目录删除，运行时自动重建）
RUNTIME_DIRS = [
    ".cache",
    "data",
]

# 源码树里必须留着、只是不出包的目录：data/evolution/predictions.jsonl 是概率校准
# 的真实命中历史，清库等于把预测自评能力删掉，所以 --full 也不许动它。
KEEP_IN_SOURCE_TREE = ("data",)

# 已知二进制扩展名
BINARY_EXTS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".gif", ".zip", ".docx", ".xlsx",
    ".pptx", ".exe", ".bin", ".onnx", ".pyc", ".pyo", ".pyd", ".7z", ".rar",
}

# 出包产物落点（包外目录，避免和源码树混在一起）
ZIP_OUT_DIR = Path(r"D:\claude 开发\专家包")

# ── v13.0 上架剔除清单 ───────────────────────────────────────────────────────
# 评审点名的三类动作里，前两类靠"整个模块不进包"来根治：语音的 PowerShell 兜底、
# 外部 MCP 桥按环境变量 fork 任意命令。源码树保留（开发者显式开开关才生效），
# 交付包连代码都不带，扫包工具也就无从标红。
SECURITY_EXCLUDE = (
    "stock_researcher/voice_interface.py",      # SAPI TTS/STT 起 PowerShell
    "stock_researcher/mcp_external_bridge.py",  # 按环境变量启动任意命令
    "run_voice.py",                             # 语音交互入口
    # 只覆盖上述模块的测试文件：模块不在包里，用例必然失败
    "tests/test_v1100_external_mcp.py",
    "tests/test_v1300_security_switches.py",
)

# 技能包（SkillHub 上传路径）额外剔除：开发/构建脚本 + 专家包专属件
SKILL_ONLY_EXCLUDE = (
    "tests", "runtests.py", "pytest.ini", "clean.py",
    "build_expert_package.py", ".codebuddy-plugin", "agents",
)

# 交付包内不允许出现的进程/shell 动作（构建闸门按"去掉注释与字符串后的代码流"判定）
RISKY_PATTERNS = (
    (r"subprocess\.", "起子进程"),
    (r"Popen\(", "起子进程"),
    (r"os\.system\(", "调用系统 shell"),
    (r"os\.popen\(", "调用系统 shell"),
    (r"powershell", "调用系统 shell"),
)
# 全局 opener 改写只允许出现在显式开关函数所在的那个文件里
OPENER_ALLOWED_FILES = {"stock_researcher/data_proxy_guard.py"}


def _rel(p) -> str:
    return str(p).replace("\\", "/")


def _excluded(rel_path: str, extra_exclude=()) -> bool:
    """相对路径是否剔出交付包（运行时目录 + 安全清单 + 该包型专属清单）。"""
    rel = _rel(rel_path)
    head = rel.split("/")[0]
    if head in RUNTIME_DIRS or head == "EMPTY":
        return True
    for prefix in SECURITY_EXCLUDE + tuple(extra_exclude):
        pref = _rel(prefix)
        if rel == pref or rel.startswith(pref + "/"):
            return True
    return False


def _package_members(extra_exclude=()):
    """返回 [(rel_path, Path)]，即交付包的真实成员（不含任何二进制）。"""
    out = []
    for f in sorted(SKILL_DIR.rglob("*")):
        if not f.is_file():
            continue
        rel = _rel(f.relative_to(SKILL_DIR))
        if _excluded(rel, extra_exclude):
            continue
        if f.suffix.lower() in BINARY_EXTS or rel.endswith((".pyc", ".pyo")):
            continue
        out.append((rel, f))
    return out



def _scan_binary() -> list:
    return [f for f in SKILL_DIR.rglob("*")
            if f.is_file() and f.suffix.lower() in BINARY_EXTS]


def _scan_pycache() -> list:
    return [d for d in SKILL_DIR.rglob("__pycache__") if d.is_dir()]


def _scan_pytest_cache() -> list:
    return [d for d in SKILL_DIR.rglob(".pytest_cache") if d.is_dir()]


def _scan_deep_dirs() -> list:
    """三级及以上嵌套目录（相对路径 parts >= 2），上传校验只允许两级结构。

    注意：二级目录（如 stock_researcher/、tests/）内的任何子目录都违规；
    白名单外的新增运行时目录也会被兜底抓到。
    """
    hits = []
    for d in SKILL_DIR.rglob("*"):
        if d.is_dir() and len(d.relative_to(SKILL_DIR).parts) >= 2:
            hits.append(d)
    hits.sort(key=lambda p: len(p.relative_to(SKILL_DIR).parts), reverse=True)
    top, seen = [], []
    for d in hits:
        if not any(d.is_relative_to(s) for s in seen):
            top.append(d)
            seen.append(d)
    return top


def _package_size() -> int:
    return sum(f.stat().st_size for f in SKILL_DIR.rglob("*") if f.is_file())


def _skill_meta():
    """从 SKILL.md frontmatter 读 name/version（出包命名与顶层目录名）。"""
    src = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    fm = src.split("---", 2)[1] if src.startswith("---") else ""

    def pick(key, default=""):
        m = re.search(rf"^{key}:\s*[\"']?([^\"'\s]+)", fm, re.M)
        return m.group(1) if m else default

    return pick("name", SKILL_DIR.name), pick("version", "0.0.0")


def _skill_frontmatter_bytes() -> int:
    src = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    if not src.startswith("---"):
        return 0
    return len(src.split("---", 2)[1].encode("utf-8"))


def _source_file_count() -> int:
    """平台按整个源目录计数：tests/、构建脚本都算，只排除字节码缓存。"""
    return sum(1 for p in SKILL_DIR.rglob("*")
               if p.is_file()
               and "__pycache__" not in p.parts
               and p.suffix not in (".pyc", ".pyo"))


def dry_run():
    print("== 二进制文件 ==")
    for f in _scan_binary():
        print(f"  {f.relative_to(SKILL_DIR)} ({f.stat().st_size} B)")
    print("== __pycache__ 目录 ==")
    for d in _scan_pycache():
        print(f"  {d.relative_to(SKILL_DIR)}/")
    print("== .pytest_cache 目录 ==")
    for d in _scan_pytest_cache():
        print(f"  {d.relative_to(SKILL_DIR)}/")
    print("== 违规嵌套目录（三级及以上，上传会被拒）==")
    for d in _scan_deep_dirs():
        print(f"  {d.relative_to(SKILL_DIR)}/")
    size = _package_size()
    flag = "⚠️ 超限！" if size > SIZE_LIMIT else "✅"
    print(f"== 源码树总大小 == {size} 字节 / 限制 {SIZE_LIMIT} {flag}")
    n_files = _source_file_count()
    print(f"== 源目录文件数 == {n_files} 个 / 限制 {FILE_COUNT_LIMIT} "
          f"{'✅' if n_files <= FILE_COUNT_LIMIT else '⚠️ 超限！平台会拒收'}")
    print("== v13 上架剔除清单（源码树保留，交付包不含）==")
    for rel in SECURITY_EXCLUDE:
        exists = (SKILL_DIR / rel).exists()
        print(f"  {'存在→已剔除' if exists else '不存在'}  {rel}")
    pkg_size = sum(p.stat().st_size for _, p in _package_members(SKILL_ONLY_EXCLUDE))
    print(f"== 技能包（剔除后）大小 == {pkg_size} 字节 / 限制 {SIZE_LIMIT} "
          f"{'✅' if pkg_size <= SIZE_LIMIT else '⚠️ 超限！'}")
    fm_bytes = _skill_frontmatter_bytes()
    print(f"== SKILL.md frontmatter == {fm_bytes} B "
          f"{'✅' if fm_bytes <= 6144 else '⚠️ 超 6KB，市场解析正文会失败'}")



def full():
    n = 0
    for f in _scan_binary():
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    for d in _scan_pycache() + _scan_pytest_cache():
        try:
            shutil.rmtree(d, ignore_errors=True)
            n += 1
        except OSError:
            pass
    for rel in RUNTIME_DIRS:
        if rel in KEEP_IN_SOURCE_TREE:
            continue  # 删了就等于把概率校准的真实历史清库，只从交付包剔除
        d = SKILL_DIR / rel
        if d.exists() and d.is_dir():
            try:
                shutil.rmtree(d, ignore_errors=True)
                n += 1
            except OSError:
                pass
    for d in _scan_deep_dirs():
        shutil.rmtree(d, ignore_errors=True)
        n += 1
    print(f"清理完成：{n} 项")
    print(f"（{', '.join(KEEP_IN_SOURCE_TREE)} 保留在源码树，仅不出包）")
    dry_run()


def binary_only():
    n = 0
    for f in _scan_binary():
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    print(f"删除二进制文件 {n} 个")


# ── 出包闸门 ─────────────────────────────────────────────────────────────────
def _gate_no_binary(members):
    hits = [rel for rel, p in members if p.suffix.lower() in BINARY_EXTS]
    assert not hits, f"交付包含二进制文件：{hits[:5]}"
    return f"{len(members)} 个文件全部文本"


def _gate_depth(members):
    deep = [rel for rel, _ in members if len(rel.split("/")) > 2]
    assert not deep, f"超过两级目录（上传会被拒）：{deep[:5]}"
    return "最深两级目录"


def _gate_size(members):
    total = sum(p.stat().st_size for _, p in members)
    assert total <= SIZE_LIMIT, f"解压后 {total} B 超过 {SIZE_LIMIT} B"
    return f"{total} B / {SIZE_LIMIT} B"


def _gate_security(members):
    rels = {rel for rel, _ in members}
    leaked = [rel for rel in SECURITY_EXCLUDE if rel in rels]
    assert not leaked, f"v13 剔除清单里的文件仍在包里：{leaked}"
    absent = [rel for rel in SECURITY_EXCLUDE if (SKILL_DIR / rel).exists()]
    return f"包内 0 个，源码树 {len(absent)} 个照常保留"


def _code_only(text: str) -> str:
    """只保留代码 token（丢掉注释与字符串），防止说明文字误报或掩盖真调用。"""
    import io
    import tokenize
    kept = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            if tok.type in (tokenize.COMMENT, tokenize.STRING):
                continue
            kept.append(tok.string)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return text  # 解析不了的 python 文件一律按原文扫，宁可误报
    return "".join(kept)


def _gate_risky_code(members):
    offenders = []
    for rel, p in members:
        if not rel.endswith(".py"):
            continue
        if rel.split("/")[0] == "tests":
            continue  # tests/ 是开发件，里面的 mock 用来证明"没有 fork"
        code = _code_only(p.read_text(encoding="utf-8", errors="ignore"))
        for pattern, why in RISKY_PATTERNS:
            if re.search(pattern, code, re.I):
                offenders.append(f"{rel}: {why} ({pattern})")
        if re.search(r"install_opener", code) and rel not in OPENER_ALLOWED_FILES:
            offenders.append(f"{rel}: 改写全局 urllib opener")
    assert not offenders, "交付包内含进程/shell 级动作：" + "; ".join(offenders[:5])
    return "无 fork/shell/全局 opener 改写（按代码 token 判定）"


_SMOKE_SCRIPT = r'''
import sys, zipfile, json
sys.dont_write_bytecode = True
import stock_researcher as sr
assert sr.parse_voice_command("预测茅台")["code"] == "600519", "口语解析不可用"
from stock_researcher import export_docx, research_hub, data_multi_source, report_ir
from stock_researcher import research_batch
assert research_batch.parse_symbols("600519,AAPL,600519") == ["600519", "AAPL"]
assert research_batch.meets_quality("actual", "derived")
doc = report_ir.ReportDocument(title="出包自检", sections=[
    report_ir.Section(title="结论", blocks=[
        report_ir.Heading(text="要点", level=2),
        report_ir.Paragraph(text="交付副本可渲染 Word")])])
blob = export_docx.render(doc, engine="stdlib")
with open(sys.argv[1], "wb") as f:
    f.write(blob)
with zipfile.ZipFile(sys.argv[1]) as z:
    names = z.namelist()
    assert "word/document.xml" in names and "word/styles.xml" in names, names
    xml = z.read("word/document.xml").decode("utf-8")
    assert "交付副本可渲染 Word" in xml, "正文没进 document.xml"
print(json.dumps({"ok": True, "docx_parts": len(names),
                  "version": sr.__version__}, ensure_ascii=False))
'''


def _gate_smoke(staging_top: Path) -> str:
    """在包外的暂存副本里真跑一遍：导入无副作用 + 口语解析 + Word 渲染。"""
    if os.environ.get("STOCK_RESEARCHER_SKIP_SMOKE") == "1":
        return "已跳过（STOCK_RESEARCHER_SKIP_SMOKE=1）"
    out = staging_top / "_smoke.docx"
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONIOENCODING": "utf-8"}
    cli = subprocess.run([sys.executable, str(staging_top / "scripts" / "stock_predict.py"),
                          "--test"], cwd=str(staging_top), env=env,
                         capture_output=True, text=True, timeout=300, encoding="utf-8",
                         errors="replace")
    assert cli.returncode == 0, f"副本内 CLI 自检失败：{cli.stdout[-400:]}{cli.stderr[-400:]}"
    smoke = subprocess.run([sys.executable, "-c", _SMOKE_SCRIPT, str(out)],
                           cwd=str(staging_top), env=env,
                           capture_output=True, text=True, timeout=300, encoding="utf-8",
                           errors="replace")
    assert smoke.returncode == 0, f"副本内导入/渲染冒烟失败：{smoke.stderr[-600:]}"
    out.unlink(missing_ok=True)
    return smoke.stdout.strip().splitlines()[-1]


def build_skill_zip(out_dir: Path = ZIP_OUT_DIR) -> Path:
    """组装技能包 zip：源码树只读，暂存与产物都落在包外。"""
    members = _package_members(SKILL_ONLY_EXCLUDE)
    n_source = _source_file_count()
    assert n_source <= FILE_COUNT_LIMIT, (
        f"源目录 {n_source} 个文件超过平台上限 {FILE_COUNT_LIMIT}："
        "平台按整目录计数（含 tests/），需先合并/清理再出包")
    assert len(members) <= FILE_COUNT_LIMIT, (
        f"技能包 {len(members)} 个文件超过平台上限 {FILE_COUNT_LIMIT}")
    name, version = _skill_meta()
    checks = [
        ("包内文件全为文本", _gate_no_binary(members)),
        ("目录层级", _gate_depth(members)),
        ("解压后体积", _gate_size(members)),
        ("v13 安全剔除", _gate_security(members)),
        ("包内无进程/shell 动作", _gate_risky_code(members)),
    ]
    staging = Path(tempfile.mkdtemp(prefix=f"{name}-skill-"))
    top = staging / name
    top.mkdir()
    for rel, src in members:
        dst = top / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    checks.append(("交付副本自跑（CLI 自检 + Word 渲染）", _gate_smoke(top)))

    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / f"{name}-skill-{version}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel, _ in members:
            zf.write(top / rel, f"{name}/{rel}")

    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        assert f"{name}/SKILL.md" in names, "技能包必须以 <name>/SKILL.md 为入口"
        roots = {n.split("/")[0] for n in names}
        assert roots == {name}, f"顶层应只有一个目录，实际：{roots}"
        bad = [n for n in names
               if n.count("/") > 2 or n.endswith(".pyc") or "__pycache__" in n
               or Path(n).suffix.lower() in BINARY_EXTS]
        assert not bad, f"zip 内有越界条目：{bad[:5]}"
        for rel in SECURITY_EXCLUDE:
            assert f"{name}/{rel}" not in names, f"zip 里混进了 {rel}"
    shutil.rmtree(staging, ignore_errors=True)

    print(f"✅ 技能包已产出：{zip_path}（{zip_path.stat().st_size // 1024}KB，"
          f"{len(members)} 个文件）")
    for k, v in checks:
        print(f"   - {k}：{v}")
    return zip_path


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="交付前清理 + 技能包出包（二进制/嵌套目录/体积/安全剔除守门）")
    ap.add_argument("--dry-run", action="store_true", help="只列出不删除")
    ap.add_argument("--zip", action="store_true", help="出技能包 zip（不删源码树任何文件）")
    ap.add_argument("--full", action="store_true", help="全量清理（推荐）")
    ap.add_argument("--binary", action="store_true", help="只删二进制文件")
    args = ap.parse_args()
    if args.dry_run:
        dry_run()
    elif args.zip:
        build_skill_zip()
    elif args.binary:
        binary_only()
    else:
        full()
