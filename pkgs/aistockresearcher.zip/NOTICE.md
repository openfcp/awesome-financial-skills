# 来源与许可

这个技能包由 **awesome-financial-skills** 清单整理，仅做分发搬运，不修改原作者内容。

| 项 | 值 |
|---|---|
| 技能 | 全球智能投研（`aistockresearcher`） |
| 作者 | skill-of-me |
| 原页面 | https://skillhub.cn/skills/aistockresearcher |
| 原始来源 | SkillHub（namespace `user_9d5a2a39`） |
| 许可证 | MIT |
| 清单版本 | 14.0.0 |

正文版权归原作者所有。若你是作者并要求下架，请到
https://github.com/openfcp/awesome-financial-skills/issues 提一个 issue，
我们会在确认后 24 小时内移除对应包与清单条目。
