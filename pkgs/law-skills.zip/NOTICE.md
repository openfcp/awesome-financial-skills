# 来源与许可

这个技能包由 **awesome-financial-skills** 清单整理，仅做分发搬运，不修改原作者内容。

| 项 | 值 |
|---|---|
| 技能 | 法律咨询与起诉状（`law-skills`） |
| 作者 | 马常成律师 |
| 原页面 | https://skillhub.cn/skills/law-skills |
| 原始来源 | SkillHub（namespace `user_5fa95d36`） |
| 许可证 | MIT |
| 清单版本 | 6.0 |

正文版权归原作者所有。若你是作者并要求下架，请到
https://github.com/openfcp/awesome-financial-skills/issues 提一个 issue，
我们会在确认后 24 小时内移除对应包与清单条目。
