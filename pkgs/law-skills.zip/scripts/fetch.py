#!/usr/bin/env python3
"""取件器：从 SkillHub 取回本插件对应的技能，装到 ~/.workbuddy/skills。

只有十几行 —— 真正的下载逻辑复用仓库里的 install.py（单一实现，避免两处漂移）。
"""
import subprocess
import sys
import tempfile
import urllib.request

ID = "law-skills"
MIRRORS = (
    "https://raw.githubusercontent.com/openfcp/awesome-financial-skills/main",
    "https://fastly.jsdelivr.net/gh/openfcp/awesome-financial-skills@main",
)


def fetch(path):
    last = None
    for base in MIRRORS:
        try:
            return urllib.request.urlopen(f"{base}{path}", timeout=40).read()
        except Exception as e:  # noqa: BLE001
            last = e
    raise SystemExit(f"取件失败，两个镜像都不可达：{last}")


tmp = tempfile.mkdtemp()
script = f"{tmp}/install.py"
open(script, "wb").write(fetch("/scripts/install.py"))
open(f"{tmp}/catalog.json", "wb").write(fetch("/catalog.json"))
sys.exit(subprocess.call([sys.executable, script,
                          "--catalog", f"{tmp}/catalog.json", "--only", ID]))
