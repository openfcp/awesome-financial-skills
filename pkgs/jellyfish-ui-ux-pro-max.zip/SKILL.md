---
name: UI/UX Pro Max（Jellyfish 内置副本）
description: Jellyfish 短剧工作台内置的 UI/UX 设计规范检索库副本，含风格、配色、字体与 UX 准则，供界面选型与评审；注意它与清单已有的 ui-ux-pro-max-skill 内容同源，装到本机时 name 同为 ui-ux-pro-max，会互相覆盖，建议二选一。（首次使用时自动从 作者的 GitHub 仓库 取回正文）
---

# UI/UX Pro Max（Jellyfish 内置副本）

这是一张**取件卡**：本插件不包含技能正文，正文在原作者处（作者的 GitHub 仓库）。

## 首次使用：先取件

```bash
python3 scripts/fetch.py
```

脚本位于本插件目录下的 `scripts/fetch.py`。它会去 作者的 GitHub 仓库 取回「jellyfish-ui-ux-pro-max」的当前版本，
安装到 `~/.workbuddy/skills`。取件成功后再继续。

## 取件之后

读取刚装好的技能目录里的 `SKILL.md`（`~/.workbuddy/skills/jellyfish-ui-ux-pro-max/SKILL.md`），
按其中的说明执行用户的请求。若用户已经装过该技能，`fetch.py` 会提示已存在，直接读即可。

## 说明

- 这个包只有我们自己的取件代码（几 KB），没有任何他人正文
- 每次取的都是原作者当前发布的最新版
- 取件失败：`404 / Version not found` 多为作者新版本仍在扫描，稍后重试；网络不通时换用
  `https://fastly.jsdelivr.net/gh/openfcp/awesome-financial-skills@main/catalog.json`
