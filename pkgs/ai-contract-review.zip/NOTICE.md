# 来源与许可

这个技能包由 **awesome-financial-skills** 清单整理，仅做分发搬运，不修改原作者内容。

| 项 | 值 |
|---|---|
| 技能 | AI 合同审查（`ai-contract-review`） |
| 作者 | 筱润科技 |
| 原页面 | https://skillhub.cn/skills/ai-contract-review |
| 原始来源 | SkillHub（namespace `user_638e256a`） |
| 许可证 | MIT |
| 清单版本 | 1.6.0 |

正文版权归原作者所有。若你是作者并要求下架，请到
https://github.com/openfcp/awesome-financial-skills/issues 提一个 issue，
我们会在确认后 24 小时内移除对应包与清单条目。
