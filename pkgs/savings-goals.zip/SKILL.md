---
name: 储蓄目标规划
description: 为退休、教育、购房等具体目标规划并追踪储蓄进度。｜美国市场与监管口径，境内业务需核对适用性。（首次使用时自动从 作者的 GitHub 仓库 取回正文）
---

# 储蓄目标规划

这是一张**取件卡**：本插件不包含技能正文，正文在原作者处（作者的 GitHub 仓库）。

## 首次使用：先取件

```bash
python3 scripts/fetch.py
```

脚本位于本插件目录下的 `scripts/fetch.py`。它会去 作者的 GitHub 仓库 取回「savings-goals」的当前版本，
安装到 `~/.workbuddy/skills`。取件成功后再继续。

## 取件之后

读取刚装好的技能目录里的 `SKILL.md`（`~/.workbuddy/skills/savings-goals/SKILL.md`），
按其中的说明执行用户的请求。若用户已经装过该技能，`fetch.py` 会提示已存在，直接读即可。

## 说明

- 这个包只有我们自己的取件代码（几 KB），没有任何他人正文
- 每次取的都是原作者当前发布的最新版
- 取件失败：`404 / Version not found` 多为作者新版本仍在扫描，稍后重试；网络不通时换用
  `https://fastly.jsdelivr.net/gh/openfcp/awesome-financial-skills@main/catalog.json`
