---
name: MoneyPrinterTurbo 短视频生成
description: 给一个主题或脚本，让 AI 代理自动完成 MoneyPrinterTurbo 的安装、配置、生成、等待与 MP4 交付，覆盖口播、教育、营销与素材混剪；依赖终端与网络、需自备 API 密钥，默认产出中文 9:16 竖屏视频，只交付成片不代替选题策划。（首次使用时自动从 作者的 GitHub 仓库 取回正文）
---

# MoneyPrinterTurbo 短视频生成

这是一张**取件卡**：本插件不包含技能正文，正文在原作者处（作者的 GitHub 仓库）。

## 首次使用：先取件

```bash
python3 scripts/fetch.py
```

脚本位于本插件目录下的 `scripts/fetch.py`。它会去 作者的 GitHub 仓库 取回「moneyprinterturbo-video」的当前版本，
安装到 `~/.workbuddy/skills`。取件成功后再继续。

## 取件之后

读取刚装好的技能目录里的 `SKILL.md`（`~/.workbuddy/skills/moneyprinterturbo-video/SKILL.md`），
按其中的说明执行用户的请求。若用户已经装过该技能，`fetch.py` 会提示已存在，直接读即可。

## 说明

- 这个包只有我们自己的取件代码（几 KB），没有任何他人正文
- 每次取的都是原作者当前发布的最新版
- 取件失败：`404 / Version not found` 多为作者新版本仍在扫描，稍后重试；网络不通时换用
  `https://fastly.jsdelivr.net/gh/openfcp/awesome-financial-skills@main/catalog.json`
