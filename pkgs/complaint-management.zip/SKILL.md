---
name: 投诉管理
description: 投诉数据统计分析、分类打标（JR/T 0169-2018）、复杂投诉谈判支持、和解协议起草、溯源整改与月报生成。（首次使用时自动从 SkillHub 取回正文）
---

# 投诉管理

这是一张**取件卡**：本插件不包含技能正文，正文在原作者处（SkillHub）。

## 首次使用：先取件

```bash
python3 scripts/fetch.py
```

脚本位于本插件目录下的 `scripts/fetch.py`。它会去 SkillHub 取回「complaint-management」的当前版本，
安装到 `~/.workbuddy/skills`。取件成功后再继续。

## 取件之后

读取刚装好的技能目录里的 `SKILL.md`（`~/.workbuddy/skills/complaint-management/SKILL.md`），
按其中的说明执行用户的请求。若用户已经装过该技能，`fetch.py` 会提示已存在，直接读即可。

## 说明

- 这个包只有我们自己的取件代码（几 KB），没有任何他人正文
- 每次取的都是原作者当前发布的最新版
- 取件失败：`404 / Version not found` 多为作者新版本仍在扫描，稍后重试；网络不通时换用
  `https://fastly.jsdelivr.net/gh/openfcp/awesome-financial-skills@main/catalog.json`
